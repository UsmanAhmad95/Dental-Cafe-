import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /**
   * Standalone output is used by the Dockerfile (self-contained server.js).
   * It is opt-in via env so `next start` (used by the preview runtime and
   * Vercel-style hosts) keeps working unchanged.
   */
  output: process.env.NEXT_OUTPUT_STANDALONE === "1" ? "standalone" : undefined,
  poweredByHeader: false,
};

export default nextConfig;
