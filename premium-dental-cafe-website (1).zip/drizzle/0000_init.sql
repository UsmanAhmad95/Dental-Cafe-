CREATE TABLE "appointments" (
	"id" serial PRIMARY KEY NOT NULL,
	"reference" varchar(24) NOT NULL,
	"treatment_slug" varchar(120) NOT NULL,
	"treatment_name" text NOT NULL,
	"doctor_slug" varchar(120),
	"doctor_name" text,
	"preferred_date" varchar(10) NOT NULL,
	"preferred_time" varchar(40) NOT NULL,
	"patient_name" text NOT NULL,
	"phone" varchar(40) NOT NULL,
	"whatsapp" varchar(40),
	"message" text,
	"status" varchar(20) DEFAULT 'new' NOT NULL,
	"source" varchar(40) DEFAULT 'website' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "appointments_reference_unique" UNIQUE("reference")
);
--> statement-breakpoint
CREATE TABLE "site_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"key" varchar(120) NOT NULL,
	"value" text,
	"version" integer DEFAULT 1 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "site_settings_key_unique" UNIQUE("key")
);
