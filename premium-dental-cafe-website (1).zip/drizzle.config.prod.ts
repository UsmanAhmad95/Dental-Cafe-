import "dotenv/config";
import { defineConfig } from "drizzle-kit";

/**
 * Drizzle config that targets whatever DATABASE_URL is in the environment.
 * Used to create the tables on your PRODUCTION database:
 *
 *   DATABASE_URL="postgres://..." npx drizzle-kit push --config drizzle.config.prod.ts
 *
 * (The default drizzle.config.json is pinned to the local sandbox database.)
 */
const url = process.env.DATABASE_URL;
if (!url) {
  throw new Error(
    'DATABASE_URL is not set. Example: DATABASE_URL="postgres://..." npx drizzle-kit push --config drizzle.config.prod.ts',
  );
}

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: { url },
});
