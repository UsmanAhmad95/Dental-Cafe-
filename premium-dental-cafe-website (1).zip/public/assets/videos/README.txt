DENTAL CAFE — VIDEOS DROP-IN LOCATION
=====================================
Place clinic tour / doctor introduction / treatment education / patient testimonial videos here
(e.g. clinic-tour.mp4, testimonial-01.mp4) OR use YouTube IDs.
Thumbnails go in this folder too (e.g. video-thumb-01.jpg).
Then edit  src/content/videos.ts  (set src or youtubeId, thumbnail status: "real", placeholder: false).
Videos never autoplay with sound.
