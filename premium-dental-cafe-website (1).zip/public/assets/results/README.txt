DENTAL CAFE — SMILE RESULTS (BEFORE / AFTER)
============================================
Only real, consented Dental Cafe patient results belong here. Use these file names:

  before-after-01-before.jpg   before-after-01-after.jpg
  before-after-02-before.jpg   before-after-02-after.jpg
  before-after-03-before.jpg   before-after-03-after.jpg

Then edit  src/content/results.ts  (treatment type / case description) and set the matching
entries in  src/content/assets.ts  to  status: "real".
