DENTAL CAFE — DOCTOR PHOTOS DROP-IN LOCATION
============================================
Place the ORIGINAL, UNMODIFIED doctor photographs here using these exact file names:

  doctor-usama.jpg
  doctor-javeriya.jpg
  doctor-marleen.jpg
  doctor-abdullah.jpg
  doctor-umair.jpg

Recommended: portrait orientation (4:5), at least 1200px wide, face centred in the upper half.
Then open  src/content/assets.ts  and set the matching entry's  status: "real".
The photo will automatically update in the doctor directory, doctor profile, homepage doctor
section, related treatment pages and every doctor CTA.
Never face-swap, retouch identities or AI-regenerate doctor images.
