DENTAL CAFE — BRAND LOGO DROP-IN LOCATION
=========================================
Place the OFFICIAL Dental Cafe logo files here (do not alter the original artwork):

  logo.png        -> primary logo, used on BLACK backgrounds (header, footer, mobile drawer)
  logo-dark.png   -> optional variant for WHITE backgrounds (falls back to logo.png)

Then open  src/content/assets.ts  and set  brandAssets.logo.status = "real"
(and brandAssets.logoOnLight.status = "real" if you added the light-background variant).

The <Logo /> component (src/components/brand/Logo.tsx) renders the file with a fixed height and
automatic width, so the original proportions are always preserved — it is never stretched.
Every logo instance on the site (header, footer, mobile navigation) reads from this one asset.
