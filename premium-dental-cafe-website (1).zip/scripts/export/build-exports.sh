#!/usr/bin/env bash
# =====================================================================
# Dental Cafe — build the two standalone export packages
#   PROJECT_EXPORT_01.zip  → Option 1 "Cinematic" homepage
#   PROJECT_EXPORT_02.zip  → Option 2 "Light Editorial" homepage
#
# Usage:  bash scripts/export/build-exports.sh [1|2|all]
# Env:    SMOKE_DATABASE_URL  Postgres URL used for the booking-API smoke test (optional)
#         EXPORT_WORK_DIR     scratch dir   (default /tmp/dental-cafe-exports)
#         EXPORT_OUT_DIR      where the .zip files are written (default project root)
#
# For each export: copy project → apply option → npm ci → typegen → tsc →
# next build → scan for sandbox refs → start production server → hit every
# route → zip. Any failure aborts with a non-zero exit code.
# =====================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TPL="$ROOT/scripts/export"
WORK="${EXPORT_WORK_DIR:-/tmp/dental-cafe-exports}"
OUT="${EXPORT_OUT_DIR:-$ROOT}"
WHICH="${1:-all}"

SUMMARY_1='**Homepage (Option 1 — Cinematic):** full-bleed dark photographic hero with a slow image zoom → black Google trust strip → cream "Ready for your next smile?" appointment CTA → About → Why Choose Us (black) → Featured Services → Meet Our Doctors (black) → Smile Results → Clinic Experience → Gallery → Video Testimonials (black) → Google Reviews → FAQ → Location / Map → final booking CTA (black).'
SUMMARY_2='**Homepage (Option 2 — Light Editorial):** white editorial hero with a black serif headline, framed image with an offset gold hairline and a floating 5.0 rating badge → black band combining the Google trust strip with the "Ready for your next smile?" booking CTA → About (white) → Meet Our Doctors (black) → Featured Services (white) → Why Choose Us (black) → Smile Results (white) → Video Testimonials (black) → Clinic Experience (cream) → Google Reviews (black) → Gallery (white) → FAQ (black) → Location / Map (white) → final booking CTA (black).'

log() { printf '\n== %s ==\n' "$*"; }

copy_base() { # $1 = destination dir
  local dest="$1"
  rm -rf "$dest"; mkdir -p "$dest"
  for entry in "$ROOT"/* "$ROOT"/.[!.]*; do
    [ -e "$entry" ] || continue
    case "$(basename "$entry")" in
      node_modules|.next|.git|.env|.env.bak|.env.local|scripts|tsconfig.tsbuildinfo|next-env.d.ts|drizzle.config.json|drizzle.config.prod.ts|DEPLOY.md|*.zip|*.log) continue ;;
    esac
    cp -a "$entry" "$dest/"
  done
  rm -rf "$dest/public/downloads"
}

apply_option() { # $1 = dest, $2 = option number, $3 = option name, $4 = summary
  local dest="$1" n="$2" name="$3" summary="$4"
  cp "$TPL/page.option-$n.tsx" "$dest/src/app/page.tsx"
  rm -rf "$dest/src/app/option-2" "$dest/src/components/preview"
  if [ "$n" = "1" ]; then
    rm -f "$dest/src/components/sections/HeroLight.tsx" "$dest/src/components/sections/TrustBookBand.tsx"
  fi
  cp "$TPL/drizzle.config.ts" "$dest/drizzle.config.ts"
  sed -i 's#disallow: \["/admin", "/api/", "/option-2"\]#disallow: ["/admin", "/api/"]#' "$dest/src/app/robots.ts"
  if grep -rn -e "OptionSwitcher" -e "option-2" "$dest/src" ; then
    echo "ERROR: preview-only references remain in export $n"; exit 1
  fi
  node -e '
    const fs = require("fs");
    const [tpl, out, n, name, summary] = process.argv.slice(1);
    const map = {
      "__OPTION_NUMBER__": n, "__OPTION_NAME__": name, "__OPTION_SUMMARY__": summary,
      "__IS_01__": n === "1" ? "✅ **this package**" : "",
      "__IS_02__": n === "2" ? "✅ **this package**" : "",
    };
    let t = fs.readFileSync(tpl, "utf8");
    for (const [k, v] of Object.entries(map)) t = t.split(k).join(v);
    fs.writeFileSync(out, t);
  ' "$TPL/README.template.md" "$dest/README.md" "$n" "$name" "$summary"
  ( cd "$dest" && node -e '
    const fs = require("fs"); const name = process.argv[1];
    for (const f of ["package.json", "package-lock.json"]) {
      const j = JSON.parse(fs.readFileSync(f, "utf8"));
      j.name = name; if (j.packages && j.packages[""]) j.packages[""].name = name;
      fs.writeFileSync(f, JSON.stringify(j, null, 2) + "\n");
    }' "dental-cafe-option-$n" )
}

smoke() { # $1 = dest, $2 = option number, $3 = port
  local dest="$1" n="$2" port="$3" base="http://127.0.0.1:$3" fail=0 code
  cd "$dest"
  DATABASE_URL="${SMOKE_DATABASE_URL:-}" ADMIN_PASSWORD="smoke-test" HOSTNAME=127.0.0.1 \
    node node_modules/next/dist/bin/next start -p "$port" > "/tmp/export-smoke-$n.log" 2>&1 &
  local pid=$!
  for _ in $(seq 1 40); do curl -sf -o /dev/null "$base/" && break; sleep 1; done

  local routes=( / /about /doctors /doctors/dr-usama /doctors/dr-javeriya-shahid /doctors/dr-marleen-mahiqa
    /doctors/dr-abdullah /doctors/dr-umair-bhalli /services /services/dental-implants /services/orthodontics-braces
    /services/general-dentistry /gallery /reviews /blog /blog/how-often-should-you-visit-the-dentist
    /blog/a-simple-daily-routine-for-healthier-gums /blog/what-to-expect-at-your-first-visit
    /blog/dental-implants-explained /blog/braces-or-aligners-questions-to-ask
    /blog/cosmetic-dentistry-understanding-your-options /contact /book /privacy-policy /terms /admin
    /sitemap.xml /robots.txt /assets/clinic/hero-main.jpg /assets/clinic/clinic-reception.jpg
    /assets/services/service-dental-implants.jpg /assets/blog/blog-daily-care.jpg /assets/gallery/gallery-01.jpg )
  for p in "${routes[@]}"; do
    code=$(curl -s -o /dev/null -w '%{http_code}' "$base$p")
    if [ "$code" = "200" ]; then printf 'ok   %-52s 200\n' "$p"; else printf 'FAIL %-52s %s\n' "$p" "$code"; fail=1; fi
  done

  code=$(curl -s -o /dev/null -w '%{http_code}' "$base/option-2")
  if [ "$code" = "404" ]; then echo "ok   /option-2 → 404 (not part of this package)"; else echo "FAIL /option-2 → $code"; fail=1; fi
  code=$(curl -s -o /dev/null -w '%{http_code}' "$base/this-page-does-not-exist")
  if [ "$code" = "404" ]; then echo "ok   unknown route → branded 404"; else echo "FAIL unknown route → $code"; fail=1; fi

  local home; home=$(curl -s "$base/")
  if echo "$home" | grep -q "Design preview"; then echo "FAIL design-preview switcher still present"; fail=1; else echo "ok   no design-preview switcher"; fi
  if [ "$n" = "1" ]; then
    if echo "$home" | grep -q "hero-zoom"; then echo "ok   homepage is Option 1 (cinematic hero)"; else echo "FAIL homepage is not Option 1"; fail=1; fi
  else
    if echo "$home" | grep -q "hero-zoom"; then echo "FAIL homepage shows Option 1 hero"; fail=1; else echo "ok   homepage is Option 2 (light editorial hero)"; fi
  fi
  if echo "$home" | grep -q "e2b.app"; then echo "FAIL preview hostname in HTML"; fail=1; else echo "ok   no preview hostname in rendered HTML"; fi

  if [ -n "${SMOKE_DATABASE_URL:-}" ]; then
    local d resp; d=$(date -d "+3 day" +%F)
    resp=$(curl -s -X POST "$base/api/appointments" -H 'Content-Type: application/json' \
      -d "{\"treatment\":\"dental-implants\",\"doctor\":\"any\",\"date\":\"$d\",\"time\":\"Morning\",\"name\":\"Export Smoke $n\",\"phone\":\"+92 300 0000000\"}")
    if echo "$resp" | grep -q '"ok":true'; then echo "ok   booking API stored a request → $resp"; else echo "FAIL booking API → $resp"; fail=1; fi
    if curl -s "$base/api/health" | grep -q '"ok":true'; then echo "ok   /api/health → database connected"; else echo "FAIL /api/health"; fail=1; fi
    if command -v psql >/dev/null 2>&1; then psql "$SMOKE_DATABASE_URL" -qc "delete from appointments where patient_name like 'Export Smoke%';" >/dev/null 2>&1 || true; fi
  fi

  kill "$pid" 2>/dev/null || true
  pkill -f "next start -p $port" 2>/dev/null || true
  wait "$pid" 2>/dev/null || true
  if [ "$fail" -ne 0 ]; then echo "SMOKE TEST FAILED (see /tmp/export-smoke-$n.log)"; exit 1; fi
}

verify() { # $1 = dest, $2 = option number, $3 = port
  local dest="$1" n="$2" port="$3"
  cd "$dest"
  log "export $n · npm ci (clean install from lockfile)"
  npm ci --no-audit --no-fund --prefer-offline --loglevel=error
  log "export $n · next typegen + tsc --noEmit"
  npx next typegen >/dev/null
  npx tsc --noEmit --pretty false
  echo "types OK"
  log "export $n · next build"
  npm run build 2>&1 | grep -E "Compiled|Generating static pages|Route \(app\)|^[├└┌].*|error|Error" | head -n 40
  log "export $n · scan for sandbox / preview references"
  if grep -rIl -i -e "e2b.app" -e "arena" --exclude-dir=node_modules --exclude-dir=.next . ; then
    echo "ERROR: sandbox/preview references found above"; exit 1
  fi
  echo "none found"
  log "export $n · production smoke test (port $port)"
  smoke "$dest" "$n" "$port"
}

package() { # $1 = dest, $2 = option number
  local dest="$1" n="$2" folder="PROJECT_EXPORT_0$2"
  cd "$dest"
  rm -rf .next node_modules tsconfig.tsbuildinfo next-env.d.ts
  cd "$WORK"
  rm -f "$OUT/$folder.zip"
  zip -qr -X "$OUT/$folder.zip" "$folder" -x '*.DS_Store'
  log "created $OUT/$folder.zip ($(du -h "$OUT/$folder.zip" | cut -f1), $(unzip -l "$OUT/$folder.zip" | tail -n1 | awk '{print $2}') files)"
}

mkdir -p "$WORK"
if [ "$WHICH" = "1" ] || [ "$WHICH" = "all" ]; then
  cd "$ROOT"; D="$WORK/PROJECT_EXPORT_01"
  log "Preparing PROJECT_EXPORT_01 — Option 1 (Cinematic)"
  copy_base "$D"; apply_option "$D" 1 "Cinematic" "$SUMMARY_1"; verify "$D" 1 4101; package "$D" 1
fi
if [ "$WHICH" = "2" ] || [ "$WHICH" = "all" ]; then
  cd "$ROOT"; D="$WORK/PROJECT_EXPORT_02"
  log "Preparing PROJECT_EXPORT_02 — Option 2 (Light Editorial)"
  copy_base "$D"; apply_option "$D" 2 "Light Editorial" "$SUMMARY_2"; verify "$D" 2 4102; package "$D" 2
fi
log "done"
