import type { Metadata } from "next";
import { Hero } from "@/components/sections/Hero";
import { TrustBar } from "@/components/sections/TrustBar";
import { AppointmentCta, FinalCta } from "@/components/sections/CtaBands";
import { AboutSection } from "@/components/sections/AboutSection";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { DoctorsSection } from "@/components/sections/DoctorsSection";
import { SmileResults } from "@/components/sections/SmileResults";
import { ClinicExperience } from "@/components/sections/ClinicExperience";
import {
  FaqSection,
  GalleryPreview,
  LocationSection,
  ReviewsSection,
  VideoTestimonials,
} from "@/components/sections/HomeSecondary";
import { site } from "@/content/site";

/**
 * HOMEPAGE — Option 1 "Cinematic"
 * Full-bleed dark hero; section order:
 * Hero → Google trust bar → Book appointment CTA → About → Why choose us →
 * Featured services → Meet our doctors → Smile results → Clinic experience →
 * Gallery → Video testimonials → Google reviews → FAQ → Location / map → Final CTA
 */
export const metadata: Metadata = {
  title: `${site.name} — Dental Clinic in DHA Phase 4, Lahore | ${site.tagline}`,
  description: site.description,
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustBar />
      <AppointmentCta />
      <AboutSection />
      <WhyChooseUs />
      <ServicesSection />
      <DoctorsSection />
      <SmileResults compact />
      <ClinicExperience />
      <GalleryPreview />
      <VideoTestimonials />
      <ReviewsSection />
      <FaqSection />
      <LocationSection />
      <FinalCta />
    </>
  );
}
