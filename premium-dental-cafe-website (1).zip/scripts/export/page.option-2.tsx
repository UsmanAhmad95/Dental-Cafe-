import type { Metadata } from "next";
import { HeroLight } from "@/components/sections/HeroLight";
import { TrustBookBand } from "@/components/sections/TrustBookBand";
import { AboutSection } from "@/components/sections/AboutSection";
import { DoctorsSection } from "@/components/sections/DoctorsSection";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { SmileResults } from "@/components/sections/SmileResults";
import { ClinicExperience } from "@/components/sections/ClinicExperience";
import { FinalCta } from "@/components/sections/CtaBands";
import {
  FaqSection,
  GalleryPreview,
  LocationSection,
  ReviewsSection,
  VideoTestimonials,
} from "@/components/sections/HomeSecondary";
import { site } from "@/content/site";

/**
 * HOMEPAGE — Option 2 "Light Editorial"
 * White editorial hero + strict white / black alternation:
 * White hero → Black trust + booking band → White about → Black doctors →
 * White services → Black why-us → White results → Black testimonials →
 * Cream clinic experience → Black reviews → White gallery → Black FAQ →
 * White location → Black final CTA
 */
export const metadata: Metadata = {
  title: `${site.name} — Dental Clinic in DHA Phase 4, Lahore | ${site.tagline}`,
  description: site.description,
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      <HeroLight />
      <TrustBookBand />
      <AboutSection />
      <DoctorsSection />
      <ServicesSection />
      <WhyChooseUs />
      <SmileResults compact />
      <VideoTestimonials />
      <ClinicExperience />
      <ReviewsSection tone="dark" />
      <GalleryPreview />
      <FaqSection tone="dark" />
      <LocationSection />
      <FinalCta />
    </>
  );
}
