# Dental Cafe — Website · Export __OPTION_NUMBER__ ("__OPTION_NAME__")

**WHERE YOUR SMILE COMES FIRST** · DHA Phase 4, Lahore · +92 332 4679934

This package is a complete, self-contained, production-ready website project. It is one of two
independent exports — each ZIP is a full website on its own and they are never combined:

| Package | Homepage design | |
| --- | --- | --- |
| `PROJECT_EXPORT_01.zip` | **Option 1 — "Cinematic"**: full-bleed dark photographic hero, black trust strip, cream appointment CTA | __IS_01__ |
| `PROJECT_EXPORT_02.zip` | **Option 2 — "Light Editorial"**: white editorial hero with framed image, combined black trust + booking band, strict white/black alternation | __IS_02__ |

Both exports share every inner page, component, animation, transition, asset and the booking backend;
only the homepage composition differs. The temporary "Design preview" strip that linked the two options
during review has been removed, because each package is now a single standalone site.

__OPTION_SUMMARY__

---

## 1. Technology & entry point

| | |
| --- | --- |
| Framework | **Next.js 16** (App Router) · React 19 · TypeScript — a server-rendered application, **not** a static SPA |
| Styling | Tailwind CSS v4 with strict White / Gold / Black design tokens in `src/app/globals.css` |
| Fonts | Self-hosted via npm — `@fontsource/cormorant-garamond`, `@fontsource-variable/manrope` (no external font CDN) |
| Icons | `lucide-react` (npm) + inline SVGs in `src/components/ui/icons.tsx` |
| Backend | Route Handler `POST /api/appointments` + Server Actions for `/admin` · PostgreSQL via Drizzle ORM |
| Node.js | **20.9 or newer** — 22 LTS recommended (`.nvmrc`) · npm 10+ |

### About `index.html`
Next.js does not use a hand-written `index.html`. Pages are React components in `src/app/`, and the
framework generates the HTML: `npm run build` pre-renders the homepage to `.next/server/app/index.html`
(and every other static route to its own `.html`), which the Next.js server — or Vercel's / Netlify's
runtime — serves. **Do not add a root `index.html` or an SPA "catch-all → index.html" rewrite**; it is not
needed and would break routing, the booking API and the admin area.

## 2. Project structure

```
PROJECT_EXPORT_0__OPTION_NUMBER__/
├── README.md                  ← this file
├── CONTENT-GUIDE.md           ← how to edit logo, photos, doctors, services, reviews, gallery, videos, blog
├── package.json · package-lock.json
├── next.config.ts · tsconfig.json · postcss.config.mjs · eslint.config.mjs
├── drizzle.config.ts          ← database tooling (reads DATABASE_URL)
├── drizzle/0000_init.sql      ← portable SQL that creates the tables on any PostgreSQL
├── vercel.json · netlify.toml ← hosting configuration (see §6, §7)
├── Dockerfile · .dockerignore ← for Railway / Render / Fly.io / any VPS (see §8)
├── .env.example               ← copy to .env and fill in
├── .nvmrc · .gitignore
├── public/
│   └── assets/                ← ALL images, organised by type
│       ├── brand/             ← logo.png drop-in location (see README.txt inside)
│       ├── clinic/  services/  gallery/  blog/
│       ├── doctors/  results/  videos/  reviews/   ← drop-in locations with README.txt
└── src/
    ├── app/                   ← routes (file-system routing, see §10)
    │   ├── layout.tsx · globals.css · page.tsx (homepage) · not-found.tsx · sitemap.ts · robots.ts
    │   ├── about/ doctors/[slug]/ services/[slug]/ gallery/ reviews/ blog/[slug]/ contact/ book/
    │   ├── privacy-policy/ terms/ admin/ api/appointments/ api/health/
    ├── components/            ← brand/Logo · layout (Header, Footer, FloatingActions) · sections · doctors ·
    │                             services · reviews · gallery · media (lightbox, videos) · booking · blog · ui · seo
    ├── content/               ← EDITABLE DATA: site.ts, assets.ts, doctors.ts, services.ts, reviews.ts,
    │                             gallery.ts, videos.ts, results.ts, blog.ts, faqs.ts
    ├── db/                    ← schema.ts (Drizzle tables) · index.ts (lazy PostgreSQL client)
    └── lib/                   ← links.ts (WhatsApp / tel / booking URLs) · utils.ts · admin-auth.ts
```

## 3. Install dependencies

```bash
npm ci          # exact versions from package-lock.json (recommended)
# or: npm install
```
The lockfile contains the native binaries for Linux, macOS and Windows.

## 4. Run locally

```bash
cp .env.example .env      # then edit DATABASE_URL and ADMIN_PASSWORD
npx drizzle-kit push      # creates the tables on the database in DATABASE_URL (run once)
npm run dev               # http://localhost:3000
```
- The whole site renders **without** a database. Only the booking API (`/api/appointments`),
  `/admin` and `/api/health` need `DATABASE_URL`.
- Type-check on its own: `npx next typegen && npm run typecheck`

## 5. Build for production

```bash
npm run build     # compiles + type-checks + pre-renders all static routes
npm start         # serves the production build on http://localhost:3000
```
Environment variables must be present at **build time** for `NEXT_PUBLIC_SITE_URL` (it is inlined),
and at **run time** for `DATABASE_URL` and `ADMIN_PASSWORD`.

## 6. Deploy to Vercel (recommended)

1. Push this folder to a Git repository (GitHub / GitLab / Bitbucket):
   ```bash
   git init && git add -A && git commit -m "Dental Cafe website"
   git remote add origin <your-repo-url> && git push -u origin main
   ```
2. Create a PostgreSQL database (e.g. [Neon](https://neon.tech) — free tier is fine to start) and
   copy its connection string.
3. Create the tables once — either
   `DATABASE_URL="postgresql://…" npx drizzle-kit push`
   or paste `drizzle/0000_init.sql` into the provider's SQL editor and run it.
4. Go to <https://vercel.com/new> → **Import** the repository → Framework preset *Next.js* is detected
   automatically (`vercel.json` only pins it) → add the environment variables from §9 → **Deploy**.
   You receive `https://<project>.vercel.app` immediately.
5. Custom domain: *Project → Settings → Domains* → add your domain and set the DNS records shown.
   Then set `NEXT_PUBLIC_SITE_URL` to that domain and redeploy.

CLI alternative: `npm i -g vercel && vercel login && vercel --prod`

> A clinic website is commercial use — use a Vercel **Pro** plan (or Netlify / Docker below).

## 7. Deploy to Netlify

1. Push to Git as in §6 step 1 and create the database / tables as in §6 steps 2–3
   (Netlify also offers a built-in Neon integration under *Extensions → Neon*).
2. <https://app.netlify.com> → **Add new site → Import an existing project** → choose the repository.
   Build settings are read from the included `netlify.toml`
   (build command `npm run build`, publish directory `.next`, Node 22, official `@netlify/plugin-nextjs` runtime).
3. *Site configuration → Environment variables* → add the variables from §9 → **Deploy site**.
4. *Domain management* → add your custom domain.

CLI alternative: `npm i -g netlify-cli && netlify login && netlify init && netlify deploy --build --prod`

The Netlify Next.js runtime provides server rendering, the API route, server actions and image
optimisation. **No `_redirects` file or SPA fallback is needed — do not add one.**

## 8. Other hosts (Docker: Railway, Render, Fly.io, DigitalOcean, VPS)

```bash
docker build --build-arg NEXT_PUBLIC_SITE_URL=https://www.your-domain.com -t dental-cafe .
docker run -d --restart=always -p 3000:3000 \
  -e DATABASE_URL="postgresql://…?sslmode=require" \
  -e ADMIN_PASSWORD="long-random-string" \
  -e NEXT_PUBLIC_SITE_URL="https://www.your-domain.com" \
  dental-cafe
```
Railway / Render detect the `Dockerfile` automatically. Behind Nginx/Caddy, proxy **all** paths to the
Node server:
```nginx
location / {
  proxy_pass http://127.0.0.1:3000;
  proxy_set_header Host $host;
  proxy_set_header X-Forwarded-Proto $scheme;
}
```

## 9. Environment variables

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | for booking API, `/admin`, `/api/health` | PostgreSQL connection string (Neon / Supabase / Railway / Render / RDS / local). Remote providers: keep `?sslmode=require`. |
| `ADMIN_PASSWORD` | for `/admin` | Password for the appointment-requests dashboard. **Change it before going live.** |
| `NEXT_PUBLIC_SITE_URL` | recommended | Public URL used for SEO metadata, Open Graph, `sitemap.xml`, `robots.txt`. Auto-detected on Vercel and Netlify if omitted. |

Template: `.env.example`. Never commit `.env` (already in `.gitignore`).

## 10. Routing configuration

Routing is file-system based under `src/app/` and handled by the Next.js server — **no SPA rewrite rules
are required**. `vercel.json` (framework hint) and `netlify.toml` (build + runtime) are included and are
all the configuration those platforms need. Unknown URLs render the branded 404 page (`src/app/not-found.tsx`).

| Route | Page |
| --- | --- |
| `/` | Homepage (Option __OPTION_NUMBER__) |
| `/about` | About Dental Cafe |
| `/doctors` · `/doctors/[slug]` | Doctor directory · 5 profiles (`dr-usama`, `dr-javeriya-shahid`, `dr-marleen-mahiqa`, `dr-abdullah`, `dr-umair-bhalli`) |
| `/services` · `/services/[slug]` | Services · 3 published treatment pages (`dental-implants`, `orthodontics-braces`, `general-dentistry`) — drafts in `src/content/services.ts` publish by flipping `published: true` |
| `/gallery` | Gallery with category filters, lightbox, videos, smile results |
| `/reviews` | Google reviews |
| `/blog` · `/blog/[slug]` | Blog index · 6 articles with related posts |
| `/contact` | Contact, map, directions |
| `/book` | 9-step appointment request wizard |
| `/privacy-policy` · `/terms` | Legal pages |
| `/admin` | Appointment requests dashboard (password) |
| `/api/appointments` (POST) · `/api/health` | Booking API · health check (`{"ok":true}` when the database is reachable) |
| `/sitemap.xml` · `/robots.txt` | Generated from `site.ts` |

## 11. External references (intentionally external)

Everything visual — images, fonts, icons, CSS, JavaScript — is bundled in this package and served from
your own domain. The only external references are live third-party services, which cannot be bundled:

| URL | Where it is set | Purpose |
| --- | --- | --- |
| `https://www.google.com/maps?q=Dental+Cafe+DHA+Phase+4+Lahore&output=embed` | `src/content/site.ts` → `location.mapsEmbedUrl` | Map iframe on Home & Contact (needs internet access) |
| `https://maps.app.goo.gl/wa2MZhBiKGsY69L68` | `site.ts` → `location.mapsUrl` | "Get Directions" and "Read on Google" links |
| `https://wa.me/923324679934?text=…` | generated by `src/lib/links.ts` | Every WhatsApp button (pre-filled message) |
| `https://www.instagram.com/dentalcafe.ju/` · `https://www.facebook.com/dentalcafe.drju/photos` | `site.ts` → `social` | Social icons |
| `https://www.youtube-nocookie.com/embed/{id}` | `src/components/media/MediaLightbox.tsx` | Only used if a video in `src/content/videos.ts` is given a `youtubeId` (none by default) |

No preview, sandbox or session URLs exist anywhere in this package.

## 12. Content, images & logo (no rebuild of the design needed)

See **`CONTENT-GUIDE.md`**. In short:
- Official logo → `public/assets/brand/logo.png`, then set `brandAssets.logo.status = "real"` in `src/content/assets.ts`.
  One `<Logo />` component feeds header, footer and mobile navigation; proportions are always preserved.
- Doctor photos → `public/assets/doctors/doctor-*.jpg` (original files only) → set `status: "real"`.
- Images marked `status: "concept"` in `src/content/assets.ts` are neutral stand-ins to be replaced with real clinic photography at the same file path.
- Anything shown as `[ADD …]` is an intentional placeholder for information not yet supplied.

## 13. Admin dashboard

`/admin` lists every appointment request (reference, patient, phone/WhatsApp, treatment, doctor,
preferred date/time, message) and lets you set its status (*new → contacted → confirmed → closed*).
A request is **not** a confirmed appointment; the clinic confirms by phone or WhatsApp.
If the database is ever unreachable, the booking form automatically offers a one-tap
"Send this request on WhatsApp instead" fallback with all details pre-filled.

## 14. Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| `/api/health` returns `{"ok":false}` | `DATABASE_URL` missing/unreachable, or tables not created → `npx drizzle-kit push` |
| Booking form shows the WhatsApp fallback | same as above |
| Map area is blank | the Google Maps iframe needs internet access / is blocked by an ad-blocker |
| Admin says "not configured" | set `ADMIN_PASSWORD` in the hosting environment and redeploy |

## 15. Verification performed on this exact package before it was zipped

`npm ci` (clean install from the lockfile) → `npx next typegen` → `tsc --noEmit` → `next build` →
a production server was started and **every route in §10 plus sample assets returned HTTP 200**, the
booking API stored and returned a test request, `/option-2` returned 404 (proving the packages are
separate), the homepage was confirmed to be Option __OPTION_NUMBER__, and the whole tree was scanned for
preview/sandbox hostnames (none found).
