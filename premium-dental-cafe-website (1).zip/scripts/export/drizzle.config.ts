import "dotenv/config";
import { defineConfig } from "drizzle-kit";

/**
 * Drizzle Kit configuration — reads DATABASE_URL from .env / the environment.
 *
 *   npx drizzle-kit push       → create / update the tables on that database
 *   npx drizzle-kit generate   → regenerate SQL migrations into ./drizzle
 *
 * Alternatively run drizzle/0000_init.sql in your database provider's SQL console.
 */
export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: {
    url: process.env.DATABASE_URL ?? "postgresql://postgres:postgres@127.0.0.1:5432/app_db",
  },
});
