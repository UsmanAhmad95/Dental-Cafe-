# Dental Cafe — Content & Asset Editing Guide

Everything editable lives in **`src/content/`** and **`public/assets/`**. No component code needs to change
to update the logo, photos, doctors, services, reviews, gallery, videos, blog or contact details.

| What | Where |
| --- | --- |
| Brand logo | Drop `logo.png` in `public/assets/brand/` → set `brandAssets.logo.status = "real"` in `src/content/assets.ts` |
| All images (hero, clinic, doctors, services, gallery, results, video thumbs, blog) | `src/content/assets.ts` (central registry) + files in `public/assets/**` |
| Hero text | `src/components/sections/Hero.tsx` → `heroContent` |
| Doctors (names, qualifications, bios, specializations, contacts, photos) | `src/content/doctors.ts` |
| Services (publish / unpublish, copy, FAQs, doctors) | `src/content/services.ts` (`published: true/false`) |
| Google reviews | `src/content/reviews.ts` (copy names & text exactly from Google) |
| Gallery | `src/content/gallery.ts` |
| Videos & video testimonials | `src/content/videos.ts` (`src` or `youtubeId`) |
| Smile results (before/after) | `src/content/results.ts` + `public/assets/results/` |
| Blog posts | `src/content/blog.ts` |
| FAQs | `src/content/faqs.ts` |
| Phone, WhatsApp, email, hours, socials, Google Maps, nav | `src/content/site.ts` |
| Colours, radius, buttons, cards | `src/app/globals.css` (`@theme` tokens) |

## Image rules
- Replace a file at the **same path** listed in `src/content/assets.ts` — every place that uses it updates.
- `status: "real"` = genuine clinic photo · `"concept"` = temporary stand-in imagery · `"missing"` = shows a labelled placeholder.
- Doctor photos: **original files only** — never AI-altered. Portrait 4:5 recommended; faces are top-aligned, never cropped awkwardly.
- Before/after: only real, consented patient results.

## Placeholders
Anything in `[BRACKETS]` (e.g. `[ADD DOCTOR BIO]`, `[ADD OPENING HOURS]`, `[ADD CLINIC EMAIL]`) is an intentional
placeholder for information not yet supplied. Search the codebase for `[ADD` to find them all.

## Booking backend
- Requests are stored in PostgreSQL (`appointments` table, `src/db/schema.ts`) via `POST /api/appointments`.
- View / update requests at **`/admin`** (set `ADMIN_PASSWORD` in `.env`).
- A request is *not* a confirmed booking; the clinic confirms by phone/WhatsApp (+92 332 4679934).

## Future CMS / Supabase
The content files are plain typed data (`Doctor`, `Service`, `Review`, `GalleryItem`, `VideoItem`, `BlogPost`),
so they can be swapped for database queries or a headless CMS without changing the UI components.
