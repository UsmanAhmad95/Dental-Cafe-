"use client";

import Image from "next/image";
import { useCallback, useEffect } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";

export type LightboxMedia =
  | { kind: "image"; src: string; alt: string; caption?: string }
  | { kind: "video"; src?: string | null; youtubeId?: string | null; title: string; caption?: string };

interface Props {
  items: LightboxMedia[];
  index: number | null;
  onClose: () => void;
  onNavigate: (next: number) => void;
}

/** Elegant, keyboard-accessible lightbox for images and videos (no autoplay with sound). */
export function MediaLightbox({ items, index, onClose, onNavigate }: Props) {
  const open = index !== null && index >= 0 && index < items.length;
  const item = open ? items[index] : null;

  const prev = useCallback(() => {
    if (index === null) return;
    onNavigate((index - 1 + items.length) % items.length);
  }, [index, items.length, onNavigate]);

  const next = useCallback(() => {
    if (index === null) return;
    onNavigate((index + 1) % items.length);
  }, [index, items.length, onNavigate]);

  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose, prev, next]);

  if (!open || !item) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={item.kind === "image" ? item.alt : item.title}
      className="fixed inset-0 z-[80] flex items-center justify-center bg-ink/95 p-4 backdrop-blur-md sm:p-8"
      onClick={onClose}
    >
      <button
        type="button"
        onClick={onClose}
        aria-label="Close"
        className="absolute top-4 right-4 inline-flex h-12 w-12 items-center justify-center rounded-full border border-white/20 text-white transition-colors hover:border-gold hover:text-gold"
      >
        <X className="h-5 w-5" />
      </button>

      {items.length > 1 ? (
        <>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); prev(); }}
            aria-label="Previous"
            className="absolute top-1/2 left-3 hidden h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-white/20 text-white transition-colors hover:border-gold hover:text-gold sm:inline-flex"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); next(); }}
            aria-label="Next"
            className="absolute top-1/2 right-3 hidden h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-white/20 text-white transition-colors hover:border-gold hover:text-gold sm:inline-flex"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </>
      ) : null}

      <figure className="w-full max-w-5xl" onClick={(e) => e.stopPropagation()}>
        <div className="relative aspect-[4/3] w-full overflow-hidden rounded-brand border border-white/10 bg-ink sm:aspect-[16/10]">
          {item.kind === "image" ? (
            <Image src={item.src} alt={item.alt} fill sizes="100vw" className="object-contain" />
          ) : item.youtubeId ? (
            <iframe
              title={item.title}
              src={`https://www.youtube-nocookie.com/embed/${item.youtubeId}?rel=0`}
              className="absolute inset-0 h-full w-full"
              allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : item.src ? (
            <video src={item.src} controls playsInline preload="metadata" className="absolute inset-0 h-full w-full object-contain">
              Your browser does not support the video tag.
            </video>
          ) : (
            <div className="absolute inset-0 grid place-items-center font-mono text-sm text-gold">[ADD VIDEO]</div>
          )}
        </div>
        {item.caption ? (
          <figcaption className="mt-4 text-center text-sm tracking-wide text-white/70">{item.caption}</figcaption>
        ) : null}
        <p className="mt-2 text-center font-mono text-[11px] text-white/40">
          {index !== null ? `${index + 1} / ${items.length}` : ""}
        </p>
      </figure>
    </div>
  );
}
