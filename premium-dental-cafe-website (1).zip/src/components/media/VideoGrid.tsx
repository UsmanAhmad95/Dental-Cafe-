"use client";

import { useState } from "react";
import { Play } from "lucide-react";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { getAsset } from "@/content/assets";
import type { VideoItem } from "@/content/videos";
import { cn } from "@/lib/utils";
import { MediaLightbox, type LightboxMedia } from "./MediaLightbox";

interface Props {
  videos: VideoItem[];
  tone?: "light" | "dark";
  ctaLabel?: string;
}

/** Video tiles with elegant thumbnails. Placeholders render as [ADD VIDEO]. */
export function VideoGrid({ videos, tone = "dark", ctaLabel = "Watch Video" }: Props) {
  const [active, setActive] = useState<number | null>(null);
  const playable = videos.filter((v) => !v.placeholder && (v.src || v.youtubeId));
  const media: LightboxMedia[] = playable.map((v) => ({
    kind: "video",
    src: v.src,
    youtubeId: v.youtubeId,
    title: v.title,
    caption: v.description ?? v.category,
  }));

  return (
    <>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((v, i) => {
          const thumb = getAsset(v.thumbnail);
          const isPlayable = !v.placeholder && (v.src || v.youtubeId);
          const playIndex = playable.findIndex((p) => p.id === v.id);
          const dark = tone === "dark";
          return (
            <Reveal key={v.id} delay={i * 80}>
              <article className={cn("group flex h-full flex-col overflow-hidden", dark ? "card-dark" : "card")}>
                <div className="relative">
                  <Picture
                    asset={v.thumbnail}
                    className="aspect-video w-full"
                    imgClassName="img-zoom"
                    tone={tone}
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                  />
                  {thumb.status !== "missing" ? (
                    <span className="pointer-events-none absolute inset-0 grid place-items-center">
                      <span className="grid h-14 w-14 place-items-center rounded-full border border-gold bg-ink/70 text-gold backdrop-blur-sm transition-transform duration-500 group-hover:scale-105">
                        <Play className="ml-0.5 h-5 w-5 fill-current" />
                      </span>
                    </span>
                  ) : null}
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <p className="text-[11px] font-semibold tracking-[0.26em] text-gold uppercase">{v.category}</p>
                  <h3 className={cn("mt-2 font-display text-2xl leading-tight", dark ? "text-white" : "text-ink")}>{v.title}</h3>
                  {v.description ? (
                    <p className={cn("mt-2 text-sm leading-6", dark ? "text-white/60" : "text-stone")}>{v.description}</p>
                  ) : null}
                  <div className="mt-auto pt-5">
                    {isPlayable ? (
                      <button
                        type="button"
                        onClick={() => setActive(playIndex)}
                        className={cn("btn btn-sm", dark ? "btn-gold" : "btn-primary")}
                      >
                        <Play className="h-3.5 w-3.5 fill-current" /> {ctaLabel}
                      </button>
                    ) : (
                      <span className={cn("inline-flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] uppercase", dark ? "text-white/40" : "text-stone")}>
                        <Play className="h-3.5 w-3.5" /> {ctaLabel} · coming soon
                      </span>
                    )}
                  </div>
                </div>
              </article>
            </Reveal>
          );
        })}
      </div>
      <MediaLightbox items={media} index={active} onClose={() => setActive(null)} onNavigate={setActive} />
    </>
  );
}
