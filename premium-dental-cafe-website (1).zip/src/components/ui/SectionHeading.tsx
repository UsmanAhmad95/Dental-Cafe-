import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Reveal } from "./Reveal";

interface SectionHeadingProps {
  eyebrow?: string;
  title: ReactNode;
  description?: ReactNode;
  align?: "left" | "center";
  tone?: "light" | "dark";
  size?: "md" | "lg";
  className?: string;
  as?: "h1" | "h2";
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  tone = "light",
  size = "md",
  className,
  as: Tag = "h2",
}: SectionHeadingProps) {
  const dark = tone === "dark";
  return (
    <Reveal className={cn(align === "center" && "mx-auto text-center", "max-w-3xl", className)}>
      {eyebrow ? (
        <p className={cn("eyebrow", align === "center" && "eyebrow-plain justify-center")}>{eyebrow}</p>
      ) : null}
      <Tag
        className={cn(
          "mt-5",
          size === "lg" ? "display-lg" : "display-md",
          dark ? "text-white" : "text-ink",
        )}
      >
        {title}
      </Tag>
      {description ? (
        <div className={cn("mt-6 text-[17px] leading-8", dark ? "text-white/70" : "text-ink/70")}>
          {description}
        </div>
      ) : null}
    </Reveal>
  );
}

export function Placeholder({ label, className }: { label: string; className?: string }) {
  return <span className={cn("placeholder-tag", className)}>{label}</span>;
}
