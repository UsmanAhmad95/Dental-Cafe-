import Image from "next/image";
import { getAsset, type ImageAssetKey } from "@/content/assets";
import { cn } from "@/lib/utils";

interface PictureProps {
  asset: ImageAssetKey;
  /** Container classes — give it a size/aspect ratio (image uses `fill`). */
  className?: string;
  imgClassName?: string;
  sizes?: string;
  priority?: boolean;
  /** Override the placeholder label for "missing" assets. */
  label?: string;
  /** Show a discreet "concept imagery" tag on stand-in images. */
  showConceptTag?: boolean;
  /** Placeholder tone */
  tone?: "light" | "dark";
}

/**
 * Asset-aware image. Reads the central registry and renders:
 *  - the real/concept image via next/image, or
 *  - a clearly labelled placeholder frame when nothing is supplied yet.
 */
export function Picture({
  asset,
  className,
  imgClassName,
  sizes = "(min-width: 1024px) 50vw, 100vw",
  priority,
  label,
  showConceptTag,
  tone = "light",
}: PictureProps) {
  const a = getAsset(asset);

  if (a.status === "missing") {
    return (
      <AssetPlaceholder
        label={label ?? a.placeholderLabel ?? "[ADD IMAGE]"}
        hint={a.src}
        className={className}
        tone={tone}
      />
    );
  }

  return (
    <div className={cn("relative overflow-hidden", className)}>
      <Image
        src={a.src}
        alt={a.alt}
        fill
        sizes={sizes}
        priority={priority}
        className={cn("object-cover", imgClassName)}
      />
      {showConceptTag && a.status === "concept" ? (
        <span className="absolute bottom-3 left-3 rounded-brand bg-ink/70 px-2 py-1 font-mono text-[10px] tracking-wide text-white/80 backdrop-blur-sm">
          concept image · replace with clinic photo
        </span>
      ) : null}
    </div>
  );
}

export function AssetPlaceholder({
  label,
  hint,
  className,
  tone = "light",
}: {
  label: string;
  hint?: string;
  className?: string;
  tone?: "light" | "dark";
}) {
  return (
    <div
      role="img"
      aria-label={`${label} placeholder`}
      className={cn(
        "relative flex flex-col items-center justify-center gap-2 overflow-hidden rounded-brand border border-dashed p-4 text-center",
        tone === "dark"
          ? "border-gold/50 bg-ink-muted text-white"
          : "border-gold/70 bg-cream text-ink",
        className,
      )}
    >
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(ellipse at 50% 30%, rgba(198,161,91,0.16) 0%, rgba(198,161,91,0) 60%)",
        }}
      />
      <span className="relative font-mono text-[11px] tracking-[0.18em] text-gold-deep">{label}</span>
      {hint ? (
        <span className={cn("relative font-mono text-[10px] break-all", tone === "dark" ? "text-white/45" : "text-stone/70")}>
          {hint}
        </span>
      ) : null}
    </div>
  );
}
