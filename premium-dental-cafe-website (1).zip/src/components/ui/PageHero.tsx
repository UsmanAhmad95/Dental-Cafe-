import Link from "next/link";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import type { ImageAssetKey } from "@/content/assets";
import { cn } from "@/lib/utils";

interface Crumb {
  label: string;
  href?: string;
}

interface PageHeroProps {
  eyebrow?: string;
  title: ReactNode;
  description?: ReactNode;
  crumbs?: Crumb[];
  image?: ImageAssetKey;
  tone?: "dark" | "light";
  children?: ReactNode;
  compact?: boolean;
}

/** Inner-page hero. Dark (image + overlay) or light editorial variant. */
export function PageHero({ eyebrow, title, description, crumbs, image, tone = "dark", children, compact }: PageHeroProps) {
  const dark = tone === "dark";
  return (
    <section className={cn("relative isolate overflow-hidden", dark ? "bg-ink text-white" : "bg-white text-ink")}>
      {dark && image ? (
        <div className="absolute inset-0 -z-10">
          <Picture asset={image} className="h-full w-full" imgClassName="object-cover" sizes="100vw" priority />
          <div className="absolute inset-0 bg-gradient-to-r from-ink/95 via-ink/80 to-ink/50" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent" />
        </div>
      ) : null}
      <div className={cn("container-x", compact ? "py-16 lg:py-20" : "py-20 lg:py-28")}>
        {crumbs?.length ? (
          <nav aria-label="Breadcrumb" className="mb-8">
            <ol className={cn("flex flex-wrap items-center gap-2 text-[11px] tracking-[0.2em] uppercase", dark ? "text-white/55" : "text-stone")}>
              <li><Link href="/" className="hover:text-gold">Home</Link></li>
              {crumbs.map((c) => (
                <li key={c.label} className="flex items-center gap-2">
                  <ChevronRight className="h-3 w-3 text-gold" />
                  {c.href ? <Link href={c.href} className="hover:text-gold">{c.label}</Link> : <span aria-current="page">{c.label}</span>}
                </li>
              ))}
            </ol>
          </nav>
        ) : null}
        <div className="max-w-3xl">
          {eyebrow ? (
            <Reveal><p className="eyebrow">{eyebrow}</p></Reveal>
          ) : null}
          <Reveal delay={100}>
            <h1 className={cn("mt-5 display-xl", dark ? "text-white" : "text-ink")}>{title}</h1>
          </Reveal>
          {description ? (
            <Reveal delay={200}>
              <div className={cn("mt-7 max-w-2xl text-lg leading-8", dark ? "text-white/72" : "text-ink/70")}>{description}</div>
            </Reveal>
          ) : null}
          {children ? <Reveal delay={300}><div className="mt-9">{children}</div></Reveal> : null}
        </div>
      </div>
      {dark ? <div className="gold-line opacity-70" /> : null}
    </section>
  );
}
