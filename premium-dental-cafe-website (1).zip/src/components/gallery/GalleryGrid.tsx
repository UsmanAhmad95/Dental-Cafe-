"use client";

import { useMemo, useState } from "react";
import { Play, ZoomIn } from "lucide-react";
import { MediaLightbox, type LightboxMedia } from "@/components/media/MediaLightbox";
import { Picture } from "@/components/ui/Picture";
import { getAsset } from "@/content/assets";
import { galleryCategories, type GalleryCategory, type GalleryItem } from "@/content/gallery";
import { getVideo } from "@/content/videos";
import { cn } from "@/lib/utils";

interface Props {
  items: GalleryItem[];
  /** Show category filter chips */
  filters?: boolean;
  /** Editorial layout with spans (desktop) */
  editorial?: boolean;
}

export function GalleryGrid({ items, filters = true, editorial = true }: Props) {
  const [category, setCategory] = useState<"All" | GalleryCategory>("All");
  const [active, setActive] = useState<number | null>(null);

  const visible = useMemo(
    () => (category === "All" ? items : items.filter((i) => i.category === category)),
    [items, category],
  );

  // Only openable media goes into the lightbox (real/concept images, playable videos)
  const openable = useMemo(() => {
    const list: { item: GalleryItem; media: LightboxMedia }[] = [];
    for (const item of visible) {
      if (item.kind === "image" && item.asset) {
        const a = getAsset(item.asset);
        if (a.status !== "missing") list.push({ item, media: { kind: "image", src: a.src, alt: a.alt, caption: item.caption } });
      } else if (item.kind === "video" && item.videoId) {
        const v = getVideo(item.videoId);
        if (v && !v.placeholder && (v.src || v.youtubeId)) {
          list.push({ item, media: { kind: "video", src: v.src, youtubeId: v.youtubeId, title: v.title, caption: item.caption } });
        }
      }
    }
    return list;
  }, [visible]);

  const openIndexFor = (id: string) => openable.findIndex((o) => o.item.id === id);

  return (
    <div>
      {filters ? (
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter gallery by category">
          {(["All", ...galleryCategories] as const).map((c) => (
            <button key={c} type="button" className="chip" aria-pressed={category === c} onClick={() => setCategory(c)}>
              {c}
            </button>
          ))}
        </div>
      ) : null}

      <ul className={cn("mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2", editorial ? "lg:grid-cols-4 lg:auto-rows-[240px]" : "lg:grid-cols-3")}>
        {visible.map((item) => {
          const idx = openIndexFor(item.id);
          const clickable = idx >= 0;
          const spanClass = editorial
            ? item.span === "wide" ? "lg:col-span-2" : item.span === "tall" ? "lg:row-span-2" : ""
            : "";

          const video = item.kind === "video" && item.videoId ? getVideo(item.videoId) : null;
          const thumbKey = item.kind === "image" ? item.asset : video?.thumbnail;

          return (
            <li key={item.id} className={cn("min-h-[240px]", spanClass)}>
              <button
                type="button"
                disabled={!clickable}
                onClick={() => clickable && setActive(idx)}
                className="group relative block h-full w-full overflow-hidden rounded-brand text-left disabled:cursor-default"
                aria-label={clickable ? `Open ${item.caption}` : `${item.caption} — not yet available`}
              >
                {thumbKey ? (
                  <Picture asset={thumbKey} className="h-full min-h-[240px] w-full rounded-brand" imgClassName="img-zoom" sizes="(min-width:1024px) 25vw, (min-width:640px) 50vw, 100vw" />
                ) : null}
                <span className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between bg-gradient-to-t from-ink/80 to-transparent p-4 pt-12 text-white">
                  <span>
                    <span className="block text-[10px] font-semibold tracking-[0.24em] text-gold uppercase">{item.category}</span>
                    <span className="mt-0.5 block text-sm">{item.caption}</span>
                  </span>
                  {clickable ? (
                    <span className="grid h-9 w-9 place-items-center rounded-full border border-gold/60 bg-ink/60 text-gold opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                      {item.kind === "video" ? <Play className="h-4 w-4 fill-current" /> : <ZoomIn className="h-4 w-4" />}
                    </span>
                  ) : null}
                </span>
              </button>
            </li>
          );
        })}
      </ul>

      {visible.length === 0 ? (
        <p className="mt-10 text-center text-sm text-stone">No items in this category yet.</p>
      ) : null}

      <MediaLightbox items={openable.map((o) => o.media)} index={active} onClose={() => setActive(null)} onNavigate={setActive} />
    </div>
  );
}
