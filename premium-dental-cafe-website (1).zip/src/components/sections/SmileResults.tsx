import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { getDoctor } from "@/content/doctors";
import { resultCases } from "@/content/results";
import { isPlaceholder } from "@/lib/utils";

export function SmileResults({ compact = false }: { compact?: boolean }) {
  const cases = compact ? resultCases.slice(0, 3) : resultCases;
  return (
    <section className="bg-white">
      <div className="container-x py-24 lg:py-32">
        <SectionHeading
          eyebrow="Smile Results"
          title="Before & after, shared with consent"
          description="Genuine Dental Cafe patient results only. Each case notes the treatment type and, where available, a short description."
        />
        <div className="mt-14 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
          {cases.map((c, i) => {
            const doctor = c.doctorSlug ? getDoctor(c.doctorSlug) : null;
            return (
              <Reveal key={c.id} delay={i * 90}>
                <article className="card overflow-hidden">
                  <div className="grid grid-cols-2 gap-px bg-ink/8">
                    <figure className="relative bg-white">
                      <Picture asset={c.before} className="aspect-[4/5] w-full rounded-none" sizes="25vw" />
                      <figcaption className="absolute top-3 left-3 rounded-brand bg-ink/80 px-2.5 py-1 text-[10px] font-semibold tracking-[0.22em] text-white uppercase backdrop-blur-sm">
                        Before
                      </figcaption>
                    </figure>
                    <figure className="relative bg-white">
                      <Picture asset={c.after} className="aspect-[4/5] w-full rounded-none" sizes="25vw" />
                      <figcaption className="absolute top-3 left-3 rounded-brand bg-gold px-2.5 py-1 text-[10px] font-semibold tracking-[0.22em] text-ink uppercase">
                        After
                      </figcaption>
                    </figure>
                  </div>
                  <div className="p-6">
                    <p className="text-[11px] font-semibold tracking-[0.26em] text-gold uppercase">Treatment</p>
                    <h3 className={isPlaceholder(c.treatment) ? "placeholder-tag mt-2" : "mt-1 font-display text-2xl text-ink"}>
                      {c.treatment}
                    </h3>
                    <p className="mt-2 text-sm leading-6 text-stone">
                      {c.description ?? <span className="placeholder-tag">[ADD CASE DESCRIPTION]</span>}
                    </p>
                    {doctor ? <p className="mt-3 text-xs tracking-wide text-stone">Care by {doctor.name}</p> : null}
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
