import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { DoctorCard } from "@/components/doctors/DoctorCard";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { sortedDoctors } from "@/content/doctors";

export function DoctorsSection() {
  const featured = sortedDoctors.filter((d) => d.featured);
  return (
    <section className="bg-ink text-white">
      <div className="container-x py-24 lg:py-32">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            tone="dark"
            eyebrow="Meet Our Doctors"
            title="A professional team you can trust"
            description="Authentic profiles of the dentists who care for you at Dental Cafe."
          />
          <Reveal delay={100}>
            <Link href="/doctors" className="btn btn-outline-light">
              All Doctors <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {featured.map((d, i) => (
            <Reveal key={d.slug} delay={i * 80} className="h-full">
              <DoctorCard doctor={d} tone="dark" />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
