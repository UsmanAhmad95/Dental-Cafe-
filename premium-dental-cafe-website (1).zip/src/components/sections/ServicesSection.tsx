import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { ServiceCard } from "@/components/services/ServiceCard";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { WhatsAppIcon } from "@/components/ui/icons";
import { featuredServices } from "@/content/services";
import { whatsappLink } from "@/lib/links";

export function ServicesSection() {
  return (
    <section className="bg-white">
      <div className="container-x py-24 lg:py-32">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="Featured Services"
            title="Treatments delivered with precision and care"
            description="Explore our confirmed treatments. For anything else, our team is a message away."
          />
          <Reveal delay={100}>
            <Link href="/services" className="btn btn-secondary">
              View All Services <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
          {featuredServices.map((s, i) => (
            <Reveal key={s.slug} delay={i * 90} className="h-full">
              <ServiceCard service={s} index={i} />
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <div className="mt-10 flex flex-col items-start justify-between gap-5 rounded-brand border border-gold/40 bg-cream px-7 py-6 sm:flex-row sm:items-center">
            <p className="text-[15px] leading-7 text-ink/75">
              Looking for a specific treatment? Ask our team about availability.
            </p>
            <a href={whatsappLink("Hello Dental Cafe, I would like to ask about a treatment.")} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm">
              <WhatsAppIcon className="h-4 w-4" /> Ask on WhatsApp
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
