import { HeartHandshake, Users, Armchair, Building2, ShieldCheck, ClipboardList } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";

export const whyChooseUs = [
  { icon: HeartHandshake, title: "Patient-Centered Care", text: "Every decision starts with listening — your concerns, goals and comfort guide the plan." },
  { icon: Users, title: "Professional Team", text: "A team of dental professionals including specialist-qualified orthodontic and implant expertise." },
  { icon: Armchair, title: "Comfort-Focused Experience", text: "A gentle, unhurried approach for patients of all ages, including those who feel anxious." },
  { icon: Building2, title: "Modern Environment", text: "A clean, calm clinic designed to make each visit feel considered and reassuring." },
  { icon: ShieldCheck, title: "Hygiene & Sterilization", text: "Strict hygiene protocols and sterilized instruments for every patient, every time." },
  { icon: ClipboardList, title: "Personalized Treatment Planning", text: "Clear explanations and options tailored to you — never one-size-fits-all." },
];

export function WhyChooseUs() {
  return (
    <section className="bg-ink text-white">
      <div className="container-x py-24 lg:py-32">
        <SectionHeading
          tone="dark"
          eyebrow="Why Choose Us"
          title="Care that feels considered, from the first hello"
          description="The details that shape a better dental experience — and the standards we hold ourselves to."
        />
        <ul className="mt-16 grid gap-px overflow-hidden rounded-brand border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
          {whyChooseUs.map(({ icon: Icon, title, text }, i) => (
            <li key={title} className="bg-ink">
              <Reveal delay={i * 70} className="h-full">
                <div className="group flex h-full flex-col p-8 transition-colors duration-500 hover:bg-ink-soft lg:p-10">
                  <span className="grid h-12 w-12 place-items-center rounded-full border border-gold/50 text-gold transition-colors duration-500 group-hover:bg-gold group-hover:text-ink">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-7 font-display text-2xl leading-tight">{title}</h3>
                  <p className="mt-3 text-[15px] leading-7 text-white/65">{text}</p>
                  <span className="mt-8 h-px w-10 bg-gold/50 transition-all duration-500 group-hover:w-16 group-hover:bg-gold" />
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
