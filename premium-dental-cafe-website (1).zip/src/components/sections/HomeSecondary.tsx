import Link from "next/link";
import { ArrowRight, ArrowUpRight, MapPin, Phone, Plus } from "lucide-react";
import { GalleryGrid } from "@/components/gallery/GalleryGrid";
import { VideoGrid } from "@/components/media/VideoGrid";
import { ReviewCard, Stars } from "@/components/reviews/ReviewCard";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading, Placeholder } from "@/components/ui/SectionHeading";
import { GoogleIcon, WhatsAppIcon } from "@/components/ui/icons";
import { faqs, type Faq } from "@/content/faqs";
import { galleryPreview } from "@/content/gallery";
import { featuredReviews, reviewSummary } from "@/content/reviews";
import { PLACEHOLDERS, site } from "@/content/site";
import { testimonialVideos } from "@/content/videos";
import { telLink, whatsappLink } from "@/lib/links";

/* ------------------------------ GALLERY PREVIEW ------------------------------ */
export function GalleryPreview() {
  return (
    <section className="bg-white">
      <div className="container-x py-24 lg:py-32">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading eyebrow="Gallery" title="A closer look at Dental Cafe" />
          <Reveal delay={100}>
            <Link href="/gallery" className="btn btn-secondary">
              View Full Gallery <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>
        <Reveal delay={120}>
          <GalleryGrid items={galleryPreview} filters={false} />
        </Reveal>
      </div>
    </section>
  );
}

/* ---------------------------- VIDEO TESTIMONIALS ----------------------------- */
export function VideoTestimonials() {
  return (
    <section className="bg-ink text-white">
      <div className="container-x py-24 lg:py-32">
        <SectionHeading
          tone="dark"
          eyebrow="Video Testimonials"
          title={<span className="uppercase">Real patient experiences</span>}
          description="Genuine, patient-provided testimonial videos. Videos never autoplay with sound."
        />
        <div className="mt-14">
          <VideoGrid videos={testimonialVideos} tone="dark" ctaLabel="Watch Testimonial" />
        </div>
      </div>
    </section>
  );
}

/* --------------------------------- REVIEWS ----------------------------------- */
export function ReviewsSection({
  showAll = false,
  heading = true,
  tone = "light",
}: {
  showAll?: boolean;
  heading?: boolean;
  tone?: "light" | "dark";
}) {
  const list = showAll ? featuredReviews : featuredReviews.slice(0, 3);
  const dark = tone === "dark";
  return (
    <section className={dark ? "bg-ink text-white" : "bg-white"}>
      <div className="container-x py-24 lg:py-32">
        {heading ? (
          <SectionHeading
            tone={tone}
            eyebrow="Google Reviews"
            title="Trusted by patients across Lahore"
            align="center"
          />
        ) : null}

        <Reveal delay={80}>
          <div
            className={`mx-auto mt-12 grid max-w-4xl items-center gap-6 rounded-brand p-8 text-white sm:grid-cols-[auto_1fr_auto] sm:p-10 ${
              dark ? "border border-gold/40 bg-ink-soft" : "bg-ink"
            }`}
          >
            <div className="text-center sm:text-left">
              <p className="font-display text-7xl leading-none text-gold">{reviewSummary.rating}</p>
              <Stars value={5} className="mt-3 justify-center sm:justify-start" />
            </div>
            <div className="text-center sm:text-left">
              <p className="font-display text-3xl leading-tight">{reviewSummary.count} Google Reviews</p>
              <p className="mt-2 text-sm text-white/65">Verified rating from patients of {site.name}, {site.location.area}.</p>
            </div>
            <a href={reviewSummary.url} target="_blank" rel="noopener noreferrer" className="btn btn-gold">
              <GoogleIcon className="h-4 w-4" /> Read on Google
            </a>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {list.map((r, i) => (
            <Reveal key={r.id} delay={i * 90} className="h-full">
              <ReviewCard review={r} />
            </Reveal>
          ))}
        </div>

        {!showAll ? (
          <Reveal delay={200} className="mt-10 text-center">
            <Link href="/reviews" className="inline-flex items-center gap-2 text-[12px] font-semibold tracking-[0.22em] text-gold uppercase hover:text-gold-deep">
              All Reviews <ArrowUpRight className="h-4 w-4" />
            </Link>
          </Reveal>
        ) : null}
      </div>
    </section>
  );
}

/* ----------------------------------- FAQ ------------------------------------- */
export function FaqList({ items, tone = "light" }: { items: Faq[]; tone?: "light" | "dark" }) {
  const dark = tone === "dark";
  return (
    <div className={dark ? "divide-y divide-white/10 border-y border-white/10" : "divide-y divide-ink/10 border-y border-ink/10"}>
      {items.map((f) => (
        <details key={f.q} className="faq group">
          <summary className={`flex cursor-pointer items-center justify-between gap-6 py-6 text-left font-display text-2xl leading-snug ${dark ? "text-white" : "text-ink"}`}>
            {f.q}
            <span className="faq-icon grid h-9 w-9 shrink-0 place-items-center rounded-full border border-gold/60 text-gold">
              <Plus className="h-4 w-4" />
            </span>
          </summary>
          <p className={`pb-7 text-[16px] leading-8 ${dark ? "text-white/70" : "text-ink/70"}`}>{f.a}</p>
        </details>
      ))}
    </div>
  );
}

export function FaqSection({ tone = "light" }: { tone?: "light" | "dark" }) {
  const dark = tone === "dark";
  return (
    <section className={dark ? "bg-ink text-white" : "bg-cream"}>
      <div className="container-x py-24 lg:py-32">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <SectionHeading
              tone={tone}
              eyebrow="FAQ"
              title="Questions, answered"
              description="Practical information about visiting Dental Cafe."
            />
          </div>
          <Reveal delay={100} className="lg:col-span-8">
            <FaqList items={faqs} tone={tone} />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* --------------------------------- LOCATION ---------------------------------- */
export function LocationSection() {
  return (
    <section className="bg-white">
      <div className="container-x py-24 lg:py-32">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionHeading
              eyebrow="Location"
              title={<>Find us in {site.location.area}, {site.location.city}</>}
            />
            <Reveal delay={100}>
              <ul className="mt-8 space-y-5 text-[16px] text-ink/80">
                <li className="flex items-start gap-4">
                  <MapPin className="mt-1 h-5 w-5 shrink-0 text-gold" />
                  <span>
                    <span className="block font-semibold text-ink">{site.name}</span>
                    {site.location.full}
                  </span>
                </li>
                <li className="flex items-start gap-4">
                  <Phone className="mt-1 h-5 w-5 shrink-0 text-gold" />
                  <span>
                    <a href={telLink()} className="block font-semibold text-ink hover:text-gold">{site.contact.phone}</a>
                    <a href={telLink(site.contact.additionalPhoneE164)} className="text-stone hover:text-gold">{site.contact.additionalPhone}</a>
                  </span>
                </li>
                <li className="flex items-start gap-4">
                  <WhatsAppIcon className="mt-1 h-5 w-5 shrink-0 text-gold" />
                  <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="font-semibold text-ink hover:text-gold">
                    WhatsApp {site.whatsapp.display}
                  </a>
                </li>
                <li className="flex items-start gap-4">
                  <span className="mt-1 h-5 w-5 shrink-0 text-center font-display text-gold">⏱</span>
                  <span>
                    <span className="block text-[11px] font-semibold tracking-[0.22em] text-stone uppercase">Opening Hours</span>
                    {site.hours ? site.hours.map((h) => <span key={h} className="block">{h}</span>) : <Placeholder label={PLACEHOLDERS.hours} className="mt-1" />}
                  </span>
                </li>
              </ul>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href={site.location.mapsUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
                  Get Directions
                </a>
                <Link href="/book" className="btn btn-secondary">Book Appointment</Link>
              </div>
            </Reveal>
          </div>
          <Reveal delay={150} className="lg:col-span-7" variant="mask">
            <div className="overflow-hidden rounded-brand border border-ink/10 shadow-soft">
              <iframe
                title={`${site.name} on Google Maps`}
                src={site.location.mapsEmbedUrl}
                className="aspect-[4/3] w-full grayscale-[35%] contrast-[1.05] sm:aspect-[16/10]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
