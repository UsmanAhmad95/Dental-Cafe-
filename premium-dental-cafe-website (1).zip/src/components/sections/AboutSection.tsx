import Link from "next/link";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { site } from "@/content/site";

export const aboutContent = {
  eyebrow: "About Dental Cafe",
  title: "A patient-centered dental practice in DHA Phase 4",
  paragraphs: [
    "Dental Cafe is a professional, patient-centered dental practice in DHA Phase 4, Lahore. Our focus is simple: healthier smiles, delivered with comfort, care and honesty.",
    "From your first conversation to your final review, treatment is planned around you — your oral health, your goals and your comfort — in a modern, hygienic clinical environment.",
  ],
  values: [
    { title: "Oral health first", text: "Careful examination and honest advice before any treatment." },
    { title: "Comfort & trust", text: "A gentle, unhurried approach that puts patients at ease." },
    { title: "Personalized care", text: "Plans shaped around individual needs, never one-size-fits-all." },
    { title: "Hygiene standards", text: "Clean, modern treatment spaces and sterilized instruments." },
  ],
  cta: "Discover Dental Cafe",
};

export function AboutSection() {
  return (
    <section className="bg-white">
      <div className="container-x py-24 lg:py-32">
        <div className="grid items-center gap-14 lg:grid-cols-12 lg:gap-20">
          <div className="relative lg:col-span-6">
            <Reveal variant="mask">
              <Picture
                asset="about-main"
                className="aspect-[4/5] w-full rounded-brand sm:aspect-[5/6]"
                sizes="(min-width: 1024px) 50vw, 100vw"
              />
            </Reveal>
            <Reveal delay={200} className="absolute -right-3 bottom-8 w-[46%] sm:-right-6 lg:-right-10">
              <div className="rounded-brand border-4 border-white shadow-lift">
                <Picture asset="about-detail" className="aspect-[4/3] w-full rounded-brand" sizes="25vw" />
              </div>
            </Reveal>
            <Reveal delay={300} className="absolute top-8 -left-3 sm:-left-6">
              <div className="rounded-brand bg-ink px-5 py-4 text-white shadow-lift">
                <p className="font-display text-4xl leading-none text-gold">{site.rating.value}</p>
                <p className="mt-1 text-[10px] tracking-[0.24em] text-white/70 uppercase">Google Rating</p>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-6">
            <SectionHeading eyebrow={aboutContent.eyebrow} title={aboutContent.title} />
            <Reveal delay={100}>
              <div className="mt-8 space-y-5 text-[17px] leading-8 text-ink/72">
                {aboutContent.paragraphs.map((p) => (
                  <p key={p}>{p}</p>
                ))}
              </div>
            </Reveal>
            <Reveal delay={180}>
              <ul className="mt-10 grid gap-6 sm:grid-cols-2">
                {aboutContent.values.map((v) => (
                  <li key={v.title} className="border-t border-gold/40 pt-4">
                    <h3 className="font-display text-xl text-ink">{v.title}</h3>
                    <p className="mt-1.5 text-sm leading-6 text-stone">{v.text}</p>
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal delay={240}>
              <Link href="/about" className="btn btn-primary mt-10">
                {aboutContent.cta}
              </Link>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
