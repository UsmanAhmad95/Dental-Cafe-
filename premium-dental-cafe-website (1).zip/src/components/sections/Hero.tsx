import Link from "next/link";
import { MapPin, Star } from "lucide-react";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppIcon } from "@/components/ui/icons";
import { site } from "@/content/site";
import { whatsappLink } from "@/lib/links";

/** Editable hero copy — kept here so text can be changed in one place. */
export const heroContent = {
  eyebrow: `${site.location.area} · ${site.location.city}`,
  headline: ["Where your", "smile", "comes first"] as const,
  supporting:
    "Professional, comfortable and personalized dental care designed around healthier smiles and confident patient experiences.",
  primaryCta: "Book an Appointment",
  secondaryCta: "Chat on WhatsApp",
};

export function Hero() {
  return (
    <section className="relative isolate flex min-h-[92svh] items-end overflow-hidden bg-ink text-white lg:items-center">
      <div className="absolute inset-0 -z-10">
        <Picture
          asset="hero-main"
          className="h-full w-full"
          imgClassName="hero-zoom object-cover"
          sizes="100vw"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/95 via-ink/70 to-ink/25" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-ink/40" />
      </div>

      <div className="container-x w-full pt-28 pb-24 lg:pt-36 lg:pb-32">
        <div className="max-w-3xl">
          <Reveal>
            <p className="eyebrow">{heroContent.eyebrow}</p>
          </Reveal>
          <Reveal delay={120}>
            <h1 className="mt-7 font-display text-[3.4rem] leading-[0.95] tracking-tight uppercase sm:text-7xl lg:text-8xl xl:text-[7.5rem]">
              {heroContent.headline[0]}
              <br />
              <span className="text-gold italic">{heroContent.headline[1]}</span>{" "}
              {heroContent.headline[2]}
            </h1>
          </Reveal>
          <Reveal delay={240}>
            <p className="mt-8 max-w-xl text-lg leading-8 text-white/75">{heroContent.supporting}</p>
          </Reveal>
          <Reveal delay={360}>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <Link href="/book" className="btn btn-gold btn-lg">
                {heroContent.primaryCta}
              </Link>
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light btn-lg">
                <WhatsAppIcon className="h-4 w-4" /> {heroContent.secondaryCta}
              </a>
            </div>
          </Reveal>
          <Reveal delay={480}>
            <ul className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 text-[13px] tracking-[0.12em] text-white/80 uppercase">
              <li className="flex items-center gap-2">
                <Star className="h-4 w-4 fill-gold text-gold" />
                <span className="font-semibold text-white">{site.rating.value}</span> Google Rating
              </li>
              <li className="hidden h-4 w-px bg-white/25 sm:block" aria-hidden />
              <li>
                <span className="font-semibold text-white">{site.rating.count}</span> Reviews
              </li>
              <li className="hidden h-4 w-px bg-white/25 sm:block" aria-hidden />
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-gold" /> {site.location.area}, {site.location.city}
              </li>
            </ul>
          </Reveal>
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 gold-line opacity-70" />
    </section>
  );
}
