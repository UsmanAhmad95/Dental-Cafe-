import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import type { ImageAssetKey } from "@/content/assets";

/** Only spaces confirmed/supplied are shown; missing ones render as placeholders. */
export const clinicSpaces: { asset: ImageAssetKey; title: string; text: string; span?: string }[] = [
  { asset: "clinic-reception", title: "Reception", text: "A calm welcome the moment you arrive.", span: "md:col-span-2 md:row-span-2" },
  { asset: "clinic-waiting-area", title: "Waiting Area", text: "Comfortable, quiet and unhurried." },
  { asset: "treatment-room", title: "Treatment Rooms", text: "Modern, clean and designed for comfort." },
  { asset: "clinic-equipment", title: "Equipment", text: "Sterilized instruments for every patient." },
  { asset: "clinic-team", title: "Team", text: "Professionals who take time to listen." },
  { asset: "patient-experience", title: "Patient Experience", text: "Care shaped around how you feel.", span: "md:col-span-2" },
];

export function ClinicExperience() {
  return (
    <section className="bg-cream">
      <div className="container-x py-24 lg:py-32">
        <SectionHeading
          eyebrow="Clinic Experience"
          title="Designed to feel calm, clean and considered"
          description="A visual walk through the spaces and details that shape your visit to Dental Cafe."
          align="center"
        />
        <div className="mt-14 grid auto-rows-[220px] gap-4 sm:auto-rows-[240px] md:grid-cols-4">
          {clinicSpaces.map((s, i) => (
            <Reveal key={s.asset} delay={i * 70} className={`h-full ${s.span ?? ""}`}>
              <figure className="group relative h-full overflow-hidden rounded-brand">
                <Picture
                  asset={s.asset}
                  className="h-full w-full rounded-brand"
                  imgClassName="img-zoom"
                  showConceptTag
                  sizes="(min-width: 768px) 50vw, 100vw"
                />
                <figcaption className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/85 via-ink/30 to-transparent p-5 pt-16 text-white">
                  <p className="text-[10px] font-semibold tracking-[0.26em] text-gold uppercase">{s.title}</p>
                  <p className="mt-1 text-sm text-white/85">{s.text}</p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
