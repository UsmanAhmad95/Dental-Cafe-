import Link from "next/link";
import { Phone } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppIcon } from "@/components/ui/icons";
import { site } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/links";
import { TrustList } from "./TrustBar";

/**
 * OPTION 2 — black band combining the Google trust strip (§10) with the
 * "Ready for your next smile?" appointment CTA (§11), directly under the white hero.
 */
export function TrustBookBand() {
  return (
    <section className="relative isolate overflow-hidden bg-ink text-white" aria-label="Trust indicators and appointments">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{ background: "radial-gradient(50% 70% at 12% 100%, rgba(198,161,91,0.22) 0%, rgba(198,161,91,0) 70%)" }}
      />
      <div className="container-x">
        <TrustList />
        <div className="grid items-center gap-10 py-16 lg:grid-cols-12 lg:py-20">
          <Reveal className="lg:col-span-7">
            <p className="eyebrow">Appointments</p>
            <h2 className="mt-5 display-lg uppercase">
              Ready for your <span className="text-gold italic">next</span> smile?
            </h2>
            <p className="mt-5 max-w-lg text-[15px] leading-7 text-white/65">
              Request a time online, call the clinic or message us on WhatsApp. Online requests are confirmed personally by our team.
            </p>
          </Reveal>
          <Reveal delay={120} className="lg:col-span-5">
            <div className="flex flex-col gap-3">
              <Link href="/book" className="btn btn-gold btn-lg w-full">
                Book Your Appointment
              </Link>
              <div className="grid gap-3 sm:grid-cols-2">
                <a href={telLink()} className="btn btn-outline-light">
                  <Phone className="h-4 w-4" /> {site.contact.phone}
                </a>
                <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light">
                  <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
