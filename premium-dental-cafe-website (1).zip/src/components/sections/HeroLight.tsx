import Link from "next/link";
import { MapPin, Star } from "lucide-react";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppIcon } from "@/components/ui/icons";
import { site } from "@/content/site";
import { whatsappLink } from "@/lib/links";
import { heroContent } from "./Hero";

/**
 * OPTION 2 HERO — white editorial hero (brief §46: "White Hero, Gold/Black typography").
 * Shares `heroContent` with Option 1 so copy is edited in one place.
 */
export function HeroLight() {
  return (
    <section className="relative isolate overflow-hidden bg-white text-ink">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{ background: "radial-gradient(45% 55% at 88% 15%, rgba(198,161,91,0.16) 0%, rgba(198,161,91,0) 70%)" }}
      />
      <div className="container-x grid min-h-[86svh] items-center gap-14 py-16 lg:grid-cols-12 lg:gap-12 lg:py-24">
        <div className="lg:col-span-7">
          <Reveal>
            <p className="eyebrow">{heroContent.eyebrow}</p>
          </Reveal>
          <Reveal delay={120}>
            <h1 className="mt-7 font-display text-[3rem] leading-[0.95] tracking-tight text-ink uppercase sm:text-7xl lg:text-8xl xl:text-[7.25rem]">
              {heroContent.headline[0]}
              <br />
              <span className="text-gold italic">{heroContent.headline[1]}</span>{" "}
              {heroContent.headline[2]}
            </h1>
          </Reveal>
          <Reveal delay={240}>
            <p className="mt-8 max-w-xl text-lg leading-8 text-ink/70">{heroContent.supporting}</p>
          </Reveal>
          <Reveal delay={360}>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <Link href="/book" className="btn btn-primary btn-lg">
                {heroContent.primaryCta}
              </Link>
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-lg">
                <WhatsAppIcon className="h-4 w-4" /> {heroContent.secondaryCta}
              </a>
            </div>
          </Reveal>
          <Reveal delay={480}>
            <ul className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-ink/10 pt-8 text-[13px] tracking-[0.12em] text-ink/70 uppercase">
              <li className="flex items-center gap-2">
                <Star className="h-4 w-4 fill-gold text-gold" />
                <span className="font-semibold text-ink">{site.rating.value}</span> Google Rating
              </li>
              <li className="hidden h-4 w-px bg-ink/15 sm:block" aria-hidden />
              <li>
                <span className="font-semibold text-ink">{site.rating.count}</span> Reviews
              </li>
              <li className="hidden h-4 w-px bg-ink/15 sm:block" aria-hidden />
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-gold" /> {site.location.area}, {site.location.city}
              </li>
            </ul>
          </Reveal>
        </div>

        <div className="relative lg:col-span-5">
          {/* Offset gold hairline frame (kept outside the mask so it is never clipped) */}
          <Reveal delay={500} className="pointer-events-none absolute inset-0">
            <span aria-hidden className="absolute inset-0 translate-x-4 translate-y-4 rounded-brand border border-gold/60" />
          </Reveal>
          <Reveal variant="mask">
            <Picture
              asset="hero-main"
              className="relative aspect-[4/3] w-full rounded-brand lg:aspect-[4/5]"
              sizes="(min-width: 1024px) 40vw, 100vw"
              priority
            />
          </Reveal>
          <Reveal delay={320} className="absolute -bottom-6 -left-3 sm:-left-6 lg:-left-10">
            <div className="rounded-brand bg-ink px-6 py-5 text-white shadow-lift">
              <div className="flex items-center gap-1 text-gold" aria-hidden>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-3.5 w-3.5 fill-current" />
                ))}
              </div>
              <p className="mt-2 font-display text-4xl leading-none">{site.rating.value}</p>
              <p className="mt-1 text-[10px] tracking-[0.24em] text-white/70 uppercase">{site.rating.count} Google Reviews</p>
            </div>
          </Reveal>
        </div>
      </div>
      <div className="gold-line opacity-70" />
    </section>
  );
}
