import { CalendarCheck, Building2, Star, Users, MessageSquareQuote } from "lucide-react";
import { site } from "@/content/site";
import { cn } from "@/lib/utils";

export const trustItems = [
  { icon: Star, value: `${site.rating.value} ★`, label: "Google Rating" },
  { icon: MessageSquareQuote, value: String(site.rating.count), label: "Google Reviews" },
  { icon: Users, value: "Professional", label: "Dental Team" },
  { icon: Building2, value: "Modern", label: "Clinic Environment" },
  { icon: CalendarCheck, value: "Appointments", label: "Recommended" },
];

/** The five trust indicators — white on black with gold icon accents. */
export function TrustList({ className }: { className?: string }) {
  return (
    <ul className={cn("grid grid-cols-2 divide-white/10 border-b border-white/10 sm:grid-cols-3 lg:grid-cols-5 lg:divide-x", className)}>
      {trustItems.map(({ icon: Icon, value, label }, i) => (
        <li
          key={label}
          className={cn("flex items-center gap-4 px-2 py-7 lg:justify-center lg:px-6", i === 4 && "col-span-2 sm:col-span-1")}
        >
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-gold/50 text-gold">
            <Icon className="h-4.5 w-4.5" />
          </span>
          <span>
            <span className="block font-display text-2xl leading-none">{value}</span>
            <span className="mt-1 block text-[11px] tracking-[0.22em] text-white/60 uppercase">{label}</span>
          </span>
        </li>
      ))}
    </ul>
  );
}

export function TrustBar() {
  return (
    <section aria-label="Trust indicators" className="bg-ink text-white">
      <div className="container-x">
        <TrustList />
      </div>
    </section>
  );
}
