import Link from "next/link";
import { Phone } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppIcon } from "@/components/ui/icons";
import { site } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/links";

/** Prominent appointment CTA placed near the top of the homepage (cream). */
export function AppointmentCta() {
  return (
    <section className="bg-cream">
      <div className="container-x py-16 lg:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-12">
          <Reveal className="lg:col-span-7">
            <p className="eyebrow">Appointments</p>
            <h2 className="mt-5 display-lg text-ink uppercase">
              Ready for your <span className="text-gold italic">next</span> smile?
            </h2>
          </Reveal>
          <Reveal delay={120} className="lg:col-span-5">
            <div className="card p-7 sm:p-8">
              <Link href="/book" className="btn btn-primary btn-lg w-full">
                Book Your Appointment
              </Link>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <a href={telLink()} className="btn btn-secondary">
                  <Phone className="h-4 w-4" /> {site.contact.phone}
                </a>
                <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
                  <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                </a>
              </div>
              <p className="mt-5 text-center text-xs tracking-wide text-stone">
                Online requests are confirmed by our team by phone or WhatsApp.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/** Final booking CTA (black + gold). Reused across pages. */
export function FinalCta({
  title = "Your next appointment starts here",
  text = "Request a time online, call the clinic or message us on WhatsApp — our team will confirm your appointment personally.",
  bookingHref = "/book",
  whatsappHref = whatsappLink(),
}: {
  title?: string;
  text?: string;
  bookingHref?: string;
  whatsappHref?: string;
}) {
  return (
    <section className="relative isolate overflow-hidden bg-ink text-white">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{ background: "radial-gradient(60% 80% at 80% 50%, rgba(198,161,91,0.22) 0%, rgba(198,161,91,0) 70%)" }}
      />
      <div className="container-x py-20 lg:py-28">
        <div className="grid items-center gap-10 lg:grid-cols-12">
          <Reveal className="lg:col-span-7">
            <p className="eyebrow">Book Appointment</p>
            <h2 className="mt-5 display-lg">{title}</h2>
            <p className="mt-6 max-w-xl text-[17px] leading-8 text-white/70">{text}</p>
          </Reveal>
          <Reveal delay={120} className="lg:col-span-5">
            <div className="flex flex-col gap-3">
              <Link href={bookingHref} className="btn btn-gold btn-lg w-full">
                Book Your Appointment
              </Link>
              <a href={whatsappHref} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light btn-lg w-full">
                <WhatsAppIcon className="h-4 w-4" /> Chat on WhatsApp
              </a>
              <a href={telLink()} className="btn btn-outline-light btn-lg w-full">
                <Phone className="h-4 w-4" /> {site.contact.phone}
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
