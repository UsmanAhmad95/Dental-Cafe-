import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Picture } from "@/components/ui/Picture";
import type { Service } from "@/content/services";

export function ServiceCard({ service, index = 0 }: { service: Service; index?: number }) {
  return (
    <article className="group card card-hover flex h-full flex-col overflow-hidden">
      <Link href={`/services/${service.slug}`} className="block" aria-label={`Explore ${service.name}`}>
        <div className="relative">
          <Picture
            asset={service.image}
            className="aspect-[4/3] w-full"
            imgClassName="img-zoom"
            sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
          />
          <span className="absolute top-4 left-4 rounded-brand bg-ink/80 px-2.5 py-1 font-mono text-[11px] tracking-[0.2em] text-gold backdrop-blur-sm">
            {String(index + 1).padStart(2, "0")}
          </span>
        </div>
      </Link>
      <div className="flex flex-1 flex-col p-7">
        <h3 className="font-display text-2xl leading-tight text-ink">{service.name}</h3>
        <p className="mt-3 text-[15px] leading-7 text-ink/70">{service.excerpt}</p>
        <Link
          href={`/services/${service.slug}`}
          className="mt-auto inline-flex items-center gap-2 pt-6 text-[12px] font-semibold tracking-[0.2em] text-gold uppercase transition-all hover:gap-3 hover:text-gold-deep"
        >
          Explore Treatment <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </article>
  );
}
