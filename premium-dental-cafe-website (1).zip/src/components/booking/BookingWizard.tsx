"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ArrowLeft, ArrowRight, Check, Phone } from "lucide-react";
import { WhatsAppIcon } from "@/components/ui/icons";
import { sortedDoctors } from "@/content/doctors";
import { publishedServices } from "@/content/services";
import { site } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/links";
import { cn } from "@/lib/utils";

const STEPS = [
  { key: "treatment", label: "Treatment" },
  { key: "doctor", label: "Doctor" },
  { key: "date", label: "Date" },
  { key: "time", label: "Preferred Time" },
  { key: "name", label: "Patient Name" },
  { key: "phone", label: "Phone" },
  { key: "whatsapp", label: "WhatsApp" },
  { key: "message", label: "Message" },
  { key: "submit", label: "Submit" },
] as const;

type StepKey = (typeof STEPS)[number]["key"];

const TIMES = [
  { value: "Morning", hint: "Early in the day" },
  { value: "Afternoon", hint: "Midday onwards" },
  { value: "Evening", hint: "Later in the day" },
  { value: "Flexible", hint: "Any time works" },
];

interface FormData {
  treatment: string;
  doctor: string;
  date: string;
  time: string;
  name: string;
  phone: string;
  whatsapp: string;
  sameAsPhone: boolean;
  message: string;
  website: string; // honeypot
}

const initial: FormData = {
  treatment: "",
  doctor: "any",
  date: "",
  time: "",
  name: "",
  phone: "",
  whatsapp: "",
  sameAsPhone: true,
  message: "",
  website: "",
};

function todayIso() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

function phoneOk(v: string) {
  const digits = v.replace(/\D/g, "");
  return /^[+\d][\d\s().-]{6,24}$/.test(v) && digits.length >= 10 && digits.length <= 15;
}

export function BookingWizard() {
  const params = useSearchParams();
  const [step, setStep] = useState(0);
  const [data, setData] = useState<FormData>(initial);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [serverFailed, setServerFailed] = useState(false);
  const [result, setResult] = useState<{ reference: string } | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  // Pre-select from ?treatment=&doctor=
  useEffect(() => {
    const t = params.get("treatment");
    const d = params.get("doctor");
    setData((prev) => ({
      ...prev,
      treatment: t && (publishedServices.some((s) => s.slug === t) || t === "other") ? t : prev.treatment,
      doctor: d && sortedDoctors.some((x) => x.slug === d) ? d : prev.doctor,
    }));
  }, [params]);

  const current = STEPS[step];
  const update = <K extends keyof FormData>(key: K, value: FormData[K]) => {
    setData((prev) => ({ ...prev, [key]: value }));
    setError(null);
  };

  const treatmentName = useMemo(
    () => (data.treatment === "other" ? "Other / Not sure" : publishedServices.find((s) => s.slug === data.treatment)?.name ?? ""),
    [data.treatment],
  );
  const doctorName = useMemo(
    () => (data.doctor === "any" ? "No preference" : sortedDoctors.find((d) => d.slug === data.doctor)?.name ?? ""),
    [data.doctor],
  );

  const validate = (key: StepKey): string | null => {
    switch (key) {
      case "treatment":
        return data.treatment ? null : "Please choose a treatment to continue.";
      case "date":
        if (!data.date) return "Please choose your preferred date.";
        return data.date < todayIso() ? "Please choose today or a future date." : null;
      case "time":
        return data.time ? null : "Please choose a preferred time.";
      case "name":
        return data.name.trim().length >= 2 ? null : "Please enter the patient's full name.";
      case "phone":
        return phoneOk(data.phone) ? null : "Please enter a valid phone number (e.g. +92 3XX XXXXXXX).";
      case "whatsapp":
        if (data.sameAsPhone) return null;
        return !data.whatsapp || phoneOk(data.whatsapp) ? null : "Please enter a valid WhatsApp number.";
      default:
        return null;
    }
  };

  const goNext = () => {
    const err = validate(current.key);
    if (err) {
      setError(err);
      return;
    }
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
    panelRef.current?.focus();
  };
  const goBack = () => {
    setError(null);
    setStep((s) => Math.max(s - 1, 0));
    panelRef.current?.focus();
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (current.key !== "submit") {
      goNext();
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          treatment: data.treatment,
          doctor: data.doctor,
          date: data.date,
          time: data.time,
          name: data.name,
          phone: data.phone,
          whatsapp: data.sameAsPhone ? data.phone : data.whatsapp,
          message: data.message,
          website: data.website,
        }),
      });
      const json = (await res.json().catch(() => ({ ok: false }))) as { ok: boolean; reference?: string; error?: string; errors?: Record<string, string> };
      if (!res.ok || !json.ok) {
        const first = json.errors ? Object.values(json.errors)[0] : undefined;
        setError(first ?? json.error ?? "Something went wrong. Please try again or contact the clinic directly.");
        setServerFailed(res.status >= 500);
        return;
      }
      setResult({ reference: json.reference ?? "" });
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setError("Network error. Please try again or call the clinic.");
      setServerFailed(true);
    } finally {
      setSubmitting(false);
    }
  };

  if (result) {
    const summary = `Hello Dental Cafe, I have just submitted an appointment request (Ref ${result.reference}) for ${treatmentName} on ${data.date} (${data.time}). Patient: ${data.name}.`;
    return (
      <div className="card mx-auto max-w-2xl p-8 text-center sm:p-12" role="status" aria-live="polite">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full border border-gold bg-cream text-gold">
          <Check className="h-7 w-7" />
        </span>
        <p className="eyebrow eyebrow-plain mt-8 justify-center">Reference {result.reference}</p>
        <h2 className="mt-4 display-md text-ink uppercase">Appointment request received</h2>
        <p className="mx-auto mt-5 max-w-lg text-[16px] leading-8 text-ink/70">
          Thank you, {data.name.split(" ")[0]}. This is a <strong className="text-ink">request</strong>, not a confirmed booking yet.
          Our team will contact you on <strong className="text-ink">{data.phone}</strong> to confirm your appointment for{" "}
          <strong className="text-ink">{treatmentName}</strong>.
        </p>
        <dl className="mx-auto mt-8 grid max-w-md grid-cols-2 gap-4 text-left text-sm">
          <div><dt className="field-label">Date</dt><dd className="text-ink">{data.date}</dd></div>
          <div><dt className="field-label">Time</dt><dd className="text-ink">{data.time}</dd></div>
          <div><dt className="field-label">Doctor</dt><dd className="text-ink">{doctorName}</dd></div>
          <div><dt className="field-label">Phone</dt><dd className="text-ink">{data.phone}</dd></div>
        </dl>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <a href={whatsappLink(summary)} target="_blank" rel="noopener noreferrer" className="btn btn-gold">
            <WhatsAppIcon className="h-4 w-4" /> Confirm faster on WhatsApp
          </a>
          <a href={telLink()} className="btn btn-secondary">
            <Phone className="h-4 w-4" /> {site.contact.phone}
          </a>
        </div>
        <Link href="/" className="mt-8 inline-block text-[12px] font-semibold tracking-[0.22em] text-gold uppercase hover:text-gold-deep">
          Back to home
        </Link>
      </div>
    );
  }

  const progress = ((step + 1) / STEPS.length) * 100;

  return (
    <div className="grid overflow-hidden rounded-brand border border-ink/10 bg-white shadow-soft lg:grid-cols-12">
      {/* Progress rail */}
      <aside className="bg-ink p-8 text-white lg:col-span-4 lg:p-10">
        <p className="eyebrow">Appointment Request</p>
        <h2 className="mt-4 font-display text-3xl leading-tight">Nine simple steps</h2>
        <p className="mt-3 text-sm leading-6 text-white/60">
          Requests are confirmed personally by our team. Prefer to talk? Call{" "}
          <a href={telLink()} className="text-gold underline-offset-4 hover:underline">{site.contact.phone}</a>.
        </p>

        <div className="mt-8 h-px w-full bg-white/10">
          <div className="h-px bg-gold transition-all duration-700 ease-luxe" style={{ width: `${progress}%` }} />
        </div>

        <ol className="mt-8 hidden space-y-3 lg:block" aria-label="Booking steps">
          {STEPS.map((s, i) => {
            const done = i < step;
            const active = i === step;
            return (
              <li key={s.key} className={cn("flex items-center gap-3 text-sm", active ? "text-white" : done ? "text-white/70" : "text-white/35")}>
                <span
                  className={cn(
                    "grid h-7 w-7 shrink-0 place-items-center rounded-full border font-mono text-[11px]",
                    active ? "border-gold bg-gold text-ink" : done ? "border-gold text-gold" : "border-white/20",
                  )}
                >
                  {done ? <Check className="h-3.5 w-3.5" /> : i + 1}
                </span>
                {s.label}
              </li>
            );
          })}
        </ol>

        <p className="mt-6 font-mono text-[11px] tracking-[0.2em] text-white/50 uppercase lg:hidden">
          Step {step + 1} of {STEPS.length} — {current.label}
        </p>
      </aside>

      {/* Step panel */}
      <form onSubmit={submit} className="p-6 sm:p-10 lg:col-span-8 lg:p-12" noValidate>
        <div ref={panelRef} tabIndex={-1} className="outline-none">
          <p className="font-mono text-[11px] tracking-[0.24em] text-gold-deep uppercase">
            Step {step + 1} / {STEPS.length}
          </p>

          {current.key === "treatment" ? (
            <fieldset>
              <legend className="mt-3 display-sm text-ink">Which treatment are you interested in?</legend>
              <div className="mt-7 grid gap-3 sm:grid-cols-2">
                {publishedServices.map((s) => (
                  <OptionCard key={s.slug} selected={data.treatment === s.slug} onClick={() => update("treatment", s.slug)} title={s.name} text={s.excerpt} />
                ))}
                <OptionCard selected={data.treatment === "other"} onClick={() => update("treatment", "other")} title="Other / Not sure" text="Tell us more in the message step and we will guide you." />
              </div>
            </fieldset>
          ) : null}

          {current.key === "doctor" ? (
            <fieldset>
              <legend className="mt-3 display-sm text-ink">Do you have a preferred doctor?</legend>
              <div className="mt-7 grid gap-3 sm:grid-cols-2">
                <OptionCard selected={data.doctor === "any"} onClick={() => update("doctor", "any")} title="No preference" text="We will match you with the right clinician." />
                {sortedDoctors.map((d) => (
                  <OptionCard key={d.slug} selected={data.doctor === d.slug} onClick={() => update("doctor", d.slug)} title={d.name} text={d.specialization ?? d.tagline ?? d.qualification ?? "Dental Cafe"} />
                ))}
              </div>
            </fieldset>
          ) : null}

          {current.key === "date" ? (
            <div>
              <label htmlFor="date" className="mt-3 block display-sm text-ink">Preferred date</label>
              <p className="mt-2 text-sm text-stone">Choose the day that suits you best. We will confirm availability.</p>
              <input id="date" type="date" min={todayIso()} value={data.date} onChange={(e) => update("date", e.target.value)} className="field mt-7 max-w-sm" required />
            </div>
          ) : null}

          {current.key === "time" ? (
            <fieldset>
              <legend className="mt-3 display-sm text-ink">Preferred time of day</legend>
              <div className="mt-7 grid gap-3 sm:grid-cols-2">
                {TIMES.map((t) => (
                  <OptionCard key={t.value} selected={data.time === t.value} onClick={() => update("time", t.value)} title={t.value} text={t.hint} />
                ))}
              </div>
            </fieldset>
          ) : null}

          {current.key === "name" ? (
            <div>
              <label htmlFor="name" className="mt-3 block display-sm text-ink">Patient name</label>
              <input id="name" type="text" autoComplete="name" value={data.name} onChange={(e) => update("name", e.target.value)} placeholder="Full name" className="field mt-7 max-w-md" required />
            </div>
          ) : null}

          {current.key === "phone" ? (
            <div>
              <label htmlFor="phone" className="mt-3 block display-sm text-ink">Phone number</label>
              <p className="mt-2 text-sm text-stone">We will call this number to confirm your appointment.</p>
              <input id="phone" type="tel" inputMode="tel" autoComplete="tel" value={data.phone} onChange={(e) => update("phone", e.target.value)} placeholder="+92 3XX XXXXXXX" className="field mt-7 max-w-md" required />
            </div>
          ) : null}

          {current.key === "whatsapp" ? (
            <div>
              <p className="mt-3 display-sm text-ink">WhatsApp number</p>
              <label className="mt-6 flex cursor-pointer items-center gap-3 text-[15px] text-ink">
                <input type="checkbox" checked={data.sameAsPhone} onChange={(e) => update("sameAsPhone", e.target.checked)} className="h-5 w-5 accent-[#C6A15B]" />
                Same as my phone number
              </label>
              {!data.sameAsPhone ? (
                <>
                  <label htmlFor="whatsapp" className="field-label mt-6">WhatsApp number (optional)</label>
                  <input id="whatsapp" type="tel" inputMode="tel" value={data.whatsapp} onChange={(e) => update("whatsapp", e.target.value)} placeholder="+92 3XX XXXXXXX" className="field max-w-md" />
                </>
              ) : null}
            </div>
          ) : null}

          {current.key === "message" ? (
            <div>
              <label htmlFor="message" className="mt-3 block display-sm text-ink">Anything we should know?</label>
              <p className="mt-2 text-sm text-stone">Optional — symptoms, concerns, anxieties or questions.</p>
              <textarea id="message" rows={5} value={data.message} onChange={(e) => update("message", e.target.value)} placeholder="Your message" className="field mt-7" />
              {/* Honeypot */}
              <div className="hidden" aria-hidden>
                <label htmlFor="website">Website</label>
                <input id="website" type="text" tabIndex={-1} autoComplete="off" value={data.website} onChange={(e) => update("website", e.target.value)} />
              </div>
            </div>
          ) : null}

          {current.key === "submit" ? (
            <div>
              <h3 className="mt-3 display-sm text-ink">Review & submit your request</h3>
              <dl className="mt-7 grid gap-x-8 gap-y-5 rounded-brand border border-ink/10 bg-cream p-6 sm:grid-cols-2">
                <Row label="Treatment" value={treatmentName} onEdit={() => setStep(0)} />
                <Row label="Doctor" value={doctorName} onEdit={() => setStep(1)} />
                <Row label="Date" value={data.date} onEdit={() => setStep(2)} />
                <Row label="Preferred time" value={data.time} onEdit={() => setStep(3)} />
                <Row label="Patient" value={data.name} onEdit={() => setStep(4)} />
                <Row label="Phone" value={data.phone} onEdit={() => setStep(5)} />
                <Row label="WhatsApp" value={data.sameAsPhone ? data.phone : data.whatsapp || "—"} onEdit={() => setStep(6)} />
                <Row label="Message" value={data.message || "—"} onEdit={() => setStep(7)} />
              </dl>
              <p className="mt-5 text-sm leading-6 text-stone">
                By submitting, you agree that Dental Cafe may contact you about this request. This is not a confirmed booking until our team contacts you.
              </p>
            </div>
          ) : null}

          {error ? (
            <div role="alert" className="mt-6 rounded-brand border border-gold/60 bg-cream px-4 py-4 text-sm text-ink">
              <p>{error}</p>
              {serverFailed ? (
                <a
                  href={whatsappLink(
                    `Hello Dental Cafe, I would like to book a dental appointment.\nTreatment: ${treatmentName}\nDoctor: ${doctorName}\nDate: ${data.date}\nTime: ${data.time}\nName: ${data.name}\nPhone: ${data.phone}${data.message ? `\nMessage: ${data.message}` : ""}`,
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-gold btn-sm mt-4"
                >
                  <WhatsAppIcon className="h-4 w-4" /> Send this request on WhatsApp instead
                </a>
              ) : null}
            </div>
          ) : null}
        </div>

        <div className="mt-10 flex flex-col-reverse gap-3 border-t border-ink/10 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <button type="button" onClick={goBack} disabled={step === 0} className="btn btn-secondary">
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
          {current.key === "submit" ? (
            <button type="submit" disabled={submitting} className="btn btn-gold btn-lg">
              {submitting ? "Sending…" : "Submit Request"}
            </button>
          ) : (
            <button type="submit" className="btn btn-primary">
              Continue <ArrowRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

function OptionCard({ selected, onClick, title, text }: { selected: boolean; onClick: () => void; title: string; text: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={cn(
        "flex min-h-[88px] items-start gap-4 rounded-brand border p-5 text-left transition-all duration-300",
        selected ? "border-gold bg-ink text-white shadow-soft" : "border-ink/12 bg-white text-ink hover:border-gold",
      )}
    >
      <span className={cn("mt-1 grid h-5 w-5 shrink-0 place-items-center rounded-full border", selected ? "border-gold bg-gold text-ink" : "border-ink/30")}>
        {selected ? <Check className="h-3 w-3" /> : null}
      </span>
      <span>
        <span className="block font-display text-xl leading-tight">{title}</span>
        <span className={cn("mt-1 block text-sm leading-6", selected ? "text-white/65" : "text-stone")}>{text}</span>
      </span>
    </button>
  );
}

function Row({ label, value, onEdit }: { label: string; value: string; onEdit: () => void }) {
  return (
    <div>
      <dt className="field-label flex items-center justify-between">
        {label}
        <button type="button" onClick={onEdit} className="text-[10px] tracking-[0.2em] text-gold-deep uppercase hover:underline">
          Edit
        </button>
      </dt>
      <dd className="text-[15px] break-words text-ink">{value}</dd>
    </div>
  );
}
