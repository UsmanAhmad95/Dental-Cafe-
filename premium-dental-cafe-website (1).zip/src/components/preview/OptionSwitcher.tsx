import Link from "next/link";
import { cn } from "@/lib/utils";

/**
 * TEMPORARY design-preview switcher shown on both homepage options.
 * Once an option is chosen, delete the <OptionSwitcher /> line from
 * src/app/page.tsx (and remove src/app/option-2 if no longer needed).
 */
export const designOptions = [
  { id: 1, href: "/", label: "Option 1", name: "Cinematic" },
  { id: 2, href: "/option-2", label: "Option 2", name: "Light Editorial" },
] as const;

export function OptionSwitcher({ active }: { active: 1 | 2 }) {
  return (
    <nav aria-label="Design preview options" className="border-b border-ink/10 bg-cream">
      <div className="container-x flex flex-wrap items-center justify-between gap-3 py-2.5">
        <p className="text-[10px] font-semibold tracking-[0.26em] text-stone uppercase">Design preview</p>
        <ul className="flex items-center gap-2">
          {designOptions.map((o) => {
            const isActive = o.id === active;
            return (
              <li key={o.id}>
                <Link
                  href={o.href}
                  aria-current={isActive ? "page" : undefined}
                  className={cn(
                    "inline-flex min-h-8 items-center gap-1.5 rounded-brand border px-3 text-[10px] font-semibold tracking-[0.2em] uppercase transition-colors",
                    isActive ? "border-ink bg-ink text-white" : "border-gold/60 bg-white text-ink hover:border-gold",
                  )}
                >
                  {o.label}
                  <span className={isActive ? "text-gold" : "text-stone"}>· {o.name}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
