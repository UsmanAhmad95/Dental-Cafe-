import { site } from "@/content/site";

/** Local business (Dentist) structured data — verified information only. */
export function LocalBusinessSchema() {
  const data = {
    "@context": "https://schema.org",
    "@type": "Dentist",
    name: site.name,
    slogan: site.tagline,
    description: site.description,
    url: site.url,
    telephone: site.contact.phoneE164,
    address: {
      "@type": "PostalAddress",
      streetAddress: site.location.area,
      addressLocality: site.location.city,
      addressRegion: site.location.region,
      addressCountry: site.location.countryCode,
    },
    hasMap: site.location.mapsUrl,
    sameAs: [site.social.instagram, site.social.facebook, site.location.mapsUrl],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: site.rating.value,
      reviewCount: String(site.rating.count),
      bestRating: "5",
      worstRating: "1",
    },
    contactPoint: [
      {
        "@type": "ContactPoint",
        telephone: site.contact.phoneE164,
        contactType: "reservations",
        availableLanguage: ["en", "ur"],
      },
    ],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
