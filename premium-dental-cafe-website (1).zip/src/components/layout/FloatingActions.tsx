import Link from "next/link";
import { Phone, CalendarDays } from "lucide-react";
import { WhatsAppIcon } from "@/components/ui/icons";
import { telLink, whatsappLink } from "@/lib/links";

/** Floating WhatsApp (all screens) + sticky mobile CTA bar (Call / WhatsApp / Book). */
export function FloatingActions() {
  return (
    <>
      <a
        href={whatsappLink()}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="group fixed right-4 bottom-[88px] z-40 inline-flex h-14 w-14 items-center justify-center rounded-full border border-gold/50 bg-ink text-gold shadow-lift transition-all duration-500 ease-luxe hover:scale-105 hover:bg-gold hover:text-ink md:right-6 md:bottom-6"
      >
        <WhatsAppIcon className="h-6 w-6" />
        <span className="sr-only">WhatsApp {`+92 332 4679934`}</span>
      </a>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-ink/95 text-white backdrop-blur-md md:hidden">
        <div className="gold-line opacity-60" />
        <div className="grid grid-cols-3">
          <a href={telLink()} className="flex min-h-[64px] flex-col items-center justify-center gap-1 text-[10px] font-semibold tracking-[0.2em] uppercase transition-colors hover:text-gold">
            <Phone className="h-5 w-5 text-gold" /> Call
          </a>
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="flex min-h-[64px] flex-col items-center justify-center gap-1 border-x border-white/10 text-[10px] font-semibold tracking-[0.2em] uppercase transition-colors hover:text-gold">
            <WhatsAppIcon className="h-5 w-5 text-gold" /> WhatsApp
          </a>
          <Link href="/book" className="flex min-h-[64px] flex-col items-center justify-center gap-1 bg-gold text-[10px] font-semibold tracking-[0.2em] text-ink uppercase transition-colors hover:bg-gold-deep">
            <CalendarDays className="h-5 w-5" /> Book
          </Link>
        </div>
      </div>
    </>
  );
}
