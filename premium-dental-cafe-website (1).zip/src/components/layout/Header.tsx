"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Phone, X } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { WhatsAppIcon } from "@/components/ui/icons";
import { site } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/links";
import { cn } from "@/lib/utils";

export function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the drawer on route change
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  // Lock body scroll + ESC to close
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header
      className={cn(
        "sticky top-0 z-50 border-b border-white/10 bg-ink/95 text-white backdrop-blur-md transition-all duration-500 ease-luxe",
        scrolled ? "shadow-[0_10px_40px_-20px_rgba(0,0,0,0.6)]" : "",
      )}
    >
      <div className="gold-line opacity-60" />
      <div
        className={cn(
          "container-x flex items-center justify-between gap-6 transition-all duration-500 ease-luxe",
          scrolled ? "py-3" : "py-5",
        )}
      >
        <Logo height={scrolled ? 36 : 44} />

        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-8 xl:gap-9">
            {site.nav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="nav-link py-2"
                  aria-current={isActive(item.href) ? "page" : undefined}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-outline-light btn-sm"
          >
            <WhatsAppIcon className="h-4 w-4" />
            WhatsApp
          </a>
          <Link href="/book" className="btn btn-gold btn-sm">
            Book Appointment
          </Link>
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="ml-1 inline-flex h-11 w-11 items-center justify-center rounded-brand border border-white/20 text-white transition-colors hover:border-gold hover:text-gold lg:hidden"
            aria-label="Open menu"
            aria-expanded={open}
            aria-controls="mobile-nav"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>

        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex h-11 w-11 items-center justify-center rounded-brand border border-white/20 text-white transition-colors hover:border-gold hover:text-gold md:hidden"
          aria-label="Open menu"
          aria-expanded={open}
          aria-controls="mobile-nav"
        >
          <Menu className="h-5 w-5" />
        </button>
      </div>

      {/* Mobile / tablet drawer */}
      <div
        id="mobile-nav"
        className={cn(
          "fixed inset-0 z-[60] lg:hidden",
          open ? "pointer-events-auto" : "pointer-events-none",
        )}
        aria-hidden={!open}
      >
        <div
          className={cn(
            "absolute inset-0 bg-ink/70 backdrop-blur-sm transition-opacity duration-500",
            open ? "opacity-100" : "opacity-0",
          )}
          onClick={() => setOpen(false)}
        />
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Site navigation"
          className={cn(
            "absolute top-0 right-0 flex h-full w-full max-w-sm flex-col border-l border-white/10 bg-ink text-white shadow-lift transition-transform duration-600 ease-luxe",
            open ? "translate-x-0" : "translate-x-full",
          )}
        >
          <div className="flex items-center justify-between border-b border-white/10 px-6 py-5">
            <Logo height={36} />
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="inline-flex h-11 w-11 items-center justify-center rounded-brand border border-white/20 transition-colors hover:border-gold hover:text-gold"
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <nav aria-label="Mobile" className="flex-1 overflow-y-auto px-6 py-6">
            <ul className="space-y-1">
              {site.nav.map((item, i) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={isActive(item.href) ? "page" : undefined}
                    className={cn(
                      "group flex items-center justify-between border-b border-white/10 py-4 font-display text-3xl transition-colors",
                      isActive(item.href) ? "text-gold" : "text-white hover:text-gold",
                    )}
                    style={{ transitionDelay: `${i * 30}ms` }}
                  >
                    {item.label}
                    <span className="h-px w-6 bg-gold opacity-0 transition-all duration-500 group-hover:w-10 group-hover:opacity-100" />
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="space-y-3 border-t border-white/10 px-6 py-6">
            <Link href="/book" className="btn btn-gold w-full">
              Book Appointment
            </Link>
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-outline-light w-full"
            >
              <WhatsAppIcon className="h-4 w-4" /> WhatsApp
            </a>
            <a href={telLink()} className="btn btn-outline-light w-full">
              <Phone className="h-4 w-4" /> Call Clinic
            </a>
            <p className="pt-2 text-center text-[11px] tracking-[0.2em] text-white/50 uppercase">
              {site.location.full}
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}
