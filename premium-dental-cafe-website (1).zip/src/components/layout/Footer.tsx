import Link from "next/link";
import { MapPin, Phone, Star, Mail, Clock } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { FacebookIcon, InstagramIcon, WhatsAppIcon } from "@/components/ui/icons";
import { Placeholder } from "@/components/ui/SectionHeading";
import { PLACEHOLDERS, site } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/links";

export function Footer() {
  return (
    <footer className="bg-ink text-white">
      <div className="gold-line" />
      <div className="container-x py-16 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-12">
          {/* Brand */}
          <div className="lg:col-span-4">
            <Logo height={48} />
            <p className="mt-6 max-w-sm text-[15px] leading-7 text-white/65">
              {site.tagline}. Professional, comfortable and personalized dental care in{" "}
              {site.location.area}, {site.location.city}.
            </p>
            <div className="mt-6 flex items-center gap-3">
              <div className="flex items-center gap-1 text-gold" aria-label={`${site.rating.value} out of 5 stars`}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <span className="text-sm text-white/70">
                {site.rating.value} · {site.rating.count} Google Reviews
              </span>
            </div>
          </div>

          {/* Navigate */}
          <div className="lg:col-span-2">
            <h3 className="font-sans text-[11px] font-semibold tracking-[0.3em] text-gold uppercase">Navigate</h3>
            <ul className="mt-6 space-y-3">
              {site.nav.map((n) => (
                <li key={n.href}>
                  <Link href={n.href} className="text-[15px] text-white/75 transition-colors hover:text-gold">
                    {n.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="lg:col-span-3">
            <h3 className="font-sans text-[11px] font-semibold tracking-[0.3em] text-gold uppercase">Contact</h3>
            <ul className="mt-6 space-y-4 text-[15px] text-white/75">
              <li className="flex items-start gap-3">
                <MapPin className="mt-1 h-4 w-4 shrink-0 text-gold" />
                <a href={site.location.mapsUrl} target="_blank" rel="noopener noreferrer" className="hover:text-gold">
                  {site.name}
                  <br />
                  {site.location.full}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="mt-1 h-4 w-4 shrink-0 text-gold" />
                <div>
                  <a href={telLink()} className="hover:text-gold">{site.contact.phone}</a>
                  <br />
                  <a href={telLink(site.contact.additionalPhoneE164)} className="text-white/55 hover:text-gold">
                    {site.contact.additionalPhone}
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <WhatsAppIcon className="mt-1 h-4 w-4 shrink-0 text-gold" />
                <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="hover:text-gold">
                  WhatsApp {site.whatsapp.display}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="mt-1 h-4 w-4 shrink-0 text-gold" />
                {site.contact.email ? (
                  <a href={`mailto:${site.contact.email}`} className="hover:text-gold">{site.contact.email}</a>
                ) : (
                  <Placeholder label={PLACEHOLDERS.email} />
                )}
              </li>
              <li className="flex items-start gap-3">
                <Clock className="mt-1 h-4 w-4 shrink-0 text-gold" />
                {site.hours ? (
                  <div>{site.hours.map((h) => <div key={h}>{h}</div>)}</div>
                ) : (
                  <Placeholder label={PLACEHOLDERS.hours} />
                )}
              </li>
            </ul>
          </div>

          {/* Connect */}
          <div className="lg:col-span-3">
            <h3 className="font-sans text-[11px] font-semibold tracking-[0.3em] text-gold uppercase">Connect</h3>
            <ul className="mt-6 space-y-3 text-[15px] text-white/75">
              <li>
                <a href={site.social.instagram} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 hover:text-gold">
                  <InstagramIcon className="h-4 w-4 text-gold" /> Instagram
                </a>
              </li>
              <li>
                <a href={site.social.facebook} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 hover:text-gold">
                  <FacebookIcon className="h-4 w-4 text-gold" /> Facebook
                </a>
              </li>
              <li>
                <a href={site.location.mapsUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 hover:text-gold">
                  <MapPin className="h-4 w-4 text-gold" /> Google Maps
                </a>
              </li>
            </ul>
            <Link href="/book" className="btn btn-gold mt-8 w-full sm:w-auto">
              Book Appointment
            </Link>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-x flex flex-col items-start justify-between gap-4 py-6 text-[12px] tracking-wide text-white/50 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} {site.name}. All rights reserved.</p>
          <ul className="flex flex-wrap gap-x-6 gap-y-2">
            {site.legalNav.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="hover:text-gold">{l.label}</Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}
