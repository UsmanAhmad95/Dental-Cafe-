import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Picture } from "@/components/ui/Picture";
import { getAsset } from "@/content/assets";
import type { Doctor } from "@/content/doctors";
import { PLACEHOLDERS } from "@/content/site";
import { bookingLink } from "@/lib/links";
import { cn, initials } from "@/lib/utils";

/**
 * Doctor portrait — renders the ORIGINAL supplied photo (top-aligned so faces
 * are never awkwardly cropped) or an identity-safe monogram placeholder.
 */
export function DoctorPortrait({
  doctor,
  className,
  tone = "light",
  priority,
}: {
  doctor: Doctor;
  className?: string;
  tone?: "light" | "dark";
  priority?: boolean;
}) {
  const asset = getAsset(doctor.photo);
  if (asset.status === "missing") {
    return (
      <div
        role="img"
        aria-label={`${doctor.name} — photo placeholder`}
        className={cn(
          "relative flex flex-col items-center justify-center overflow-hidden rounded-brand border border-dashed",
          tone === "dark" ? "border-gold/50 bg-ink-muted" : "border-gold/70 bg-cream",
          className,
        )}
      >
        <span
          aria-hidden
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at 50% 35%, rgba(198,161,91,0.22) 0%, rgba(198,161,91,0) 62%)",
          }}
        />
        <span aria-hidden className="relative grid h-24 w-24 place-items-center rounded-full border border-gold/70">
          <span className="font-display text-5xl text-gold">{initials(doctor.name)}</span>
        </span>
        <span className="relative mt-6 font-mono text-[11px] tracking-[0.18em] text-gold-deep">
          {PLACEHOLDERS.doctorPhoto}
        </span>
        <span className={cn("relative mt-1 font-mono text-[10px]", tone === "dark" ? "text-white/40" : "text-stone/70")}>
          {asset.src.split("/").pop()}
        </span>
      </div>
    );
  }
  return (
    <Picture
      asset={doctor.photo}
      className={className}
      imgClassName="object-top"
      sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
      priority={priority}
    />
  );
}

export function DoctorCard({ doctor, tone = "dark" }: { doctor: Doctor; tone?: "light" | "dark" }) {
  const dark = tone === "dark";
  return (
    <article
      className={cn(
        "group card-hover flex h-full flex-col overflow-hidden",
        dark ? "card-dark" : "card",
      )}
    >
      <Link href={`/doctors/${doctor.slug}`} className="block" aria-label={`View profile of ${doctor.name}`}>
        <DoctorPortrait doctor={doctor} tone={tone} className="aspect-[4/5] w-full" />
      </Link>
      <div className="flex flex-1 flex-col p-6">
        <p className="text-[11px] font-semibold tracking-[0.26em] text-gold uppercase">
          {doctor.specialization ?? doctor.tagline ?? "Dental Cafe"}
        </p>
        <h3 className={cn("mt-2 font-display text-2xl leading-tight", dark ? "text-white" : "text-ink")}>
          {doctor.name}
        </h3>
        <p className={cn("mt-1 text-sm", dark ? "text-white/60" : "text-stone")}>
          {doctor.qualification ?? <span className="placeholder-tag">{PLACEHOLDERS.doctorQualification}</span>}
        </p>
        <p className={cn("mt-4 line-clamp-3 text-[15px] leading-7", dark ? "text-white/65" : "text-ink/70")}>
          {doctor.bio ?? (
            <span className="placeholder-tag">{PLACEHOLDERS.doctorBio}</span>
          )}
        </p>
        <div className="mt-auto flex items-center justify-between gap-3 pt-6">
          <Link
            href={`/doctors/${doctor.slug}`}
            className="inline-flex items-center gap-2 text-[12px] font-semibold tracking-[0.2em] text-gold uppercase transition-colors hover:text-gold-deep"
          >
            View Profile <ArrowUpRight className="h-4 w-4" />
          </Link>
          <Link href={bookingLink({ doctor: doctor.slug })} className={cn("btn btn-sm", dark ? "btn-outline-light" : "btn-primary")}>
            Book
          </Link>
        </div>
      </div>
    </article>
  );
}
