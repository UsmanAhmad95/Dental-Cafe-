import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Picture } from "@/components/ui/Picture";
import type { BlogPost } from "@/content/blog";
import { formatDate } from "@/lib/utils";

export function PostCard({ post, featured = false }: { post: BlogPost; featured?: boolean }) {
  return (
    <article className={`group card card-hover flex h-full flex-col overflow-hidden ${featured ? "lg:grid lg:grid-cols-2" : ""}`}>
      <Link href={`/blog/${post.slug}`} className="block" aria-label={post.title}>
        <Picture
          asset={post.cover}
          className={`${featured ? "aspect-[4/3] lg:h-full lg:min-h-[360px]" : "aspect-[16/10]"} w-full`}
          imgClassName="img-zoom"
          sizes="(min-width:1024px) 50vw, 100vw"
        />
      </Link>
      <div className={`flex flex-1 flex-col ${featured ? "p-8 lg:p-10" : "p-7"}`}>
        <div className="flex items-center gap-3 text-[11px] font-semibold tracking-[0.22em] uppercase">
          <span className="text-gold">{post.category}</span>
          <span className="h-px w-4 bg-ink/20" />
          <span className="text-stone">{formatDate(post.date)}</span>
        </div>
        <h2 className={`mt-4 font-display leading-tight text-ink ${featured ? "text-4xl" : "text-2xl"}`}>
          <Link href={`/blog/${post.slug}`} className="hover:text-gold-deep">{post.title}</Link>
        </h2>
        <p className="mt-3 text-[15px] leading-7 text-ink/70">{post.excerpt}</p>
        <div className="mt-auto flex items-center justify-between pt-6 text-xs text-stone">
          <span>{post.readingTime}</span>
          <Link href={`/blog/${post.slug}`} className="inline-flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-gold uppercase hover:text-gold-deep">
            Read Article <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </article>
  );
}
