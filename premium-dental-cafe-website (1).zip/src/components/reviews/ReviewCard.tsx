import { Star, ArrowUpRight } from "lucide-react";
import { GoogleIcon } from "@/components/ui/icons";
import { reviewSummary, type Review } from "@/content/reviews";
import { cn, formatDate, initials, isPlaceholder } from "@/lib/utils";

export function Stars({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn("flex items-center gap-1 text-gold", className)} aria-label={`${value} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={cn("h-4 w-4", i < value ? "fill-current" : "opacity-30")} />
      ))}
    </div>
  );
}

export function ReviewCard({ review }: { review: Review }) {
  const placeholder = review.placeholder || isPlaceholder(review.name);
  const link = review.googleUrl ?? reviewSummary.url;

  return (
    <article
      className={cn(
        "flex h-full flex-col rounded-brand p-7",
        placeholder ? "border border-dashed border-gold/70 bg-cream" : "card",
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <span
            aria-hidden
            className="grid h-12 w-12 shrink-0 place-items-center rounded-full border border-gold/60 bg-white font-display text-xl text-gold"
          >
            {placeholder ? "?" : initials(review.name)}
          </span>
          <div>
            <h3 className={cn("text-[15px] font-semibold", placeholder ? "font-mono text-[12px] tracking-wide text-gold-deep" : "text-ink")}>
              {review.name}
            </h3>
            <p className="mt-0.5 text-xs text-stone">
              {review.reviewerMeta?.localGuide ? "Local Guide · " : ""}
              {review.reviewerMeta?.reviewCount ? `${review.reviewerMeta.reviewCount} reviews · ` : ""}
              {review.date ? formatDate(review.date) : placeholder ? "[ADD DATE]" : ""}
            </p>
          </div>
        </div>
        <GoogleIcon className="h-5 w-5 shrink-0 text-ink/60" />
      </div>

      <Stars value={review.rating} className="mt-5" />

      <p className={cn("mt-4 flex-1 text-[15px] leading-7", placeholder ? "font-mono text-[12px] text-gold-deep" : "text-ink/75")}>
        {review.reviewText ?? "[ADD REVIEW TEXT]"}
      </p>

      {review.ownerResponse ? (
        <div className="mt-5 border-l-2 border-gold pl-4 text-sm leading-6 text-ink/65">
          <p className="mb-1 text-[11px] font-semibold tracking-[0.2em] text-gold uppercase">Response from Dental Cafe</p>
          {review.ownerResponse}
        </div>
      ) : null}

      <a
        href={link}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-6 inline-flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-gold uppercase transition-colors hover:text-gold-deep"
      >
        Read full review on Google <ArrowUpRight className="h-4 w-4" />
      </a>
    </article>
  );
}
