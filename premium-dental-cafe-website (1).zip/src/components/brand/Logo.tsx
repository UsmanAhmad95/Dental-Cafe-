import Link from "next/link";
import { brandAssets } from "@/content/assets";
import { site } from "@/content/site";
import { cn } from "@/lib/utils";

/**
 * =====================================================================
 * <Logo /> — the ONE component every brand-logo instance uses
 * (header, footer, mobile drawer, admin).
 *
 * Asset location:  /public/assets/brand/logo.png  (see README.txt there)
 * Registry:        src/content/assets.ts → brandAssets
 *
 * The image is rendered with a fixed height and automatic width, so the
 * original proportions are always preserved (never stretched). When no
 * official file is present yet (status "missing"), a typographic
 * wordmark fallback is shown so the layout is never broken.
 * =====================================================================
 */

interface LogoProps {
  /** "onDark" for black backgrounds, "onLight" for white backgrounds */
  variant?: "onDark" | "onLight";
  height?: number;
  linked?: boolean;
  className?: string;
  priority?: boolean;
}

export function Logo({ variant = "onDark", height = 44, linked = true, className }: LogoProps) {
  const asset =
    variant === "onLight" && brandAssets.logoOnLight.status === "real"
      ? brandAssets.logoOnLight
      : brandAssets.logo;

  const content =
    asset.status === "real" ? (
      // Native <img> so ANY logo file keeps its exact aspect ratio without config.
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={asset.src}
        alt={asset.alt}
        style={{ height, width: "auto" }}
        className="block max-w-[220px] object-contain object-left sm:max-w-[260px]"
        decoding="async"
      />
    ) : (
      <Wordmark variant={variant} height={height} />
    );

  if (!linked) return <span className={cn("inline-flex items-center", className)}>{content}</span>;

  return (
    <Link
      href="/"
      aria-label={`${site.name} — home`}
      className={cn("inline-flex items-center rounded-brand", className)}
    >
      {content}
    </Link>
  );
}

/** Typographic fallback shown until the official logo file is dropped in. */
function Wordmark({ variant, height }: { variant: "onDark" | "onLight"; height: number }) {
  const text = variant === "onDark" ? "text-white" : "text-ink";
  const mark = Math.round(height * 0.95);
  return (
    <span className="inline-flex items-center gap-3 whitespace-nowrap" style={{ height }}>
      <span
        aria-hidden
        className="grid shrink-0 place-items-center rounded-full border border-gold"
        style={{ height: mark, width: mark }}
      >
        <span className="font-display leading-none text-gold" style={{ fontSize: mark * 0.46 }}>
          DC
        </span>
      </span>
      <span className="flex flex-col justify-center leading-none">
        <span
          className={cn("font-display font-semibold uppercase tracking-[0.2em]", text)}
          style={{ fontSize: Math.max(16, height * 0.47) }}
        >
          Dental Cafe
        </span>
        <span
          className="mt-1 text-gold uppercase tracking-[0.32em]"
          style={{ fontSize: Math.max(7, height * 0.17) }}
        >
          Where your smile comes first
        </span>
      </span>
    </span>
  );
}
