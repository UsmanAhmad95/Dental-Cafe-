import { createHash, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

export const ADMIN_COOKIE = "dc_admin_session";

function adminPassword() {
  return process.env.ADMIN_PASSWORD?.trim() || null;
}

export function isAdminConfigured() {
  return adminPassword() !== null;
}

function sessionToken(password: string) {
  return createHash("sha256").update(`dental-cafe-admin::${password}`).digest("hex");
}

export function verifyPassword(input: string) {
  const pw = adminPassword();
  if (!pw) return false;
  const a = Buffer.from(sessionToken(input));
  const b = Buffer.from(sessionToken(pw));
  return a.length === b.length && timingSafeEqual(a, b);
}

export function tokenForConfiguredPassword() {
  const pw = adminPassword();
  return pw ? sessionToken(pw) : null;
}

export async function isAdminAuthenticated() {
  const expected = tokenForConfiguredPassword();
  if (!expected) return false;
  const store = await cookies();
  const value = store.get(ADMIN_COOKIE)?.value;
  if (!value || value.length !== expected.length) return false;
  return timingSafeEqual(Buffer.from(value), Buffer.from(expected));
}
