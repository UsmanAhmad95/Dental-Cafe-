import { site } from "@/content/site";

export function whatsappLink(message: string = site.whatsapp.defaultMessage) {
  return `https://wa.me/${site.whatsapp.number}?text=${encodeURIComponent(message)}`;
}

export function telLink(e164: string = site.contact.phoneE164) {
  return `tel:${e164}`;
}

export function bookingLink(params?: { treatment?: string; doctor?: string }) {
  const sp = new URLSearchParams();
  if (params?.treatment) sp.set("treatment", params.treatment);
  if (params?.doctor) sp.set("doctor", params.doctor);
  const q = sp.toString();
  return q ? `/book?${q}` : "/book";
}

export function doctorWhatsappLink(doctorName: string) {
  return whatsappLink(
    `Hello Dental Cafe, I would like to book a dental appointment with ${doctorName}.`,
  );
}

export function serviceWhatsappLink(serviceName: string) {
  return whatsappLink(
    `Hello Dental Cafe, I would like to book a dental appointment for ${serviceName}.`,
  );
}
