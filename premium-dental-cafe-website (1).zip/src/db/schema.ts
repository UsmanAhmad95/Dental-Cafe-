import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

/**
 * Appointment REQUESTS submitted from the website booking wizard.
 * A row here is a request only — the clinic confirms by phone/WhatsApp.
 */
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  reference: varchar("reference", { length: 24 }).notNull().unique(),
  treatmentSlug: varchar("treatment_slug", { length: 120 }).notNull(),
  treatmentName: text("treatment_name").notNull(),
  doctorSlug: varchar("doctor_slug", { length: 120 }),
  doctorName: text("doctor_name"),
  preferredDate: varchar("preferred_date", { length: 10 }).notNull(),
  preferredTime: varchar("preferred_time", { length: 40 }).notNull(),
  patientName: text("patient_name").notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 40 }),
  message: text("message"),
  status: varchar("status", { length: 20 }).notNull().default("new"), // new | contacted | confirmed | closed
  source: varchar("source", { length: 40 }).notNull().default("website"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Appointment = typeof appointments.$inferSelect;
export type NewAppointment = typeof appointments.$inferInsert;

/**
 * Optional key/value settings table — ready for a future admin layer to
 * override content (opening hours, email, etc.) without a redeploy.
 */
export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 120 }).notNull().unique(),
  value: text("value"),
  version: integer("version").notNull().default(1),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
