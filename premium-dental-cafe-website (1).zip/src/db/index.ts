import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Lazy PostgreSQL client.
 *
 * The connection pool is created on FIRST USE, not at import time. This means
 * `next build` and Docker image builds succeed without a live database — only
 * requests that actually touch the database (booking API, /admin, /api/health)
 * need DATABASE_URL to be set in the hosting environment.
 *
 * Works with local Postgres, Neon, Supabase, Railway, Render, RDS, etc.
 * Remote hosts get SSL automatically unless the URL already specifies `sslmode`.
 */

const globalForDb = globalThis as typeof globalThis & {
  __dentalCafePool?: Pool;
  __dentalCafeDb?: NodePgDatabase;
};

function resolveSsl(url: string): false | { rejectUnauthorized: boolean } | undefined {
  if (process.env.DATABASE_SSL === "false") return false;
  if (/[?&]sslmode=/i.test(url)) return undefined; // let `pg` honour the URL
  try {
    const host = new URL(url).hostname;
    const local =
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "::1" ||
      host.endsWith(".internal") ||
      host === "db" ||
      host === "postgres";
    return local ? undefined : { rejectUnauthorized: false };
  } catch {
    return undefined;
  }
}

export function getPool(): Pool {
  if (!globalForDb.__dentalCafePool) {
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error(
        "DATABASE_URL is required. Set it in .env (local) or in your hosting provider's environment variables (see DEPLOY.md).",
      );
    }
    globalForDb.__dentalCafePool = new Pool({
      connectionString: databaseUrl,
      ssl: resolveSsl(databaseUrl),
      max: 10,
      idleTimeoutMillis: 30_000,
    });
  }
  return globalForDb.__dentalCafePool;
}

export function getDb(): NodePgDatabase {
  if (!globalForDb.__dentalCafeDb) {
    globalForDb.__dentalCafeDb = drizzle(getPool());
  }
  return globalForDb.__dentalCafeDb;
}

/**
 * `db` — the client used throughout the app (`import { db } from "@/db"`).
 * A thin lazy proxy: the real Drizzle instance is resolved on first property
 * access, so importing this module never opens a connection.
 */
export const db: NodePgDatabase = new Proxy({} as NodePgDatabase, {
  get(_target, prop) {
    const real = getDb() as unknown as Record<PropertyKey, unknown>;
    const value = real[prop];
    return typeof value === "function"
      ? (value as (...args: unknown[]) => unknown).bind(real)
      : value;
  },
});
