import type { ImageAssetKey } from "./assets";

/**
 * DENTAL CAFE — BLOG (editable). Educational content only; no medical
 * guarantees. Add posts here — index, article and related pages update.
 */

export const blogCategories = [
  "Oral Health",
  "Dental Care",
  "Cosmetic Dentistry",
  "Preventive Dentistry",
  "Dental Implants",
  "Orthodontics",
] as const;

export type BlogCategory = (typeof blogCategories)[number];

export type BlogBlock =
  | { type: "p"; text: string }
  | { type: "h2"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "quote"; text: string };

export interface BlogPost {
  slug: string;
  title: string;
  category: BlogCategory;
  excerpt: string;
  cover: ImageAssetKey;
  date: string; // ISO
  readingTime: string;
  author: string;
  body: BlogBlock[];
}

export const blogPosts: BlogPost[] = [
  {
    slug: "how-often-should-you-visit-the-dentist",
    title: "How Often Should You Visit the Dentist?",
    category: "Preventive Dentistry",
    excerpt:
      "Regular check-ups are one of the simplest ways to protect your smile. Here is how to think about the right interval for you.",
    cover: "blog-checkups",
    date: "2026-01-12",
    readingTime: "4 min read",
    author: "Dental Cafe",
    body: [
      { type: "p", text: "Most people know they should see a dentist regularly, but \"regularly\" means different things to different patients. The right interval depends on your oral health history, your daily habits and any treatment you may be undergoing." },
      { type: "h2", text: "Why routine visits matter" },
      { type: "p", text: "Many dental concerns develop quietly. Early-stage decay or gum inflammation often causes no discomfort at all, which is exactly why a professional examination is valuable. Identifying a small issue early usually means simpler, more comfortable care." },
      { type: "ul", items: ["A check of your teeth, gums and soft tissues", "Advice tailored to your brushing and flossing routine", "Imaging when your dentist considers it helpful", "A clear plan if anything needs attention"] },
      { type: "h2", text: "Finding the interval that suits you" },
      { type: "p", text: "Many dentists suggest a review every six months as a general guide, but your dentist may recommend seeing you more or less often depending on your individual risk. Patients with a history of gum problems, those wearing braces, or those with certain medical conditions may benefit from closer follow-up." },
      { type: "quote", text: "Prevention is rarely dramatic — it is the quiet, consistent habit that keeps smiles healthy." },
      { type: "p", text: "If it has been a while since your last visit, there is no need to feel awkward. Our team in DHA Phase 4 will simply pick up from where you are today and help you plan the next step." },
    ],
  },
  {
    slug: "a-simple-daily-routine-for-healthier-gums",
    title: "A Simple Daily Routine for Healthier Gums",
    category: "Oral Health",
    excerpt:
      "Healthy gums are the foundation of a healthy smile. A calm, consistent routine makes more difference than any single product.",
    cover: "blog-daily-care",
    date: "2026-01-26",
    readingTime: "3 min read",
    author: "Dental Cafe",
    body: [
      { type: "p", text: "Gum health is easy to overlook until something feels wrong. Bleeding when brushing, tenderness or persistent bad breath can all be early signs that your gums need a little more care." },
      { type: "h2", text: "The essentials" },
      { type: "ul", items: ["Brush twice a day for around two minutes with a soft-bristled brush", "Angle the bristles gently toward the gum line", "Clean between your teeth daily with floss or interdental brushes", "Replace your toothbrush every three months or when bristles fray"] },
      { type: "h2", text: "Small habits, steady results" },
      { type: "p", text: "Technique matters more than force. Scrubbing hard can irritate gums rather than help them. If you are unsure whether your technique is right, ask at your next visit — a short demonstration is often all it takes." },
      { type: "p", text: "If bleeding continues despite a good routine, it is worth having your gums assessed. Your dentist can identify the cause and recommend the most appropriate care." },
    ],
  },
  {
    slug: "what-to-expect-at-your-first-visit",
    title: "What to Expect at Your First Dental Cafe Visit",
    category: "Dental Care",
    excerpt:
      "New to Dental Cafe? Here is how a first appointment unfolds, from arrival to your personalized plan.",
    cover: "blog-first-visit",
    date: "2026-02-09",
    readingTime: "3 min read",
    author: "Dental Cafe",
    body: [
      { type: "p", text: "A first visit should feel welcoming, unhurried and clear. Whether you are coming in for a routine check or a specific concern, knowing what to expect can make the experience more comfortable." },
      { type: "h2", text: "Before you arrive" },
      { type: "p", text: "Appointments are recommended. Request one online, call +92 332 4679934 or message us on WhatsApp. If you have any medical conditions, medications or previous dental records, bringing those details helps us plan your care." },
      { type: "h2", text: "During your appointment" },
      { type: "ul", items: ["A conversation about your concerns and goals", "A thorough examination of your teeth, gums and mouth", "Imaging if your dentist considers it useful", "A plain-language explanation of what we find"] },
      { type: "h2", text: "Your personalized plan" },
      { type: "p", text: "If treatment is recommended, we explain the options, the sequence and what each step involves. Decisions are made together — you will never be rushed. If you feel nervous, tell us; a gentle, comfort-focused approach is at the heart of how we work." },
    ],
  },
  {
    slug: "dental-implants-explained",
    title: "Dental Implants Explained: A Calm, Clear Overview",
    category: "Dental Implants",
    excerpt:
      "Considering an implant to replace a missing tooth? This overview explains what implants are and how treatment generally unfolds.",
    cover: "blog-implants",
    date: "2026-02-23",
    readingTime: "5 min read",
    author: "Dental Cafe",
    body: [
      { type: "p", text: "A dental implant is a small titanium post placed in the jaw to act as an artificial tooth root. Once it has integrated with the bone, it can support a crown, bridge or denture, restoring both function and appearance." },
      { type: "h2", text: "Who might consider an implant?" },
      { type: "p", text: "Implants are often considered by adults with one or more missing teeth who want a fixed alternative to removable options. Suitability depends on gum health, available bone and general health — which is why treatment always begins with an assessment." },
      { type: "h2", text: "How treatment generally unfolds" },
      { type: "ul", items: ["Consultation, examination and imaging", "A personalized plan covering timeline and cost", "Implant placement under local anaesthesia", "A healing period while the implant integrates", "Fitting of the final custom restoration"] },
      { type: "h2", text: "Looking after an implant" },
      { type: "p", text: "Implants are cared for much like natural teeth: daily brushing and interdental cleaning, plus regular professional reviews. Good hygiene is one of the most important factors in long-term success." },
      { type: "p", text: "At Dental Cafe, implant care is led by our implantologist, Dr. Umair Bhalli. A consultation is the best way to learn whether implants are right for you." },
    ],
  },
  {
    slug: "braces-or-aligners-questions-to-ask",
    title: "Braces or Aligners? Questions to Ask Your Orthodontist",
    category: "Orthodontics",
    excerpt:
      "Choosing between orthodontic options is easier when you know which questions matter. Start with these.",
    cover: "blog-orthodontics",
    date: "2026-03-09",
    readingTime: "4 min read",
    author: "Dental Cafe",
    body: [
      { type: "p", text: "Orthodontic treatment moves teeth into healthier, better-aligned positions. Different appliances suit different situations, and the best choice depends on your bite, your goals and your lifestyle." },
      { type: "h2", text: "Useful questions for your consultation" },
      { type: "ul", items: ["Which options are suitable for my specific case?", "How long is treatment likely to take?", "How often will I need to attend for reviews?", "What will daily care look like during treatment?", "What happens after treatment to maintain the result?"] },
      { type: "h2", text: "Why a specialist assessment matters" },
      { type: "p", text: "An orthodontist assesses not only the position of your teeth but how your jaws meet. That broader view shapes a plan that is designed to be stable in the long term, not just straight in the short term." },
      { type: "p", text: "Orthodontic treatment at Dental Cafe is led by Dr. Abdullah, BDS, FCPS (Orthodontics). Book a consultation to discuss the approach that suits you." },
    ],
  },
  {
    slug: "cosmetic-dentistry-understanding-your-options",
    title: "Cosmetic Dentistry: Understanding Your Options",
    category: "Cosmetic Dentistry",
    excerpt:
      "From subtle refinements to broader smile design, cosmetic dentistry works best when it looks natural and respects healthy tooth structure.",
    cover: "blog-cosmetic",
    date: "2026-03-23",
    readingTime: "4 min read",
    author: "Dental Cafe",
    body: [
      { type: "p", text: "Cosmetic dentistry focuses on the appearance of your smile — the shade, shape, alignment and proportion of your teeth. The most successful results tend to be the ones people do not notice as \"work\" at all." },
      { type: "h2", text: "Start with health" },
      { type: "p", text: "Before any cosmetic treatment, your dentist will want to make sure your teeth and gums are healthy. A stable foundation protects your result and often simplifies the plan." },
      { type: "h2", text: "Common approaches" },
      { type: "ul", items: ["Professional whitening to brighten the natural shade", "Bonding or veneers to refine shape and surface", "Orthodontic alignment to correct position", "Combinations planned as part of a broader smile design"] },
      { type: "h2", text: "A conversation, not a catalogue" },
      { type: "p", text: "The right option depends on what you would like to change and what your dentist observes. A consultation lets you discuss expectations openly and understand what each approach involves. To ask about availability of specific cosmetic treatments at Dental Cafe, message us on WhatsApp." },
    ],
  },
];

export const sortedPosts = [...blogPosts].sort((a, b) => (a.date < b.date ? 1 : -1));

export function getPost(slug: string) {
  return blogPosts.find((p) => p.slug === slug) ?? null;
}

export function getRelatedPosts(post: BlogPost, limit = 3) {
  const sameCategory = sortedPosts.filter((p) => p.slug !== post.slug && p.category === post.category);
  const others = sortedPosts.filter((p) => p.slug !== post.slug && p.category !== post.category);
  return [...sameCategory, ...others].slice(0, limit);
}
