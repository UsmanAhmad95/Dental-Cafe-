/**
 * =====================================================================
 * DENTAL CAFE — SITE SETTINGS (single source of truth)
 * Edit brand copy, contact details, socials, hours and SEO here.
 * Only VERIFIED business information belongs in this file.
 * Unknown values stay `null` and render as identifiable placeholders.
 * =====================================================================
 */

export const PLACEHOLDERS = {
  email: "[ADD CLINIC EMAIL]",
  hours: "[ADD OPENING HOURS]",
  doctorBio: "[ADD DOCTOR BIO]",
  doctorQualification: "[ADD QUALIFICATION]",
  doctorSpecialization: "[ADD SPECIALIZATION]",
  doctorExperience: "[ADD EXPERIENCE]",
  doctorLanguages: "[ADD LANGUAGES]",
  serviceDetails: "[ADD SERVICE DETAILS]",
  video: "[ADD VIDEO]",
  galleryImage: "[ADD GALLERY IMAGE]",
  doctorPhoto: "[ADD DOCTOR PHOTO]",
  beforeImage: "[ADD BEFORE IMAGE]",
  afterImage: "[ADD AFTER IMAGE]",
  review: "[ADD GENUINE GOOGLE REVIEW]",
} as const;

export const site = {
  name: "Dental Cafe",
  tagline: "Where Your Smile Comes First",
  shortDescription:
    "Professional, comfortable and personalized dental care in DHA Phase 4, Lahore.",
  description:
    "Dental Cafe is a patient-centered dental clinic in DHA Phase 4, Lahore, offering professional, comfortable and personalized dental care — rated 5.0 on Google from 145 reviews.",
  /**
   * Public site URL used for SEO metadata, Open Graph, sitemap and robots.
   * Set NEXT_PUBLIC_SITE_URL in production. Falls back to the URL provided
   * automatically by Vercel or Netlify, then to localhost for development.
   */
  url:
    process.env.NEXT_PUBLIC_SITE_URL ??
    (process.env.VERCEL_PROJECT_PRODUCTION_URL
      ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
      : process.env.URL?.startsWith("http")
        ? process.env.URL
        : "http://localhost:3000"),
  locale: "en_PK",

  location: {
    area: "DHA Phase 4",
    city: "Lahore",
    region: "Punjab",
    country: "Pakistan",
    countryCode: "PK",
    full: "DHA Phase 4, Lahore, Pakistan",
    mapsUrl: "https://maps.app.goo.gl/wa2MZhBiKGsY69L68",
    /** Embed query (no API key required). Replace with a Google Maps embed URL if preferred. */
    mapsEmbedUrl:
      "https://www.google.com/maps?q=Dental+Cafe+DHA+Phase+4+Lahore&output=embed",
  },

  contact: {
    phone: "+92 332 4679934",
    phoneE164: "+923324679934",
    bookingPhone: "+92 332 4679934",
    bookingPhoneE164: "+923324679934",
    additionalPhone: "+92 327 6445111",
    additionalPhoneE164: "+923276445111",
    additionalPhoneLabel: "Additional Line",
    email: null as string | null, // -> renders PLACEHOLDERS.email
  },

  whatsapp: {
    number: "923324679934",
    display: "+92 332 4679934",
    defaultMessage: "Hello Dental Cafe, I would like to book a dental appointment.",
  },

  rating: {
    value: "5.0",
    numeric: 5,
    count: 145,
    platform: "Google",
  },

  social: {
    instagram: "https://www.instagram.com/dentalcafe.ju/",
    facebook: "https://www.facebook.com/dentalcafe.drju/photos",
  },

  /** e.g. ["Monday – Saturday: 10:00 AM – 8:00 PM", "Sunday: Closed"] */
  hours: null as string[] | null,

  nav: [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Doctors", href: "/doctors" },
    { label: "Services", href: "/services" },
    { label: "Gallery", href: "/gallery" },
    { label: "Reviews", href: "/reviews" },
    { label: "Blog", href: "/blog" },
    { label: "Contact", href: "/contact" },
  ],

  legalNav: [
    { label: "Privacy Policy", href: "/privacy-policy" },
    { label: "Terms & Conditions", href: "/terms" },
  ],

  seoKeywords: [
    "Dental Clinic DHA Phase 4 Lahore",
    "Dentist DHA Lahore",
    "Dental Clinic Lahore",
    "Dental Implants Lahore",
    "Orthodontist DHA Lahore",
    "Dental Cafe",
  ],
} as const;

export type NavItem = (typeof site.nav)[number];
