import { site, PLACEHOLDERS } from "./site";

/**
 * =====================================================================
 * DENTAL CAFE — GOOGLE REVIEWS (editable data, never hard-coded in UI)
 *
 * Copy reviewer names and text EXACTLY as written on Google.
 * If a review is truncated, paste the genuine available excerpt and the
 * UI will show "Read full review on Google".
 * Entries with `placeholder: true` render as identifiable placeholders.
 * =====================================================================
 */

export interface ReviewerMeta {
  localGuide?: boolean;
  reviewCount?: number | null;
  photoCount?: number | null;
}

export interface Review {
  id: string;
  name: string;
  rating: number; // 1–5
  date: string | null; // ISO (YYYY-MM-DD) or a Google-style relative label
  reviewText: string | null;
  ownerResponse: string | null;
  googleUrl: string | null;
  reviewerMeta: ReviewerMeta | null;
  featured: boolean;
  placeholder?: boolean;
}

export const reviewSummary = {
  rating: site.rating.value,
  numeric: site.rating.numeric,
  count: site.rating.count,
  platform: site.rating.platform,
  url: site.location.mapsUrl,
};

export const reviews: Review[] = [
  {
    id: "review-01",
    name: "[ADD REVIEWER NAME]",
    rating: 5,
    date: null,
    reviewText: PLACEHOLDERS.review,
    ownerResponse: null,
    googleUrl: null,
    reviewerMeta: null,
    featured: true,
    placeholder: true,
  },
  {
    id: "review-02",
    name: "[ADD REVIEWER NAME]",
    rating: 5,
    date: null,
    reviewText: PLACEHOLDERS.review,
    ownerResponse: null,
    googleUrl: null,
    reviewerMeta: null,
    featured: true,
    placeholder: true,
  },
  {
    id: "review-03",
    name: "[ADD REVIEWER NAME]",
    rating: 5,
    date: null,
    reviewText: PLACEHOLDERS.review,
    ownerResponse: null,
    googleUrl: null,
    reviewerMeta: null,
    featured: true,
    placeholder: true,
  },
];

export const featuredReviews = reviews.filter((r) => r.featured).slice(0, 3);
