import type { ImageAssetKey } from "./assets";

/**
 * DENTAL CAFE — GALLERY (editable). Each item points to an asset key.
 * "Videos" category items reference entries in src/content/videos.ts.
 */

export const galleryCategories = [
  "Clinic",
  "Doctors",
  "Team",
  "Treatment Rooms",
  "Equipment",
  "Patient Experience",
  "Smile Results",
  "Videos",
] as const;

export type GalleryCategory = (typeof galleryCategories)[number];

export interface GalleryItem {
  id: string;
  category: GalleryCategory;
  kind: "image" | "video";
  asset?: ImageAssetKey;
  videoId?: string;
  caption: string;
  /** Layout hint for the editorial grid. */
  span?: "wide" | "tall" | "normal";
}

export const galleryItems: GalleryItem[] = [
  { id: "g-01", category: "Clinic", kind: "image", asset: "gallery-01", caption: "Reception", span: "wide" },
  { id: "g-02", category: "Clinic", kind: "image", asset: "gallery-02", caption: "Waiting Area" },
  { id: "g-03", category: "Treatment Rooms", kind: "image", asset: "gallery-03", caption: "Treatment Room", span: "tall" },
  { id: "g-04", category: "Equipment", kind: "image", asset: "gallery-04", caption: "Sterilization & Equipment" },
  { id: "g-05", category: "Treatment Rooms", kind: "image", asset: "gallery-05", caption: "Treatment Suite", span: "wide" },
  { id: "g-06", category: "Equipment", kind: "image", asset: "gallery-06", caption: "Instruments" },
  { id: "g-07", category: "Doctors", kind: "image", asset: "gallery-07", caption: "Our Doctors" },
  { id: "g-08", category: "Team", kind: "image", asset: "gallery-08", caption: "The Team" },
  { id: "g-09", category: "Patient Experience", kind: "image", asset: "gallery-09", caption: "Patient Experience", span: "tall" },
  { id: "g-10", category: "Smile Results", kind: "image", asset: "gallery-10", caption: "Smile Results" },
  { id: "g-11", category: "Videos", kind: "video", videoId: "clinic-tour", caption: "Clinic Tour" },
  { id: "g-12", category: "Videos", kind: "video", videoId: "doctor-introduction", caption: "Doctor Introduction" },
];

export const galleryPreview = galleryItems.filter((g) => g.kind === "image").slice(0, 6);
