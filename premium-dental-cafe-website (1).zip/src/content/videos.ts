import type { ImageAssetKey } from "./assets";

/**
 * DENTAL CAFE — VIDEOS (editable). Provide `src` (file under /public/assets/videos)
 * OR `youtubeId`. Videos never autoplay with sound. Placeholders render as
 * identifiable [ADD VIDEO] tiles until real media is supplied.
 */

export type VideoCategory =
  | "Clinic Tour"
  | "Doctor Introduction"
  | "Treatment Education"
  | "Patient Testimonials";

export interface VideoItem {
  id: string;
  title: string;
  category: VideoCategory;
  thumbnail: ImageAssetKey;
  src: string | null;
  youtubeId: string | null;
  duration: string | null;
  description: string | null;
  placeholder: boolean;
}

export const videos: VideoItem[] = [
  { id: "clinic-tour", title: "Clinic Tour", category: "Clinic Tour", thumbnail: "video-thumb-01", src: null, youtubeId: null, duration: null, description: null, placeholder: true },
  { id: "doctor-introduction", title: "Meet Our Doctors", category: "Doctor Introduction", thumbnail: "video-thumb-02", src: null, youtubeId: null, duration: null, description: null, placeholder: true },
  { id: "treatment-education", title: "Treatment Education", category: "Treatment Education", thumbnail: "video-thumb-03", src: null, youtubeId: null, duration: null, description: null, placeholder: true },
];

/** REAL PATIENT EXPERIENCES — only genuine, patient-provided testimonial videos. */
export const testimonialVideos: VideoItem[] = [
  { id: "testimonial-01", title: "Patient Testimonial", category: "Patient Testimonials", thumbnail: "video-thumb-04", src: null, youtubeId: null, duration: null, description: null, placeholder: true },
  { id: "testimonial-02", title: "Patient Testimonial", category: "Patient Testimonials", thumbnail: "video-thumb-05", src: null, youtubeId: null, duration: null, description: null, placeholder: true },
  { id: "testimonial-03", title: "Patient Testimonial", category: "Patient Testimonials", thumbnail: "video-thumb-06", src: null, youtubeId: null, duration: null, description: null, placeholder: true },
];

export function getVideo(id: string) {
  return [...videos, ...testimonialVideos].find((v) => v.id === id) ?? null;
}
