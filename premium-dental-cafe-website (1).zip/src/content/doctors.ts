import type { ImageAssetKey } from "./assets";

/**
 * =====================================================================
 * DENTAL CAFE — DOCTOR PROFILES (editable)
 * Only CONFIRMED information is filled in. Unknown values are `null`
 * (rendered as identifiable placeholders or hidden). Do not invent data.
 * Photos are referenced by asset key → see src/content/assets.ts.
 * =====================================================================
 */

export interface DoctorContact {
  label: string;
  display: string;
  e164: string;
}

export interface Doctor {
  slug: string;
  name: string;
  /** Asset key of the ORIGINAL supplied photo. */
  photo: ImageAssetKey;
  qualification: string | null;
  specialization: string | null;
  /** Short line shown under the name (e.g. a supplied tagline). */
  tagline: string | null;
  experience: string | null;
  certifications: string[];
  bio: string | null;
  /** Service slugs this doctor is associated with. */
  treatments: string[];
  languages: string[];
  appointmentInfo: string | null;
  contact: DoctorContact[];
  featured: boolean;
  order: number;
}

export const doctors: Doctor[] = [
  {
    slug: "dr-usama",
    name: "Dr. Usama",
    photo: "doctor-usama",
    qualification: null,
    specialization: null,
    tagline: "Gentle and Pain-Free Dentistry",
    experience: null,
    certifications: [],
    bio: null,
    treatments: ["general-dentistry"],
    languages: [],
    appointmentInfo: null,
    contact: [
      { label: "DHA Office", display: "+92 332 4679934", e164: "+923324679934" },
      { label: "ZWL Office", display: "+92 327 6445111", e164: "+923276445111" },
    ],
    featured: true,
    order: 1,
  },
  {
    slug: "dr-javeriya-shahid",
    name: "Dr. Javeriya Shahid",
    photo: "doctor-javeriya",
    qualification: null,
    specialization: null,
    tagline: null,
    experience: null,
    certifications: [],
    bio: null,
    treatments: [],
    languages: [],
    appointmentInfo: null,
    contact: [],
    featured: true,
    order: 2,
  },
  {
    slug: "dr-marleen-mahiqa",
    name: "Dr. Marleen Mahiqa",
    photo: "doctor-marleen",
    qualification: null,
    specialization: null,
    tagline: null,
    experience: null,
    certifications: [],
    bio: null,
    treatments: [],
    languages: [],
    appointmentInfo: null,
    contact: [],
    featured: true,
    order: 3,
  },
  {
    slug: "dr-abdullah",
    name: "Dr. Abdullah",
    photo: "doctor-abdullah",
    qualification: "BDS, FCPS (Orthodontics)",
    specialization: "Orthodontist",
    tagline: null,
    experience: null,
    certifications: ["FCPS (Orthodontics)"],
    bio: null,
    treatments: ["orthodontics-braces"],
    languages: [],
    appointmentInfo: null,
    contact: [],
    featured: true,
    order: 4,
  },
  {
    slug: "dr-umair-bhalli",
    name: "Dr. Umair Bhalli",
    photo: "doctor-umair",
    qualification: "BDS",
    specialization: "Implantologist",
    tagline: null,
    experience: null,
    certifications: [],
    bio: null,
    treatments: ["dental-implants"],
    languages: [],
    appointmentInfo: null,
    contact: [],
    featured: true,
    order: 5,
  },
];

export const sortedDoctors = [...doctors].sort((a, b) => a.order - b.order);

export function getDoctor(slug: string) {
  return doctors.find((d) => d.slug === slug) ?? null;
}

export function getDoctorsForService(serviceSlug: string) {
  return sortedDoctors.filter((d) => d.treatments.includes(serviceSlug));
}
