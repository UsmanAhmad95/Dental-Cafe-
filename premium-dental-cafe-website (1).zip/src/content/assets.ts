/**
 * =====================================================================
 * DENTAL CAFE — CENTRAL IMAGE / ASSET REGISTRY
 *
 * Every visual on the site references an entry here by key.
 * To replace an image: drop the new file at the SAME `src` path inside
 * /public (no rebuild required for the file itself), then make sure the
 * entry's `status` is "real".
 *
 * status:
 *   "real"    – genuine Dental Cafe photography → rendered as-is
 *   "concept" – neutral concept/stock-style imagery used as a stand-in
 *               until real clinic photography is supplied
 *   "missing" – nothing supplied yet → a clearly labelled placeholder
 *               frame is rendered instead (never a fake photo)
 * =====================================================================
 */

export type AssetStatus = "real" | "concept" | "missing";

export interface ImageAsset {
  /** Public path — drop the replacement file at exactly this path. */
  src: string;
  alt: string;
  status: AssetStatus;
  /** Label shown inside the placeholder frame when status === "missing". */
  placeholderLabel?: string;
  note?: string;
}

/* ------------------------------ BRAND ------------------------------ */
export const brandAssets = {
  logo: {
    src: "/assets/brand/logo.png",
    alt: "Dental Cafe",
    status: "missing" as AssetStatus,
    note: "Official logo for dark backgrounds. Drop the original file here and set status to \"real\".",
  },
  logoOnLight: {
    src: "/assets/brand/logo-dark.png",
    alt: "Dental Cafe",
    status: "missing" as AssetStatus,
    note: "Optional variant for light backgrounds. Falls back to `logo`.",
  },
  ogImage: "/assets/clinic/hero-main.jpg",
};

/* ------------------------------ IMAGES ----------------------------- */
const registry = {
  /* Hero / about */
  "hero-main": {
    src: "/assets/clinic/hero-main.jpg",
    alt: "Calm, modern dental treatment room with warm white walls and gold accents",
    status: "concept",
    note: "Replace with real Dental Cafe hero photography.",
  },
  "about-main": {
    src: "/assets/clinic/about-main.jpg",
    alt: "Dental clinic reception with white marble and warm lighting",
    status: "concept",
  },
  "about-detail": {
    src: "/assets/clinic/about-detail.jpg",
    alt: "Modern dental treatment chair and equipment",
    status: "concept",
  },

  /* Clinic spaces */
  "clinic-reception": {
    src: "/assets/clinic/clinic-reception.jpg",
    alt: "Reception area",
    status: "concept",
  },
  "clinic-waiting-area": {
    src: "/assets/clinic/clinic-waiting-area.jpg",
    alt: "Waiting lounge",
    status: "concept",
  },
  "treatment-room": {
    src: "/assets/clinic/treatment-room.jpg",
    alt: "Treatment room",
    status: "concept",
  },
  "clinic-equipment": {
    src: "/assets/clinic/clinic-equipment.jpg",
    alt: "Sterilization and equipment area",
    status: "concept",
  },
  "clinic-team": {
    src: "/assets/clinic/clinic-team.jpg",
    alt: "The Dental Cafe team",
    status: "missing",
    placeholderLabel: "[ADD TEAM PHOTO]",
  },
  "patient-experience": {
    src: "/assets/clinic/patient-experience.jpg",
    alt: "Patient experience at Dental Cafe",
    status: "missing",
    placeholderLabel: "[ADD PATIENT EXPERIENCE PHOTO]",
  },

  /* Doctors — ORIGINAL photos only, never AI-altered */
  "doctor-usama": {
    src: "/assets/doctors/doctor-usama.jpg",
    alt: "Dr. Usama — Dental Cafe",
    status: "missing",
    placeholderLabel: "[ADD DOCTOR PHOTO]",
  },
  "doctor-javeriya": {
    src: "/assets/doctors/doctor-javeriya.jpg",
    alt: "Dr. Javeriya Shahid — Dental Cafe",
    status: "missing",
    placeholderLabel: "[ADD DOCTOR PHOTO]",
  },
  "doctor-marleen": {
    src: "/assets/doctors/doctor-marleen.jpg",
    alt: "Dr. Marleen Mahiqa — Dental Cafe",
    status: "missing",
    placeholderLabel: "[ADD DOCTOR PHOTO]",
  },
  "doctor-abdullah": {
    src: "/assets/doctors/doctor-abdullah.jpg",
    alt: "Dr. Abdullah — Orthodontist, Dental Cafe",
    status: "missing",
    placeholderLabel: "[ADD DOCTOR PHOTO]",
  },
  "doctor-umair": {
    src: "/assets/doctors/doctor-umair.jpg",
    alt: "Dr. Umair Bhalli — Implantologist, Dental Cafe",
    status: "missing",
    placeholderLabel: "[ADD DOCTOR PHOTO]",
  },

  /* Services */
  "service-dental-implants": {
    src: "/assets/services/service-dental-implants.jpg",
    alt: "Dental implant and crown model",
    status: "concept",
  },
  "service-orthodontics": {
    src: "/assets/services/service-orthodontics.jpg",
    alt: "Clear aligner and orthodontic model",
    status: "concept",
  },
  "service-general-dentistry": {
    src: "/assets/services/service-general-dentistry.jpg",
    alt: "Dental instruments arranged on a tray",
    status: "concept",
  },
  "service-root-canal": {
    src: "/assets/services/service-root-canal.jpg",
    alt: "Dental treatment room",
    status: "concept",
  },
  "service-clear-aligners": {
    src: "/assets/services/service-clear-aligners.jpg",
    alt: "Clear aligner tray",
    status: "concept",
  },
  "service-veneers": {
    src: "/assets/services/service-veneers.jpg",
    alt: "Porcelain veneer shade guide",
    status: "concept",
  },
  "service-teeth-whitening": {
    src: "/assets/services/service-teeth-whitening.jpg",
    alt: "Tooth shade guide",
    status: "concept",
  },
  "service-scaling-cleaning": {
    src: "/assets/services/service-scaling-cleaning.jpg",
    alt: "Dental hygiene instruments",
    status: "concept",
  },
  "service-crowns-bridges": {
    src: "/assets/services/service-crowns-bridges.jpg",
    alt: "Ceramic crown model",
    status: "concept",
  },
  "service-wisdom-tooth": {
    src: "/assets/services/service-wisdom-tooth.jpg",
    alt: "Sterile dental equipment",
    status: "concept",
  },
  "service-cosmetic-dentistry": {
    src: "/assets/services/service-cosmetic-dentistry.jpg",
    alt: "Cosmetic dentistry shade guide",
    status: "concept",
  },

  /* Gallery slots */
  "gallery-01": { src: "/assets/gallery/gallery-01.jpg", alt: "Reception", status: "concept" },
  "gallery-02": { src: "/assets/gallery/gallery-02.jpg", alt: "Waiting lounge", status: "concept" },
  "gallery-03": { src: "/assets/gallery/gallery-03.jpg", alt: "Treatment room", status: "concept" },
  "gallery-04": { src: "/assets/gallery/gallery-04.jpg", alt: "Equipment", status: "concept" },
  "gallery-05": { src: "/assets/gallery/gallery-05.jpg", alt: "Treatment suite", status: "concept" },
  "gallery-06": { src: "/assets/gallery/gallery-06.jpg", alt: "Instruments", status: "concept" },
  "gallery-07": {
    src: "/assets/gallery/gallery-07.jpg",
    alt: "Dental Cafe doctors",
    status: "missing",
    placeholderLabel: "[ADD GALLERY IMAGE]",
  },
  "gallery-08": {
    src: "/assets/gallery/gallery-08.jpg",
    alt: "Dental Cafe team",
    status: "missing",
    placeholderLabel: "[ADD GALLERY IMAGE]",
  },
  "gallery-09": {
    src: "/assets/gallery/gallery-09.jpg",
    alt: "Patient experience",
    status: "missing",
    placeholderLabel: "[ADD GALLERY IMAGE]",
  },
  "gallery-10": {
    src: "/assets/gallery/gallery-10.jpg",
    alt: "Smile result",
    status: "missing",
    placeholderLabel: "[ADD GALLERY IMAGE]",
  },

  /* Before / after — REAL consented patient results only */
  "before-after-01-before": { src: "/assets/results/before-after-01-before.jpg", alt: "Before treatment", status: "missing", placeholderLabel: "[ADD BEFORE IMAGE]" },
  "before-after-01-after": { src: "/assets/results/before-after-01-after.jpg", alt: "After treatment", status: "missing", placeholderLabel: "[ADD AFTER IMAGE]" },
  "before-after-02-before": { src: "/assets/results/before-after-02-before.jpg", alt: "Before treatment", status: "missing", placeholderLabel: "[ADD BEFORE IMAGE]" },
  "before-after-02-after": { src: "/assets/results/before-after-02-after.jpg", alt: "After treatment", status: "missing", placeholderLabel: "[ADD AFTER IMAGE]" },
  "before-after-03-before": { src: "/assets/results/before-after-03-before.jpg", alt: "Before treatment", status: "missing", placeholderLabel: "[ADD BEFORE IMAGE]" },
  "before-after-03-after": { src: "/assets/results/before-after-03-after.jpg", alt: "After treatment", status: "missing", placeholderLabel: "[ADD AFTER IMAGE]" },

  /* Video thumbnails */
  "video-thumb-01": { src: "/assets/videos/video-thumb-01.jpg", alt: "Clinic tour", status: "missing", placeholderLabel: "[ADD VIDEO]" },
  "video-thumb-02": { src: "/assets/videos/video-thumb-02.jpg", alt: "Doctor introduction", status: "missing", placeholderLabel: "[ADD VIDEO]" },
  "video-thumb-03": { src: "/assets/videos/video-thumb-03.jpg", alt: "Treatment education", status: "missing", placeholderLabel: "[ADD VIDEO]" },
  "video-thumb-04": { src: "/assets/videos/video-thumb-04.jpg", alt: "Patient testimonial", status: "missing", placeholderLabel: "[ADD VIDEO]" },
  "video-thumb-05": { src: "/assets/videos/video-thumb-05.jpg", alt: "Patient testimonial", status: "missing", placeholderLabel: "[ADD VIDEO]" },
  "video-thumb-06": { src: "/assets/videos/video-thumb-06.jpg", alt: "Patient testimonial", status: "missing", placeholderLabel: "[ADD VIDEO]" },

  /* Blog covers */
  "blog-checkups": { src: "/assets/blog/blog-checkups.jpg", alt: "Sterile dental equipment", status: "concept" },
  "blog-daily-care": { src: "/assets/blog/blog-daily-care.jpg", alt: "Toothbrush and floss on marble", status: "concept" },
  "blog-first-visit": { src: "/assets/blog/blog-first-visit.jpg", alt: "Dental treatment room", status: "concept" },
  "blog-implants": { src: "/assets/blog/blog-implants.jpg", alt: "Dental implant model", status: "concept" },
  "blog-orthodontics": { src: "/assets/blog/blog-orthodontics.jpg", alt: "Clear aligner and braces model", status: "concept" },
  "blog-cosmetic": { src: "/assets/blog/blog-cosmetic.jpg", alt: "Veneer shade guide", status: "concept" },
} satisfies Record<string, ImageAsset>;

export type ImageAssetKey = keyof typeof registry;
export const imageAssets: Record<ImageAssetKey, ImageAsset> = registry;

export function getAsset(key: ImageAssetKey): ImageAsset {
  return imageAssets[key];
}
