import type { ImageAssetKey } from "./assets";

/**
 * DENTAL CAFE — SMILE RESULTS / BEFORE & AFTER (editable)
 * Only REAL, consented Dental Cafe patient results. Never generated imagery.
 */
export interface ResultCase {
  id: string;
  treatment: string;
  description: string | null;
  before: ImageAssetKey;
  after: ImageAssetKey;
  doctorSlug: string | null;
}

export const resultCases: ResultCase[] = [
  { id: "case-01", treatment: "Orthodontic Treatment", description: null, before: "before-after-01-before", after: "before-after-01-after", doctorSlug: "dr-abdullah" },
  { id: "case-02", treatment: "Dental Implant", description: null, before: "before-after-02-before", after: "before-after-02-after", doctorSlug: "dr-umair-bhalli" },
  { id: "case-03", treatment: "[ADD TREATMENT TYPE]", description: null, before: "before-after-03-before", after: "before-after-03-after", doctorSlug: null },
];
