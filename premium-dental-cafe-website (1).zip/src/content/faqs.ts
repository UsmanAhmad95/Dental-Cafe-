export interface Faq {
  q: string;
  a: string;
}

/** General clinic FAQs — verified information only. */
export const faqs: Faq[] = [
  {
    q: "Do I need an appointment to visit Dental Cafe?",
    a: "Appointments are recommended so we can give you our full attention. You can request an appointment online, call +92 332 4679934, or message us on WhatsApp.",
  },
  {
    q: "Where is Dental Cafe located?",
    a: "We are located in DHA Phase 4, Lahore, Pakistan. Use the Get Directions button on our Contact page to open our location in Google Maps.",
  },
  {
    q: "Is my online appointment request confirmed instantly?",
    a: "No. The online form sends a request to our team. We will contact you on the phone or WhatsApp number you provide to confirm a suitable time.",
  },
  {
    q: "Which treatments do you offer?",
    a: "Our published treatments include dental implants, orthodontics and braces, and gentle general dentistry. If you are looking for something specific, message us on WhatsApp and we will guide you.",
  },
  {
    q: "I feel anxious about dental visits. Can you help?",
    a: "Comfort is central to how we care for patients. Let us know how you feel when you book and our team will take the time to explain each step and go at your pace.",
  },
  {
    q: "How can I reach the clinic quickly?",
    a: "The fastest ways are calling +92 332 4679934 or messaging the same number on WhatsApp. An additional line is available on +92 327 6445111.",
  },
];
