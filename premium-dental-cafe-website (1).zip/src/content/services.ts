import type { ImageAssetKey } from "./assets";

/**
 * =====================================================================
 * DENTAL CAFE — SERVICES (editable)
 *
 * `published: true`  → confirmed Dental Cafe service, live on the site.
 * `published: false` → prepared DRAFT awaiting confirmation. Drafts are
 *                      never rendered publicly; flip the flag to publish.
 *
 * Confirmation basis for the published set:
 *   • Dental Implants        – Dr. Umair Bhalli (Implantologist)
 *   • Orthodontics & Braces  – Dr. Abdullah (FCPS Orthodontics)
 *   • General Dentistry      – "Gentle and Pain-Free Dentistry" (Dr. Usama creative)
 * =====================================================================
 */

export interface ServiceStep {
  title: string;
  text: string;
}
export interface ServiceFaq {
  q: string;
  a: string;
}

export interface Service {
  slug: string;
  name: string;
  shortName: string;
  excerpt: string;
  image: ImageAssetKey;
  published: boolean;
  featured: boolean;
  order: number;
  overview: string[];
  whoItIsFor: string[];
  howItWorks: ServiceStep[];
  benefits: string[];
  whatToExpect: string[];
  faqs: ServiceFaq[];
  doctorSlugs: string[];
  seoTitle: string;
  seoDescription: string;
}

export const services: Service[] = [
  {
    slug: "dental-implants",
    name: "Dental Implants",
    shortName: "Implants",
    excerpt:
      "A long-term option for replacing missing teeth, planned and placed by our implantologist with comfort in mind.",
    image: "service-dental-implants",
    published: true,
    featured: true,
    order: 1,
    overview: [
      "A dental implant is a small titanium post placed in the jaw to act as an artificial tooth root. Once integrated, it supports a crown, bridge or denture so a missing tooth can be restored in both function and appearance.",
      "At Dental Cafe, implant treatment is planned around your individual anatomy and goals. Our implantologist, Dr. Umair Bhalli, assesses suitability, explains your options clearly and guides you through every stage of care.",
    ],
    whoItIsFor: [
      "Adults with one or more missing teeth",
      "Patients who find removable dentures uncomfortable or unstable",
      "Those looking for a fixed, natural-feeling replacement",
      "Patients with healthy gums who are able to maintain good daily hygiene",
    ],
    howItWorks: [
      { title: "Consultation & assessment", text: "We examine your teeth, gums and jaw, discuss your medical history and take any necessary imaging to confirm you are a suitable candidate." },
      { title: "Personalized treatment plan", text: "You receive a clear plan covering the number of implants, the restoration type, timeline and cost before anything begins." },
      { title: "Implant placement", text: "The implant is placed in a gentle, controlled procedure under local anaesthesia, with your comfort monitored throughout." },
      { title: "Healing & integration", text: "Over the following months the implant bonds with the bone. A temporary solution can often be provided while you heal." },
      { title: "Final restoration", text: "A custom crown, bridge or denture is fitted to the implant, matched to the shade and shape of your natural teeth." },
    ],
    benefits: [
      "Fixed replacement that looks and functions like a natural tooth",
      "Helps preserve the surrounding bone and neighbouring teeth",
      "Eat, speak and smile with renewed confidence",
      "Cared for like natural teeth with brushing, flossing and check-ups",
    ],
    whatToExpect: [
      "Most patients describe placement as more comfortable than expected thanks to local anaesthesia.",
      "Mild swelling or tenderness for a few days is normal and usually managed with simple aftercare.",
      "Treatment typically takes place over several visits spread across a few months.",
      "Regular reviews help protect the long-term health of your implant.",
    ],
    faqs: [
      { q: "Is implant placement painful?", a: "The procedure is carried out under local anaesthesia so you should not feel pain during placement. Some tenderness afterwards is normal and usually settles within a few days." },
      { q: "How long does the whole process take?", a: "It varies by patient. Healing and integration typically take a few months before the final restoration is fitted. Your dentist will give you a personal timeline at your consultation." },
      { q: "Am I a suitable candidate?", a: "Suitability depends on your oral health, bone volume and general health. A consultation with our implantologist is the best way to find out." },
    ],
    doctorSlugs: ["dr-umair-bhalli"],
    seoTitle: "Dental Implants in DHA Phase 4, Lahore",
    seoDescription:
      "Dental implants at Dental Cafe, DHA Phase 4 Lahore. Consultation, planning and placement by our implantologist. Book on +92 332 4679934.",
  },
  {
    slug: "orthodontics-braces",
    name: "Orthodontics & Braces",
    shortName: "Orthodontics",
    excerpt:
      "Specialist orthodontic care to align teeth and improve bite, guided by our FCPS-qualified orthodontist.",
    image: "service-orthodontics",
    published: true,
    featured: true,
    order: 2,
    overview: [
      "Orthodontics focuses on the position of the teeth and jaws. Braces and related appliances apply gentle, controlled forces over time to move teeth into healthier, better-aligned positions.",
      "Orthodontic treatment at Dental Cafe is led by Dr. Abdullah, BDS, FCPS (Orthodontics). Every plan begins with a thorough assessment so the approach fits your bite, your goals and your lifestyle.",
    ],
    whoItIsFor: [
      "Children, teenagers and adults with crowded or spaced teeth",
      "Patients with bite concerns such as overbite, underbite or crossbite",
      "Anyone who would like a straighter, more balanced smile",
      "Patients referred by their general dentist for specialist alignment",
    ],
    howItWorks: [
      { title: "Orthodontic assessment", text: "We examine your teeth and bite, take records and discuss what you would like to achieve." },
      { title: "Treatment plan", text: "Your orthodontist explains the appliance options suitable for you, the expected duration and how to care for your teeth during treatment." },
      { title: "Fitting", text: "Your braces or appliance are fitted in a comfortable appointment, and you receive clear guidance for the first days." },
      { title: "Regular adjustments", text: "Periodic visits allow your orthodontist to review progress and make adjustments." },
      { title: "Retention", text: "Once alignment is complete, retainers help keep your teeth in their new position." },
    ],
    benefits: [
      "Straighter teeth that are easier to clean and maintain",
      "Improved bite function and comfort",
      "A more balanced, confident smile",
      "Care led by a specialist-qualified orthodontist",
    ],
    whatToExpect: [
      "Some pressure or tenderness for a few days after fitting and adjustments is normal.",
      "Treatment length depends on your case and is discussed at your consultation.",
      "Good daily hygiene and regular reviews are an important part of successful treatment.",
      "Retainers are usually required after treatment to maintain your result.",
    ],
    faqs: [
      { q: "Am I too old for braces?", a: "Healthy teeth and gums can be moved at almost any age. Many adults choose orthodontic treatment. Your orthodontist will advise what is suitable for you." },
      { q: "How long will I need to wear braces?", a: "It depends on the complexity of your case. Your orthodontist will give you an estimated timeline after your assessment." },
      { q: "Will braces affect what I can eat?", a: "Some hard or sticky foods are best avoided during treatment. You will receive simple guidance when your appliance is fitted." },
    ],
    doctorSlugs: ["dr-abdullah"],
    seoTitle: "Orthodontist & Braces in DHA Phase 4, Lahore",
    seoDescription:
      "Orthodontic treatment and braces at Dental Cafe, DHA Phase 4 Lahore, led by an FCPS-qualified orthodontist. Book on +92 332 4679934.",
  },
  {
    slug: "general-dentistry",
    name: "Gentle & Pain-Free Dentistry",
    shortName: "General Dentistry",
    excerpt:
      "Everyday dental care delivered gently — examinations, advice and treatment planned around your comfort.",
    image: "service-general-dentistry",
    published: true,
    featured: true,
    order: 3,
    overview: [
      "General dentistry is the foundation of a healthy smile: careful examination, honest advice and treatment carried out with attention to how you feel throughout.",
      "Dental Cafe's approach is gentle and patient-centered. We take time to explain what we find, discuss your options and plan care at a pace that suits you.",
    ],
    whoItIsFor: [
      "Patients looking for a regular dentist in DHA, Lahore",
      "Anyone due for a dental examination or advice",
      "Patients who feel anxious about dental visits and want a gentle approach",
      "Families seeking comfortable, professional everyday dental care",
    ],
    howItWorks: [
      { title: "Welcome & history", text: "We listen to your concerns and review your medical and dental history." },
      { title: "Examination", text: "A thorough check of your teeth, gums and mouth, with imaging if needed." },
      { title: "Clear explanation", text: "We explain what we find in plain language and outline any recommended care." },
      { title: "Comfortable treatment", text: "Any treatment is carried out gently, with your comfort checked at every step." },
    ],
    benefits: [
      "Early attention to concerns before they become complex",
      "A calm, comfort-focused experience",
      "Personalized advice for your oral health at home",
      "Continuity of care with a team you know",
    ],
    whatToExpect: [
      "Your first visit focuses on understanding your needs and examining your mouth.",
      "You will never be rushed into treatment — decisions are made together.",
      "Let us know about any anxieties so we can adapt your care.",
    ],
    faqs: [
      { q: "I am nervous about the dentist. Can you help?", a: "Yes. Comfort is central to how we work. Tell us how you feel and we will go at your pace, explaining each step before it happens." },
      { q: "Do I need an appointment?", a: "Appointments are recommended so we can give you our full attention. Book online, call or WhatsApp +92 332 4679934." },
    ],
    doctorSlugs: ["dr-usama"],
    seoTitle: "Gentle, Pain-Free Dentist in DHA Phase 4, Lahore",
    seoDescription:
      "Gentle, patient-centered general dentistry at Dental Cafe, DHA Phase 4 Lahore. Appointments recommended — call or WhatsApp +92 332 4679934.",
  },

  /* ---------------- DRAFTS — awaiting confirmation (not published) --------------- */
  ...(
    [
      ["root-canal-treatment", "Root Canal Treatment", "Root Canal", "service-root-canal", "Treatment to relieve pain and save a tooth affected by infection or deep decay."],
      ["clear-aligners", "Clear Aligners", "Aligners", "service-clear-aligners", "Discreet, removable aligner trays that gradually guide teeth into position."],
      ["veneers", "Veneers", "Veneers", "service-veneers", "Thin, custom-made shells designed to refine the shape and shade of front teeth."],
      ["teeth-whitening", "Teeth Whitening", "Whitening", "service-teeth-whitening", "Professionally supervised whitening to brighten the natural shade of your teeth."],
      ["scaling-cleaning", "Scaling & Cleaning", "Scaling", "service-scaling-cleaning", "Professional removal of plaque and tartar to support healthy gums."],
      ["crowns-bridges", "Crowns & Bridges", "Crowns", "service-crowns-bridges", "Custom restorations to protect damaged teeth or replace missing ones."],
      ["wisdom-tooth-treatment", "Wisdom Tooth Treatment", "Wisdom Teeth", "service-wisdom-tooth", "Assessment and care for problematic or impacted wisdom teeth."],
      ["cosmetic-dentistry", "Cosmetic Dentistry", "Cosmetic", "service-cosmetic-dentistry", "Treatments focused on the appearance of your smile, planned to look natural."],
    ] as const
  ).map(([slug, name, shortName, image, excerpt], i): Service => ({
    slug,
    name,
    shortName,
    excerpt,
    image,
    published: false,
    featured: false,
    order: 10 + i,
    overview: [],
    whoItIsFor: [],
    howItWorks: [],
    benefits: [],
    whatToExpect: [],
    faqs: [],
    doctorSlugs: [],
    seoTitle: `${name} in DHA Phase 4, Lahore`,
    seoDescription: `${name} at Dental Cafe, DHA Phase 4 Lahore.`,
  })),
];

export const publishedServices = services
  .filter((s) => s.published)
  .sort((a, b) => a.order - b.order);

export const featuredServices = publishedServices.filter((s) => s.featured);

export function getService(slug: string) {
  return services.find((s) => s.slug === slug && s.published) ?? null;
}

export function getServicesForDoctor(slugs: string[]) {
  return publishedServices.filter((s) => slugs.includes(s.slug));
}
