import type { Metadata } from "next";
import { OptionSwitcher } from "@/components/preview/OptionSwitcher";
import { HeroLight } from "@/components/sections/HeroLight";
import { TrustBookBand } from "@/components/sections/TrustBookBand";
import { AboutSection } from "@/components/sections/AboutSection";
import { DoctorsSection } from "@/components/sections/DoctorsSection";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { SmileResults } from "@/components/sections/SmileResults";
import { ClinicExperience } from "@/components/sections/ClinicExperience";
import { FinalCta } from "@/components/sections/CtaBands";
import {
  FaqSection,
  GalleryPreview,
  LocationSection,
  ReviewsSection,
  VideoTestimonials,
} from "@/components/sections/HomeSecondary";
import { site } from "@/content/site";

/**
 * OPTION 2 — "Light Editorial"
 * White hero + strict WHITE / BLACK alternation (brief §46):
 * White Hero → Black Trust+Book → White About → Black Doctors → White Services →
 * Black Why Us → White Results → Black Testimonials → Cream Clinic → Black Reviews →
 * White Gallery → Black FAQ → White Location → Black CTA → Black Footer
 */
export const metadata: Metadata = {
  title: `Option 2 — Light Editorial | ${site.name}`,
  description: site.description,
  robots: { index: false, follow: false },
};

export default function OptionTwoPage() {
  return (
    <>
      <OptionSwitcher active={2} />
      <HeroLight />
      <TrustBookBand />
      <AboutSection />
      <DoctorsSection />
      <ServicesSection />
      <WhyChooseUs />
      <SmileResults compact />
      <VideoTestimonials />
      <ClinicExperience />
      <ReviewsSection tone="dark" />
      <GalleryPreview />
      <FaqSection tone="dark" />
      <LocationSection />
      <FinalCta />
    </>
  );
}
