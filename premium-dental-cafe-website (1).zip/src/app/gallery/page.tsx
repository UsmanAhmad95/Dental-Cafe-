import type { Metadata } from "next";
import { GalleryGrid } from "@/components/gallery/GalleryGrid";
import { VideoGrid } from "@/components/media/VideoGrid";
import { FinalCta } from "@/components/sections/CtaBands";
import { SmileResults } from "@/components/sections/SmileResults";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { galleryItems } from "@/content/gallery";
import { testimonialVideos, videos } from "@/content/videos";

export const metadata: Metadata = {
  title: "Gallery — Dental Cafe, DHA Phase 4 Lahore",
  description: "Explore the Dental Cafe clinic, treatment rooms, equipment, team, patient experience, smile results and videos.",
  alternates: { canonical: "/gallery" },
};

export default function GalleryPage() {
  return (
    <>
      <PageHero
        tone="light"
        compact
        eyebrow="Gallery"
        title={<>A closer look at <span className="text-gold italic">Dental Cafe</span></>}
        description="Clinic spaces, doctors, team, treatment rooms, equipment, patient experience, smile results and videos."
        crumbs={[{ label: "Gallery" }]}
      />
      <section className="bg-white">
        <div className="container-x pb-24">
          <Reveal>
            <GalleryGrid items={galleryItems} />
          </Reveal>
        </div>
      </section>

      <section id="videos" className="bg-ink text-white">
        <div className="container-x py-24 lg:py-28">
          <SectionHeading tone="dark" eyebrow="Videos" title="Clinic tour, doctors & treatment education" description="Elegant video thumbnails; videos never autoplay with sound." />
          <div className="mt-12"><VideoGrid videos={videos} tone="dark" /></div>
          <div className="mt-20">
            <SectionHeading tone="dark" eyebrow="Video Testimonials" title={<span className="uppercase">Real patient experiences</span>} />
            <div className="mt-12"><VideoGrid videos={testimonialVideos} tone="dark" ctaLabel="Watch Testimonial" /></div>
          </div>
        </div>
      </section>

      <SmileResults />
      <FinalCta />
    </>
  );
}
