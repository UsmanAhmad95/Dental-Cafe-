import type { MetadataRoute } from "next";
import { blogPosts } from "@/content/blog";
import { doctors } from "@/content/doctors";
import { publishedServices } from "@/content/services";
import { site } from "@/content/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = site.url.replace(/\/$/, "");
  const now = new Date();
  const statics = ["", "/about", "/doctors", "/services", "/gallery", "/reviews", "/blog", "/contact", "/book", "/privacy-policy", "/terms"];
  return [
    ...statics.map((p) => ({ url: `${base}${p}`, lastModified: now, changeFrequency: "weekly" as const, priority: p === "" ? 1 : 0.8 })),
    ...doctors.map((d) => ({ url: `${base}/doctors/${d.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.7 })),
    ...publishedServices.map((s) => ({ url: `${base}/services/${s.slug}`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.8 })),
    ...blogPosts.map((p) => ({ url: `${base}/blog/${p.slug}`, lastModified: new Date(p.date), changeFrequency: "yearly" as const, priority: 0.5 })),
  ];
}
