import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Check } from "lucide-react";
import { DoctorCard } from "@/components/doctors/DoctorCard";
import { FinalCta } from "@/components/sections/CtaBands";
import { FaqList } from "@/components/sections/HomeSecondary";
import { PageHero } from "@/components/ui/PageHero";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading, Placeholder } from "@/components/ui/SectionHeading";
import { WhatsAppIcon } from "@/components/ui/icons";
import { getDoctorsForService } from "@/content/doctors";
import { getService, publishedServices } from "@/content/services";
import { PLACEHOLDERS, site } from "@/content/site";
import { bookingLink, serviceWhatsappLink } from "@/lib/links";

interface Params {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return publishedServices.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) return { title: "Treatment not found" };
  return {
    title: service.seoTitle,
    description: service.seoDescription,
    alternates: { canonical: `/services/${service.slug}` },
  };
}

export default async function ServicePage({ params }: Params) {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) notFound();

  const doctors = [
    ...getDoctorsForService(service.slug),
  ].filter((d, i, arr) => arr.findIndex((x) => x.slug === d.slug) === i);

  const bookHref = bookingLink({ treatment: service.slug });
  const waHref = serviceWhatsappLink(service.name);

  const schema = {
    "@context": "https://schema.org",
    "@type": "MedicalProcedure",
    name: service.name,
    description: service.excerpt,
    url: `${site.url}/services/${service.slug}`,
    provider: { "@type": "Dentist", name: site.name, telephone: site.contact.phoneE164, address: site.location.full },
  };

  return (
    <>
      <PageHero
        eyebrow="Treatment"
        title={service.name}
        description={service.excerpt}
        crumbs={[{ label: "Services", href: "/services" }, { label: service.name }]}
        image={service.image}
      >
        <div className="flex flex-col gap-3 sm:flex-row">
          <Link href={bookHref} className="btn btn-gold btn-lg">Book Appointment</Link>
          <a href={waHref} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light btn-lg">
            <WhatsAppIcon className="h-4 w-4" /> WhatsApp
          </a>
        </div>
      </PageHero>

      {/* Overview + who it is for */}
      <section className="bg-white">
        <div className="container-x py-20 lg:py-28">
          <div className="grid gap-14 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <SectionHeading eyebrow="Overview" title={`Understanding ${service.shortName.toLowerCase()}`} />
              <Reveal delay={100}>
                <div className="mt-8 space-y-5 text-[17px] leading-8 text-ink/72">
                  {service.overview.length ? service.overview.map((p) => <p key={p}>{p}</p>) : <Placeholder label={PLACEHOLDERS.serviceDetails} />}
                </div>
              </Reveal>
              <Reveal delay={160}>
                <h3 className="mt-12 font-display text-3xl text-ink">Who it is for</h3>
                <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                  {service.whoItIsFor.length ? service.whoItIsFor.map((w) => (
                    <li key={w} className="flex items-start gap-3 rounded-brand border border-ink/8 bg-cream px-4 py-3 text-[15px] text-ink/80">
                      <Check className="mt-1 h-4 w-4 shrink-0 text-gold" /> {w}
                    </li>
                  )) : <Placeholder label={PLACEHOLDERS.serviceDetails} />}
                </ul>
              </Reveal>
            </div>
            <div className="lg:col-span-5">
              <Reveal delay={120} variant="mask">
                <Picture asset={service.image} className="aspect-[4/5] w-full rounded-brand" sizes="(min-width:1024px) 40vw, 100vw" />
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="bg-ink text-white">
        <div className="container-x py-20 lg:py-28">
          <SectionHeading tone="dark" eyebrow="How Treatment Works" title="A clear, step-by-step journey" />
          <ol className="mt-14 grid gap-px overflow-hidden rounded-brand border border-white/10 bg-white/10 md:grid-cols-2 lg:grid-cols-5">
            {service.howItWorks.length ? service.howItWorks.map((s, i) => (
              <li key={s.title} className="bg-ink p-7">
                <Reveal delay={i * 80}>
                  <span className="font-mono text-[11px] tracking-[0.24em] text-gold">{String(i + 1).padStart(2, "0")}</span>
                  <h3 className="mt-4 font-display text-2xl leading-tight">{s.title}</h3>
                  <p className="mt-3 text-[15px] leading-7 text-white/65">{s.text}</p>
                </Reveal>
              </li>
            )) : (
              <li className="bg-ink p-7"><Placeholder label={PLACEHOLDERS.serviceDetails} /></li>
            )}
          </ol>
        </div>
      </section>

      {/* Benefits + what to expect */}
      <section className="bg-cream">
        <div className="container-x py-20 lg:py-28">
          <div className="grid gap-14 lg:grid-cols-2">
            <Reveal>
              <p className="eyebrow">Benefits</p>
              <h2 className="mt-5 display-md text-ink">Why patients choose this treatment</h2>
              <ul className="mt-8 space-y-4">
                {service.benefits.map((b) => (
                  <li key={b} className="flex items-start gap-4 text-[16px] leading-7 text-ink/80">
                    <span className="mt-2 h-px w-6 shrink-0 bg-gold" /> {b}
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal delay={120}>
              <div className="card p-8">
                <p className="eyebrow">What to expect</p>
                <ul className="mt-6 space-y-4">
                  {service.whatToExpect.map((w) => (
                    <li key={w} className="flex items-start gap-3 text-[15px] leading-7 text-ink/75">
                      <Check className="mt-1.5 h-4 w-4 shrink-0 text-gold" /> {w}
                    </li>
                  ))}
                </ul>
                <p className="mt-6 border-t border-ink/10 pt-5 text-xs leading-5 text-stone">
                  Information on this page is general and educational. Suitability, timelines and outcomes vary by patient and are discussed at your consultation.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* FAQ */}
      {service.faqs.length ? (
        <section className="bg-white">
          <div className="container-x py-20 lg:py-28">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-4"><SectionHeading eyebrow="FAQ" title={`${service.shortName} questions`} /></div>
              <Reveal delay={100} className="lg:col-span-8"><FaqList items={service.faqs} /></Reveal>
            </div>
          </div>
        </section>
      ) : null}

      {/* Relevant doctors */}
      {doctors.length ? (
        <section className="bg-ink text-white">
          <div className="container-x py-20 lg:py-28">
            <SectionHeading tone="dark" eyebrow="Your Doctor" title={`Meet the clinician${doctors.length > 1 ? "s" : ""} for ${service.shortName.toLowerCase()}`} />
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {doctors.map((d) => <DoctorCard key={d.slug} doctor={d} tone="dark" />)}
            </div>
          </div>
        </section>
      ) : null}

      <FinalCta title={`Book your ${service.shortName.toLowerCase()} consultation`} bookingHref={bookHref} whatsappHref={waHref} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
    </>
  );
}
