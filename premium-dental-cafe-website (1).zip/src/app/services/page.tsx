import type { Metadata } from "next";
import { ServiceCard } from "@/components/services/ServiceCard";
import { FinalCta } from "@/components/sections/CtaBands";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { WhatsAppIcon } from "@/components/ui/icons";
import { publishedServices } from "@/content/services";
import { whatsappLink } from "@/lib/links";

export const metadata: Metadata = {
  title: "Dental Services in DHA Phase 4, Lahore",
  description:
    "Dental implants, orthodontics & braces and gentle general dentistry at Dental Cafe, DHA Phase 4 Lahore. Explore treatments and book an appointment.",
  alternates: { canonical: "/services" },
};

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title={<>Treatments delivered with <span className="text-gold italic">precision</span> and care</>}
        description="Every treatment at Dental Cafe begins with a careful assessment and a clear, personalized plan."
        crumbs={[{ label: "Services" }]}
        image="service-general-dentistry"
      />
      <section className="bg-white">
        <div className="container-x py-20 lg:py-28">
          <div className="grid gap-7 md:grid-cols-2 lg:grid-cols-3">
            {publishedServices.map((s, i) => (
              <Reveal key={s.slug} delay={i * 80} className="h-full">
                <ServiceCard service={s} index={i} />
              </Reveal>
            ))}
          </div>

          <Reveal delay={200}>
            <div className="mt-14 grid items-center gap-8 rounded-brand bg-ink p-8 text-white sm:p-10 lg:grid-cols-12">
              <div className="lg:col-span-8">
                <p className="eyebrow">Not listed here?</p>
                <h2 className="mt-4 display-sm">Ask about a specific treatment</h2>
                <p className="mt-3 max-w-xl text-[15px] leading-7 text-white/65">
                  Our team can advise on availability and guide you to the right care. Message us with your question and we will respond personally.
                </p>
              </div>
              <div className="lg:col-span-4 lg:text-right">
                <a href={whatsappLink("Hello Dental Cafe, I would like to ask about a treatment.")} target="_blank" rel="noopener noreferrer" className="btn btn-gold">
                  <WhatsAppIcon className="h-4 w-4" /> Ask on WhatsApp
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
