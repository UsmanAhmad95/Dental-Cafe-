import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, ChevronRight, Phone } from "lucide-react";
import { DoctorPortrait } from "@/components/doctors/DoctorCard";
import { ServiceCard } from "@/components/services/ServiceCard";
import { FinalCta } from "@/components/sections/CtaBands";
import { Reveal } from "@/components/ui/Reveal";
import { Placeholder } from "@/components/ui/SectionHeading";
import { WhatsAppIcon } from "@/components/ui/icons";
import { doctors, getDoctor } from "@/content/doctors";
import { getServicesForDoctor } from "@/content/services";
import { PLACEHOLDERS, site } from "@/content/site";
import { bookingLink, doctorWhatsappLink, telLink } from "@/lib/links";

interface Params {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return doctors.map((d) => ({ slug: d.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const doctor = getDoctor(slug);
  if (!doctor) return { title: "Doctor not found" };
  const role = doctor.specialization ? ` — ${doctor.specialization}` : "";
  return {
    title: `${doctor.name}${role}`,
    description: `${doctor.name}${role} at Dental Cafe, DHA Phase 4 Lahore. Book an appointment on ${site.contact.phone}.`,
    alternates: { canonical: `/doctors/${doctor.slug}` },
  };
}

export default async function DoctorProfilePage({ params }: Params) {
  const { slug } = await params;
  const doctor = getDoctor(slug);
  if (!doctor) notFound();

  const services = getServicesForDoctor(doctor.treatments);

  const facts: { label: string; value: string | null; placeholder: string }[] = [
    { label: "Qualification", value: doctor.qualification, placeholder: PLACEHOLDERS.doctorQualification },
    { label: "Specialization", value: doctor.specialization, placeholder: PLACEHOLDERS.doctorSpecialization },
    { label: "Experience", value: doctor.experience, placeholder: PLACEHOLDERS.doctorExperience },
    { label: "Languages", value: doctor.languages.length ? doctor.languages.join(", ") : null, placeholder: PLACEHOLDERS.doctorLanguages },
  ];

  const personSchema = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: doctor.name,
    jobTitle: doctor.specialization ?? "Dentist",
    worksFor: { "@type": "Dentist", name: site.name, address: site.location.full },
    url: `${site.url}/doctors/${doctor.slug}`,
  };

  return (
    <>
      <section className="relative isolate overflow-hidden bg-ink text-white">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-50"
          style={{ background: "radial-gradient(50% 70% at 20% 40%, rgba(198,161,91,0.18) 0%, rgba(198,161,91,0) 70%)" }}
        />
        <div className="container-x py-16 lg:py-24">
          <nav aria-label="Breadcrumb" className="mb-10">
            <ol className="flex flex-wrap items-center gap-2 text-[11px] tracking-[0.2em] text-white/55 uppercase">
              <li><Link href="/" className="hover:text-gold">Home</Link></li>
              <li className="flex items-center gap-2"><ChevronRight className="h-3 w-3 text-gold" /><Link href="/doctors" className="hover:text-gold">Doctors</Link></li>
              <li className="flex items-center gap-2"><ChevronRight className="h-3 w-3 text-gold" /><span aria-current="page">{doctor.name}</span></li>
            </ol>
          </nav>

          <div className="grid items-start gap-12 lg:grid-cols-12">
            <Reveal variant="mask" className="lg:col-span-5">
              <div className="rounded-brand border border-gold/40 p-2">
                <DoctorPortrait doctor={doctor} tone="dark" className="aspect-[4/5] w-full rounded-brand" priority />
              </div>
            </Reveal>

            <div className="lg:col-span-7">
              <Reveal>
                <p className="eyebrow">{doctor.specialization ?? doctor.tagline ?? "Dental Cafe"}</p>
                <h1 className="mt-5 display-xl">{doctor.name}</h1>
                <p className="mt-4 text-lg text-white/70">
                  {doctor.qualification ?? <Placeholder label={PLACEHOLDERS.doctorQualification} />}
                </p>
                {doctor.tagline && doctor.specialization ? (
                  <p className="mt-2 font-display text-2xl text-gold italic">{doctor.tagline}</p>
                ) : null}
              </Reveal>

              <Reveal delay={120}>
                <dl className="mt-10 grid gap-6 sm:grid-cols-2">
                  {facts.map((f) => (
                    <div key={f.label} className="border-t border-white/15 pt-4">
                      <dt className="text-[11px] font-semibold tracking-[0.24em] text-gold uppercase">{f.label}</dt>
                      <dd className="mt-2 text-[15px] text-white/85">
                        {f.value ?? <Placeholder label={f.placeholder} />}
                      </dd>
                    </div>
                  ))}
                </dl>
              </Reveal>

              <Reveal delay={200}>
                <div className="mt-10 flex flex-col gap-3 sm:flex-row">
                  <Link href={bookingLink({ doctor: doctor.slug })} className="btn btn-gold btn-lg">
                    Book Appointment
                  </Link>
                  <a href={doctorWhatsappLink(doctor.name)} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light btn-lg">
                    <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                  </a>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
        <div className="gold-line opacity-70" />
      </section>

      <section className="bg-white">
        <div className="container-x py-20 lg:py-28">
          <div className="grid gap-14 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <Reveal>
                <p className="eyebrow">Biography</p>
                <h2 className="mt-5 display-md text-ink">About {doctor.name}</h2>
                <div className="mt-7 text-[17px] leading-8 text-ink/72">
                  {doctor.bio ? (
                    doctor.bio.split("\n").map((p) => <p key={p} className="mb-5">{p}</p>)
                  ) : (
                    <div className="placeholder-box p-10">
                      <span className="font-mono text-[12px] tracking-[0.18em] text-gold-deep">{PLACEHOLDERS.doctorBio}</span>
                      <span className="font-mono text-[10px] text-stone/70">src/content/doctors.ts → {doctor.slug}.bio</span>
                    </div>
                  )}
                </div>
              </Reveal>

              {doctor.certifications.length ? (
                <Reveal delay={100}>
                  <h3 className="mt-12 font-display text-2xl text-ink">Certifications</h3>
                  <ul className="mt-4 flex flex-wrap gap-2">
                    {doctor.certifications.map((c) => (
                      <li key={c} className="rounded-brand border border-gold/50 bg-cream px-3 py-1.5 text-sm text-ink">{c}</li>
                    ))}
                  </ul>
                </Reveal>
              ) : null}

              <Reveal delay={150}>
                <h3 className="mt-12 font-display text-2xl text-ink">Treatment expertise</h3>
                {services.length ? (
                  <div className="mt-6 grid gap-6 sm:grid-cols-2">
                    {services.map((s, i) => <ServiceCard key={s.slug} service={s} index={i} />)}
                  </div>
                ) : (
                  <p className="mt-4 text-[15px] text-stone">
                    <Placeholder label="[ADD TREATMENT EXPERTISE]" />{" "}
                    <span className="ml-2">Link services in src/content/doctors.ts → treatments.</span>
                  </p>
                )}
              </Reveal>
            </div>

            <aside className="lg:col-span-5">
              <Reveal delay={120}>
                <div className="card-dark sticky top-28 p-8">
                  <p className="eyebrow">Appointments</p>
                  <h3 className="mt-4 font-display text-3xl">Book with {doctor.name}</h3>
                  <p className="mt-3 text-sm leading-6 text-white/65">
                    {doctor.appointmentInfo ?? "Appointments are recommended. Request online or contact the clinic directly."}
                  </p>
                  <ul className="mt-6 space-y-3 text-[15px]">
                    {(doctor.contact.length ? doctor.contact : [{ label: "Clinic", display: site.contact.phone, e164: site.contact.phoneE164 }]).map((c) => (
                      <li key={c.e164} className="flex items-center justify-between gap-4 border-t border-white/10 pt-3">
                        <span className="text-[11px] tracking-[0.22em] text-white/55 uppercase">{c.label}</span>
                        <a href={telLink(c.e164)} className="inline-flex items-center gap-2 text-white hover:text-gold">
                          <Phone className="h-4 w-4 text-gold" /> {c.display}
                        </a>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-7 flex flex-col gap-3">
                    <Link href={bookingLink({ doctor: doctor.slug })} className="btn btn-gold w-full">Book Appointment</Link>
                    <a href={doctorWhatsappLink(doctor.name)} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light w-full">
                      <WhatsAppIcon className="h-4 w-4" /> Chat on WhatsApp
                    </a>
                  </div>
                  <Link href="/doctors" className="mt-6 inline-flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] text-gold uppercase hover:text-gold-deep">
                    All doctors <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </Reveal>
            </aside>
          </div>
        </div>
      </section>

      <FinalCta title={`Ready to see ${doctor.name}?`} bookingHref={bookingLink({ doctor: doctor.slug })} whatsappHref={doctorWhatsappLink(doctor.name)} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(personSchema) }} />
    </>
  );
}
