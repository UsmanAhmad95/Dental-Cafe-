import type { Metadata } from "next";
import { DoctorCard } from "@/components/doctors/DoctorCard";
import { FinalCta } from "@/components/sections/CtaBands";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { sortedDoctors } from "@/content/doctors";

export const metadata: Metadata = {
  title: "Our Doctors — Dentists in DHA Phase 4, Lahore",
  description:
    "Meet the Dental Cafe team: Dr. Usama, Dr. Javeriya Shahid, Dr. Marleen Mahiqa, Dr. Abdullah (Orthodontist) and Dr. Umair Bhalli (Implantologist).",
  alternates: { canonical: "/doctors" },
};

export default function DoctorsPage() {
  return (
    <>
      <PageHero
        eyebrow="Doctors"
        title={<>A professional team, <span className="text-gold italic">personally</span> invested in your smile</>}
        description="Authentic profiles of the dentists who care for you at Dental Cafe, DHA Phase 4, Lahore."
        crumbs={[{ label: "Doctors" }]}
        image="treatment-room"
      />
      <section className="bg-white">
        <div className="container-x py-20 lg:py-28">
          <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {sortedDoctors.map((d, i) => (
              <Reveal key={d.slug} delay={i * 80} className="h-full">
                <DoctorCard doctor={d} tone="light" />
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <FinalCta title="Book with the doctor of your choice" />
    </>
  );
}
