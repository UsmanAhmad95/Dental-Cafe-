import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { aboutContent } from "@/components/sections/AboutSection";
import { ClinicExperience } from "@/components/sections/ClinicExperience";
import { FinalCta } from "@/components/sections/CtaBands";
import { DoctorsSection } from "@/components/sections/DoctorsSection";
import { whyChooseUs } from "@/components/sections/WhyChooseUs";
import { PageHero } from "@/components/ui/PageHero";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { site } from "@/content/site";

export const metadata: Metadata = {
  title: "About Dental Cafe — Dental Clinic in DHA Phase 4, Lahore",
  description:
    "Dental Cafe is a patient-centered dental practice in DHA Phase 4, Lahore focused on oral health, comfort, hygiene and personalized care.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        tone="light"
        eyebrow="About Dental Cafe"
        title={<>Where your <span className="text-gold italic">smile</span> comes first</>}
        description={aboutContent.paragraphs[0]}
        crumbs={[{ label: "About" }]}
      />

      <section className="bg-white">
        <div className="container-x pb-24 lg:pb-32">
          <div className="grid gap-4 md:grid-cols-12">
            <Reveal variant="mask" className="md:col-span-8">
              <Picture asset="about-main" className="aspect-[16/10] w-full rounded-brand" sizes="(min-width:768px) 66vw, 100vw" priority />
            </Reveal>
            <Reveal variant="mask" delay={150} className="md:col-span-4">
              <Picture asset="about-detail" className="aspect-[16/10] h-full w-full rounded-brand md:aspect-auto" sizes="(min-width:768px) 33vw, 100vw" />
            </Reveal>
          </div>

          <div className="mt-20 grid gap-14 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <SectionHeading eyebrow="Our Approach" title="Professional care, personally delivered" />
            </div>
            <Reveal delay={100} className="lg:col-span-7">
              <div className="space-y-5 text-[17px] leading-8 text-ink/72">
                <p>{aboutContent.paragraphs[1]}</p>
                <p>
                  We are a professional, patient-centered team in {site.location.area}, {site.location.city}. Our purpose is straightforward — to protect and improve your oral health in an environment that feels modern, clean and calm, with every step explained clearly.
                </p>
                <p>
                  Patient trust is earned through honesty: we recommend only what we believe is right for you, take time to answer questions and plan treatment at a pace you are comfortable with.
                </p>
              </div>
              <ul className="mt-10 grid gap-6 sm:grid-cols-2">
                {aboutContent.values.map((v) => (
                  <li key={v.title} className="border-t border-gold/40 pt-4">
                    <h3 className="font-display text-xl text-ink">{v.title}</h3>
                    <p className="mt-1.5 text-sm leading-6 text-stone">{v.text}</p>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="bg-ink text-white">
        <div className="container-x py-24 lg:py-32">
          <SectionHeading tone="dark" eyebrow="Standards" title="What you can expect from every visit" align="center" />
          <ul className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {whyChooseUs.map(({ icon: Icon, title, text }, i) => (
              <li key={title}>
                <Reveal delay={i * 60} className="h-full">
                  <div className="card-dark h-full p-8">
                    <span className="grid h-11 w-11 place-items-center rounded-full border border-gold/50 text-gold"><Icon className="h-5 w-5" /></span>
                    <h3 className="mt-6 font-display text-2xl">{title}</h3>
                    <p className="mt-3 text-[15px] leading-7 text-white/65">{text}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <ClinicExperience />

      <section className="bg-white">
        <div className="container-x py-20 lg:py-24">
          <Reveal>
            <div className="flex flex-col items-start justify-between gap-6 border-y border-ink/10 py-10 md:flex-row md:items-center">
              <div>
                <p className="eyebrow">Rated {site.rating.value} on Google</p>
                <h2 className="mt-4 display-sm text-ink">{site.rating.count} patients have shared their experience</h2>
              </div>
              <Link href="/reviews" className="btn btn-primary">Read Reviews <ArrowRight className="h-4 w-4" /></Link>
            </div>
          </Reveal>
        </div>
      </section>

      <DoctorsSection />
      <FinalCta />
    </>
  );
}
