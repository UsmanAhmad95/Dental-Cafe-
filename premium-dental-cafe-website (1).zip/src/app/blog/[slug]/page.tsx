import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ChevronRight } from "lucide-react";
import { FinalCta } from "@/components/sections/CtaBands";
import { Picture } from "@/components/ui/Picture";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { blogPosts, getPost, getRelatedPosts } from "@/content/blog";
import { site } from "@/content/site";
import { formatDate } from "@/lib/utils";
import { PostCard } from "@/components/blog/PostCard";

interface Params {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return blogPosts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) return { title: "Article not found" };
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: { type: "article", title: post.title, description: post.excerpt, publishedTime: post.date },
  };
}

export default async function BlogArticlePage({ params }: Params) {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) notFound();
  const related = getRelatedPosts(post);

  const schema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.excerpt,
    datePublished: post.date,
    author: { "@type": "Organization", name: post.author },
    publisher: { "@type": "Organization", name: site.name },
    mainEntityOfPage: `${site.url}/blog/${post.slug}`,
  };

  return (
    <>
      <article className="bg-white">
        <header className="container-x pt-14 lg:pt-20">
          <nav aria-label="Breadcrumb">
            <ol className="flex flex-wrap items-center gap-2 text-[11px] tracking-[0.2em] text-stone uppercase">
              <li><Link href="/" className="hover:text-gold">Home</Link></li>
              <li className="flex items-center gap-2"><ChevronRight className="h-3 w-3 text-gold" /><Link href="/blog" className="hover:text-gold">Blog</Link></li>
              <li className="flex items-center gap-2"><ChevronRight className="h-3 w-3 text-gold" /><span aria-current="page">{post.category}</span></li>
            </ol>
          </nav>
          <Reveal>
            <div className="mx-auto mt-10 max-w-3xl text-center">
              <p className="eyebrow eyebrow-plain justify-center">{post.category}</p>
              <h1 className="mt-5 display-lg text-ink">{post.title}</h1>
              <p className="mt-6 text-lg leading-8 text-ink/70">{post.excerpt}</p>
              <p className="mt-6 text-xs tracking-[0.2em] text-stone uppercase">
                {post.author} · {formatDate(post.date)} · {post.readingTime}
              </p>
            </div>
          </Reveal>
          <Reveal delay={120} variant="mask" className="mt-12">
            <Picture asset={post.cover} className="aspect-[16/9] w-full rounded-brand sm:aspect-[21/9]" sizes="100vw" priority />
          </Reveal>
        </header>

        <div className="container-x py-16 lg:py-20">
          <div className="prose-cafe mx-auto max-w-3xl">
            {post.body.map((block, i) => {
              switch (block.type) {
                case "h2":
                  return <h2 key={i}>{block.text}</h2>;
                case "ul":
                  return <ul key={i}>{block.items.map((it) => <li key={it}>{it}</li>)}</ul>;
                case "quote":
                  return <blockquote key={i}>{block.text}</blockquote>;
                default:
                  return <p key={i}>{block.text}</p>;
              }
            })}
            <p className="mt-10 rounded-brand border border-gold/40 bg-cream p-5 text-sm leading-6 text-stone">
              This article is general educational information and does not replace a consultation. For advice specific to you, book an appointment with Dental Cafe in {site.location.area}, {site.location.city}.
            </p>
          </div>
        </div>
      </article>

      {related.length ? (
        <section className="bg-cream">
          <div className="container-x py-20 lg:py-24">
            <SectionHeading eyebrow="Related Articles" title="Continue reading" />
            <div className="mt-12 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
              {related.map((p, i) => (
                <Reveal key={p.slug} delay={i * 70} className="h-full"><PostCard post={p} /></Reveal>
              ))}
            </div>
          </div>
        </section>
      ) : null}

      <FinalCta />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
    </>
  );
}
