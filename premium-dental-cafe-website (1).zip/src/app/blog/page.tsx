import type { Metadata } from "next";
import { PostCard } from "@/components/blog/PostCard";
import { FinalCta } from "@/components/sections/CtaBands";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { blogCategories, sortedPosts } from "@/content/blog";

export const metadata: Metadata = {
  title: "Blog — Oral Health & Dental Care Insights",
  description: "Educational articles from Dental Cafe on oral health, preventive dentistry, cosmetic dentistry, dental implants and orthodontics.",
  alternates: { canonical: "/blog" },
};

export default function BlogPage() {
  const [first, ...rest] = sortedPosts;
  return (
    <>
      <PageHero
        tone="light"
        compact
        eyebrow="Blog"
        title={<>Insights for a <span className="text-gold italic">healthier</span> smile</>}
        description="Clear, calm guidance on oral health and modern dentistry from the Dental Cafe team."
        crumbs={[{ label: "Blog" }]}
      />
      <section className="bg-white">
        <div className="container-x pb-24">
          <Reveal>
            <ul className="flex flex-wrap gap-2" aria-label="Categories">
              {blogCategories.map((c) => (
                <li key={c} className="chip cursor-default hover:border-ink/15 hover:bg-white hover:text-ink">{c}</li>
              ))}
            </ul>
          </Reveal>
          {first ? (
            <Reveal delay={100} className="mt-10">
              <PostCard post={first} featured />
            </Reveal>
          ) : null}
          <div className="mt-8 grid gap-7 md:grid-cols-2 lg:grid-cols-3">
            {rest.map((p, i) => (
              <Reveal key={p.slug} delay={i * 70} className="h-full">
                <PostCard post={p} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <FinalCta title="Questions about your oral health?" />
    </>
  );
}
