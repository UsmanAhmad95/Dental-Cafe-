import type { Metadata } from "next";
import { ReviewCard, Stars } from "@/components/reviews/ReviewCard";
import { FinalCta } from "@/components/sections/CtaBands";
import { VideoTestimonials } from "@/components/sections/HomeSecondary";
import { Reveal } from "@/components/ui/Reveal";
import { GoogleIcon } from "@/components/ui/icons";
import { reviews, reviewSummary } from "@/content/reviews";
import { site } from "@/content/site";

export const metadata: Metadata = {
  title: `Reviews — ${site.rating.value} ★ from ${site.rating.count} Google Reviews`,
  description: `Dental Cafe in DHA Phase 4 Lahore is rated ${site.rating.value} on Google from ${site.rating.count} reviews. Read genuine patient reviews.`,
  alternates: { canonical: "/reviews" },
};

export default function ReviewsPage() {
  return (
    <>
      <section className="relative isolate overflow-hidden bg-ink text-white">
        <div aria-hidden className="pointer-events-none absolute inset-0 opacity-50" style={{ background: "radial-gradient(50% 70% at 70% 30%, rgba(198,161,91,0.2) 0%, rgba(198,161,91,0) 70%)" }} />
        <div className="container-x py-20 lg:py-28">
          <div className="grid items-center gap-12 lg:grid-cols-12">
            <Reveal className="lg:col-span-7">
              <p className="eyebrow">Google Reviews</p>
              <h1 className="mt-5 display-xl">What our patients say</h1>
              <p className="mt-6 max-w-xl text-lg leading-8 text-white/70">
                Genuine reviews from patients of {site.name}, {site.location.area}, {site.location.city}. Names and text are shown exactly as published on Google.
              </p>
            </Reveal>
            <Reveal delay={120} className="lg:col-span-5">
              <div className="card-dark p-8 text-center sm:p-10">
                <p className="font-display text-8xl leading-none text-gold">{reviewSummary.rating}</p>
                <Stars value={5} className="mt-4 justify-center" />
                <p className="mt-4 font-display text-2xl">{reviewSummary.count} Google Reviews</p>
                <a href={reviewSummary.url} target="_blank" rel="noopener noreferrer" className="btn btn-gold mt-7 w-full">
                  <GoogleIcon className="h-4 w-4" /> Read all on Google
                </a>
              </div>
            </Reveal>
          </div>
        </div>
        <div className="gold-line opacity-70" />
      </section>

      <section className="bg-white">
        <div className="container-x py-20 lg:py-28">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {reviews.map((r, i) => (
              <Reveal key={r.id} delay={(i % 3) * 80} className="h-full">
                <ReviewCard review={r} />
              </Reveal>
            ))}
          </div>
          <Reveal delay={150} className="mt-12 text-center">
            <a href={reviewSummary.url} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
              <GoogleIcon className="h-4 w-4" /> See all {reviewSummary.count} reviews on Google
            </a>
          </Reveal>
        </div>
      </section>

      <VideoTestimonials />
      <FinalCta title="Experience the care patients talk about" />
    </>
  );
}
