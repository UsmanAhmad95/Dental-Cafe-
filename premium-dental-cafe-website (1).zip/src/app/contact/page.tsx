import type { Metadata } from "next";
import Link from "next/link";
import { CalendarDays, MapPin, Phone, Mail, Clock } from "lucide-react";
import { FinalCta } from "@/components/sections/CtaBands";
import { FaqList } from "@/components/sections/HomeSecondary";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading, Placeholder } from "@/components/ui/SectionHeading";
import { FacebookIcon, InstagramIcon, WhatsAppIcon } from "@/components/ui/icons";
import { faqs } from "@/content/faqs";
import { PLACEHOLDERS, site } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/links";

export const metadata: Metadata = {
  title: "Contact Dental Cafe — DHA Phase 4, Lahore",
  description: `Contact Dental Cafe in DHA Phase 4, Lahore. Call or WhatsApp ${site.contact.phone}, get directions on Google Maps, or book an appointment online.`,
  alternates: { canonical: "/contact" },
};

const actions = [
  { icon: Phone, label: "Call Clinic", value: site.contact.phone, href: telLink(), external: false },
  { icon: WhatsAppIcon, label: "Chat on WhatsApp", value: site.whatsapp.display, href: whatsappLink(), external: true },
  { icon: MapPin, label: "Get Directions", value: site.location.full, href: site.location.mapsUrl, external: true },
  { icon: CalendarDays, label: "Book Appointment", value: "Online request", href: "/book", external: false },
];

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title={<>We would love to <span className="text-gold italic">hear</span> from you</>}
        description={`${site.name} · ${site.location.full}`}
        crumbs={[{ label: "Contact" }]}
        image="clinic-waiting-area"
      />

      <section className="bg-white">
        <div className="container-x py-20 lg:py-28">
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {actions.map(({ icon: Icon, label, value, href, external }, i) => (
              <li key={label}>
                <Reveal delay={i * 70} className="h-full">
                  {external ? (
                    <a href={href} target="_blank" rel="noopener noreferrer" className="card card-hover group flex h-full flex-col p-7">
                      <span className="grid h-12 w-12 place-items-center rounded-full border border-gold/50 text-gold transition-colors group-hover:bg-gold group-hover:text-ink"><Icon className="h-5 w-5" /></span>
                      <span className="mt-6 font-display text-2xl text-ink">{label}</span>
                      <span className="mt-1 text-sm text-stone">{value}</span>
                    </a>
                  ) : (
                    <Link href={href} className="card card-hover group flex h-full flex-col p-7">
                      <span className="grid h-12 w-12 place-items-center rounded-full border border-gold/50 text-gold transition-colors group-hover:bg-gold group-hover:text-ink"><Icon className="h-5 w-5" /></span>
                      <span className="mt-6 font-display text-2xl text-ink">{label}</span>
                      <span className="mt-1 text-sm text-stone">{value}</span>
                    </Link>
                  )}
                </Reveal>
              </li>
            ))}
          </ul>

          <div className="mt-20 grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <SectionHeading eyebrow="Clinic Details" title={site.name} />
              <Reveal delay={100}>
                <dl className="mt-8 space-y-6 text-[16px] text-ink/80">
                  <div className="flex items-start gap-4">
                    <MapPin className="mt-1 h-5 w-5 shrink-0 text-gold" />
                    <div><dt className="field-label">Address</dt><dd>{site.location.full}</dd></div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Phone className="mt-1 h-5 w-5 shrink-0 text-gold" />
                    <div>
                      <dt className="field-label">Phone</dt>
                      <dd><a href={telLink()} className="hover:text-gold">{site.contact.phone}</a></dd>
                      <dd className="text-stone"><a href={telLink(site.contact.additionalPhoneE164)} className="hover:text-gold">{site.contact.additionalPhone}</a> <span className="text-xs">({site.contact.additionalPhoneLabel})</span></dd>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <WhatsAppIcon className="mt-1 h-5 w-5 shrink-0 text-gold" />
                    <div><dt className="field-label">WhatsApp</dt><dd><a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="hover:text-gold">{site.whatsapp.display}</a></dd></div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Mail className="mt-1 h-5 w-5 shrink-0 text-gold" />
                    <div><dt className="field-label">Email</dt><dd>{site.contact.email ? <a href={`mailto:${site.contact.email}`} className="hover:text-gold">{site.contact.email}</a> : <Placeholder label={PLACEHOLDERS.email} />}</dd></div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Clock className="mt-1 h-5 w-5 shrink-0 text-gold" />
                    <div><dt className="field-label">Opening Hours</dt><dd>{site.hours ? site.hours.map((h) => <span key={h} className="block">{h}</span>) : <Placeholder label={PLACEHOLDERS.hours} />}</dd></div>
                  </div>
                </dl>
                <div className="mt-8 flex gap-3">
                  <a href={site.social.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="grid h-12 w-12 place-items-center rounded-full border border-ink/15 text-ink transition-colors hover:border-gold hover:text-gold"><InstagramIcon className="h-5 w-5" /></a>
                  <a href={site.social.facebook} target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="grid h-12 w-12 place-items-center rounded-full border border-ink/15 text-ink transition-colors hover:border-gold hover:text-gold"><FacebookIcon className="h-5 w-5" /></a>
                  <a href={site.location.mapsUrl} target="_blank" rel="noopener noreferrer" aria-label="Google Maps" className="grid h-12 w-12 place-items-center rounded-full border border-ink/15 text-ink transition-colors hover:border-gold hover:text-gold"><MapPin className="h-5 w-5" /></a>
                </div>
              </Reveal>
            </div>
            <Reveal delay={150} variant="mask" className="lg:col-span-7">
              <div className="overflow-hidden rounded-brand border border-ink/10 shadow-soft">
                <iframe
                  title={`${site.name} on Google Maps`}
                  src={site.location.mapsEmbedUrl}
                  className="aspect-[4/3] w-full grayscale-[35%] sm:aspect-[16/10]"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
              </div>
              <a href={site.location.mapsUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary mt-5">Get Directions</a>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="bg-cream">
        <div className="container-x py-20 lg:py-24">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4"><SectionHeading eyebrow="FAQ" title="Before you visit" /></div>
            <Reveal delay={100} className="lg:col-span-8"><FaqList items={faqs} /></Reveal>
          </div>
        </div>
      </section>

      <FinalCta />
    </>
  );
}
