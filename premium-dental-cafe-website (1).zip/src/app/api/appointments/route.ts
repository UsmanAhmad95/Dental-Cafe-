import { NextResponse } from "next/server";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { getDoctor } from "@/content/doctors";
import { getService } from "@/content/services";

export const dynamic = "force-dynamic";

const TIME_OPTIONS = new Set(["Morning", "Afternoon", "Evening", "Flexible"]);

interface Payload {
  treatment?: string;
  doctor?: string;
  date?: string;
  time?: string;
  name?: string;
  phone?: string;
  whatsapp?: string;
  message?: string;
  website?: string; // honeypot
}

function clean(v: unknown, max = 500) {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

function isValidPhone(v: string) {
  const digits = v.replace(/\D/g, "");
  return /^[+\d][\d\s().-]{6,24}$/.test(v) && digits.length >= 10 && digits.length <= 15;
}

function makeReference() {
  const stamp = Date.now().toString(36).toUpperCase().slice(-5);
  const rand = Math.random().toString(36).toUpperCase().slice(2, 6);
  return `DC-${stamp}${rand}`;
}

/**
 * POST /api/appointments — stores an appointment REQUEST.
 * The clinic confirms by phone/WhatsApp; nothing here is a confirmed booking.
 */
export async function POST(req: Request) {
  let body: Payload;
  try {
    body = (await req.json()) as Payload;
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  // Honeypot — silently accept bots without storing
  if (clean(body.website)) {
    return NextResponse.json({ ok: true, reference: makeReference() });
  }

  const treatmentSlug = clean(body.treatment, 120);
  const doctorSlug = clean(body.doctor, 120);
  const date = clean(body.date, 10);
  const time = clean(body.time, 40);
  const name = clean(body.name, 120);
  const phone = clean(body.phone, 40);
  const whatsapp = clean(body.whatsapp, 40);
  const message = clean(body.message, 1500);

  const errors: Record<string, string> = {};

  const service = treatmentSlug === "other" ? null : getService(treatmentSlug);
  if (!treatmentSlug || (treatmentSlug !== "other" && !service)) errors.treatment = "Please choose a treatment.";

  const doctor = doctorSlug && doctorSlug !== "any" ? getDoctor(doctorSlug) : null;
  if (doctorSlug && doctorSlug !== "any" && !doctor) errors.doctor = "Please choose a valid doctor.";

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) errors.date = "Please choose a valid date.";
  else {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const chosen = new Date(`${date}T00:00:00`);
    if (Number.isNaN(chosen.getTime()) || chosen < today) errors.date = "Please choose today or a future date.";
  }

  if (!TIME_OPTIONS.has(time)) errors.time = "Please choose a preferred time.";
  if (name.length < 2) errors.name = "Please enter the patient's name.";
  if (!isValidPhone(phone)) errors.phone = "Please enter a valid phone number.";
  if (whatsapp && !isValidPhone(whatsapp)) errors.whatsapp = "Please enter a valid WhatsApp number.";

  if (Object.keys(errors).length) {
    return NextResponse.json({ ok: false, errors }, { status: 422 });
  }

  const reference = makeReference();

  try {
    const [row] = await db
      .insert(appointments)
      .values({
        reference,
        treatmentSlug,
        treatmentName: service?.name ?? "Other / Not sure",
        doctorSlug: doctor?.slug ?? null,
        doctorName: doctor?.name ?? null,
        preferredDate: date,
        preferredTime: time,
        patientName: name,
        phone,
        whatsapp: whatsapp || null,
        message: message || null,
        status: "new",
        source: "website",
      })
      .returning({ id: appointments.id, reference: appointments.reference });

    return NextResponse.json({ ok: true, id: row.id, reference: row.reference }, { status: 201 });
  } catch (err) {
    console.error("[appointments] insert failed", err);
    return NextResponse.json(
      { ok: false, error: "We could not save your request right now. Please call or WhatsApp the clinic." },
      { status: 500 },
    );
  }
}

export function GET() {
  return NextResponse.json({ ok: false, error: "Method not allowed." }, { status: 405 });
}
