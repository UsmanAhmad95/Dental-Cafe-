import type { Metadata } from "next";
import { Suspense } from "react";
import { BookingWizard } from "@/components/booking/BookingWizard";
import { PageHero } from "@/components/ui/PageHero";
import { WhatsAppIcon } from "@/components/ui/icons";
import { site } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/links";

export const metadata: Metadata = {
  title: "Book an Appointment",
  description: `Request a dental appointment at Dental Cafe, DHA Phase 4 Lahore. Call or WhatsApp ${site.contact.bookingPhone}.`,
  alternates: { canonical: "/book" },
};

export default function BookPage() {
  return (
    <>
      <PageHero
        compact
        eyebrow="Book Appointment"
        title={<>Request your <span className="text-gold italic">appointment</span></>}
        description="Tell us what you need and when suits you. Our team confirms every request personally by phone or WhatsApp."
        crumbs={[{ label: "Book Appointment" }]}
      >
        <div className="flex flex-wrap gap-3">
          <a href={telLink(site.contact.bookingPhoneE164)} className="btn btn-gold btn-sm">Call {site.contact.bookingPhone}</a>
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light btn-sm">
            <WhatsAppIcon className="h-4 w-4" /> WhatsApp
          </a>
        </div>
      </PageHero>

      <section className="bg-cream">
        <div className="container-x py-16 lg:py-24">
          <Suspense fallback={<div className="card p-10 text-center text-sm text-stone">Loading booking form…</div>}>
            <BookingWizard />
          </Suspense>
        </div>
      </section>
    </>
  );
}
