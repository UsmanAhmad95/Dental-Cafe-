import type { Metadata } from "next";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { isAdminAuthenticated, isAdminConfigured } from "@/lib/admin-auth";
import { site } from "@/content/site";
import { whatsappLink } from "@/lib/links";
import { loginAction, logoutAction, updateStatusAction } from "./actions";

export const metadata: Metadata = {
  title: "Admin — Appointment Requests",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

const STATUS_STYLES: Record<string, string> = {
  new: "bg-gold text-ink",
  contacted: "bg-white text-ink border border-ink/20",
  confirmed: "bg-ink text-white border border-gold",
  closed: "bg-mist text-stone",
};

export default async function AdminPage() {
  if (!isAdminConfigured()) {
    return (
      <Shell title="Admin area not configured">
        <p className="text-[15px] leading-7 text-ink/70">
          Set <code className="rounded bg-mist px-1.5 py-0.5 font-mono text-sm">ADMIN_PASSWORD</code> in your environment (see <code className="font-mono text-sm">.env</code>) to enable the appointment requests dashboard.
        </p>
      </Shell>
    );
  }

  const authed = await isAdminAuthenticated();

  if (!authed) {
    return (
      <Shell title="Sign in">
        <form action={loginAction} className="max-w-sm space-y-4">
          <div>
            <label htmlFor="password" className="field-label">Admin password</label>
            <input id="password" name="password" type="password" required autoComplete="current-password" className="field" />
          </div>
          <button type="submit" className="btn btn-primary w-full">Sign In</button>
        </form>
      </Shell>
    );
  }

  const rows = await db.select().from(appointments).orderBy(desc(appointments.createdAt)).limit(200);
  const counts = rows.reduce<Record<string, number>>((acc, r) => ({ ...acc, [r.status]: (acc[r.status] ?? 0) + 1 }), {});

  return (
    <Shell
      title="Appointment Requests"
      aside={
        <form action={logoutAction}>
          <button type="submit" className="btn btn-secondary btn-sm">Sign Out</button>
        </form>
      }
    >
      <div className="grid gap-4 sm:grid-cols-4">
        {(["new", "contacted", "confirmed", "closed"] as const).map((s) => (
          <div key={s} className="card p-5">
            <p className="text-[11px] font-semibold tracking-[0.22em] text-stone uppercase">{s}</p>
            <p className="mt-2 font-display text-4xl text-ink">{counts[s] ?? 0}</p>
          </div>
        ))}
      </div>

      <div className="card mt-8 overflow-x-auto">
        <table className="w-full min-w-[880px] text-left text-sm">
          <thead className="bg-cream text-[11px] tracking-[0.2em] text-stone uppercase">
            <tr>
              <th className="px-4 py-3">Ref</th>
              <th className="px-4 py-3">Patient</th>
              <th className="px-4 py-3">Treatment / Doctor</th>
              <th className="px-4 py-3">Preferred</th>
              <th className="px-4 py-3">Message</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/8">
            {rows.length === 0 ? (
              <tr><td colSpan={6} className="px-4 py-10 text-center text-stone">No appointment requests yet.</td></tr>
            ) : rows.map((r) => (
              <tr key={r.id} className="align-top">
                <td className="px-4 py-4 font-mono text-xs">
                  {r.reference}
                  <div className="mt-1 text-[11px] text-stone">{r.createdAt.toLocaleString("en-GB")}</div>
                </td>
                <td className="px-4 py-4">
                  <div className="font-semibold text-ink">{r.patientName}</div>
                  <a href={`tel:${r.phone}`} className="block text-stone hover:text-gold">{r.phone}</a>
                  {r.whatsapp ? (
                    <a href={`https://wa.me/${r.whatsapp.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer" className="text-xs text-gold-deep hover:underline">
                      WhatsApp {r.whatsapp}
                    </a>
                  ) : null}
                </td>
                <td className="px-4 py-4">
                  <div className="text-ink">{r.treatmentName}</div>
                  <div className="text-stone">{r.doctorName ?? "No preference"}</div>
                </td>
                <td className="px-4 py-4">
                  <div className="text-ink">{r.preferredDate}</div>
                  <div className="text-stone">{r.preferredTime}</div>
                </td>
                <td className="max-w-[240px] px-4 py-4 text-stone">{r.message ?? "—"}</td>
                <td className="px-4 py-4">
                  <span className={`inline-block rounded-brand px-2 py-1 text-[11px] font-semibold tracking-[0.18em] uppercase ${STATUS_STYLES[r.status] ?? ""}`}>{r.status}</span>
                  <form action={updateStatusAction} className="mt-2 flex items-center gap-2">
                    <input type="hidden" name="id" value={r.id} />
                    <select name="status" defaultValue={r.status} className="field px-2 py-1.5 text-xs" aria-label={`Update status for ${r.reference}`}>
                      <option value="new">new</option>
                      <option value="contacted">contacted</option>
                      <option value="confirmed">confirmed</option>
                      <option value="closed">closed</option>
                    </select>
                    <button type="submit" className="btn btn-primary btn-sm !min-h-8 !px-3 !py-1">Save</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-6 text-xs leading-6 text-stone">
        Content (logo, doctors, services, reviews, gallery, videos, blog, contact details) is managed in <code className="font-mono">src/content/*</code> — see <code className="font-mono">CONTENT-GUIDE.md</code>. Clinic WhatsApp:{" "}
        <a href={whatsappLink()} className="text-gold-deep hover:underline">{site.whatsapp.display}</a>.
      </p>
    </Shell>
  );
}

function Shell({ title, children, aside }: { title: string; children: React.ReactNode; aside?: React.ReactNode }) {
  return (
    <section className="bg-cream">
      <div className="container-x py-16 lg:py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">{site.name} · Admin</p>
            <h1 className="mt-4 display-md text-ink">{title}</h1>
          </div>
          {aside}
        </div>
        <div className="mt-10">{children}</div>
      </div>
    </section>
  );
}
