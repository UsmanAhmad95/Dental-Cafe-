"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { ADMIN_COOKIE, isAdminAuthenticated, tokenForConfiguredPassword, verifyPassword } from "@/lib/admin-auth";

const STATUSES = new Set(["new", "contacted", "confirmed", "closed"]);

export async function loginAction(formData: FormData) {
  const password = String(formData.get("password") ?? "");
  if (!verifyPassword(password)) {
    revalidatePath("/admin");
    return;
  }
  const token = tokenForConfiguredPassword();
  if (!token) return;
  const store = await cookies();
  store.set(ADMIN_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/admin",
    maxAge: 60 * 60 * 12,
  });
  revalidatePath("/admin");
}

export async function logoutAction() {
  const store = await cookies();
  store.delete(ADMIN_COOKIE);
  revalidatePath("/admin");
}

export async function updateStatusAction(formData: FormData) {
  if (!(await isAdminAuthenticated())) return;
  const id = Number(formData.get("id"));
  const status = String(formData.get("status") ?? "");
  if (!Number.isInteger(id) || !STATUSES.has(status)) return;
  await db
    .update(appointments)
    .set({ status, updatedAt: new Date() })
    .where(eq(appointments.id, id));
  revalidatePath("/admin");
}
