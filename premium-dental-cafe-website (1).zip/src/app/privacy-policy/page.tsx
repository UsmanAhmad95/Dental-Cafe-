import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { Placeholder } from "@/components/ui/SectionHeading";
import { PLACEHOLDERS, site } from "@/content/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `How ${site.name} handles the personal information you share with us.`,
  alternates: { canonical: "/privacy-policy" },
};

export default function PrivacyPolicyPage() {
  return (
    <>
      <PageHero tone="light" compact eyebrow="Legal" title="Privacy Policy" crumbs={[{ label: "Privacy Policy" }]} />
      <section className="bg-white">
        <div className="container-x pb-24">
          <div className="prose-cafe max-w-3xl">
            <p>Last updated: {new Date().toLocaleDateString("en-GB", { month: "long", year: "numeric" })}</p>
            <h2>Information we collect</h2>
            <p>
              When you request an appointment, contact us by phone or WhatsApp, or use this website, we may collect the information you provide — such as your name, phone number, WhatsApp number, preferred appointment details and any message you include.
            </p>
            <h2>How we use it</h2>
            <ul>
              <li>To respond to your enquiry and confirm appointment requests</li>
              <li>To provide and coordinate your dental care</li>
              <li>To maintain accurate clinical and administrative records</li>
            </ul>
            <h2>Sharing</h2>
            <p>We do not sell your personal information. Information is shared only with members of our clinical and administrative team as needed to provide your care, or where required by law.</p>
            <h2>Third-party services</h2>
            <p>This website may embed services such as Google Maps and links to WhatsApp, Instagram and Facebook. Those services operate under their own privacy policies.</p>
            <h2>Your choices</h2>
            <p>You may contact us at any time to ask what information we hold about you or to request a correction.</p>
            <h2>Contact</h2>
            <p>
              {site.name}, {site.location.full} · {site.contact.phone} · {site.contact.email ?? <Placeholder label={PLACEHOLDERS.email} />}
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
