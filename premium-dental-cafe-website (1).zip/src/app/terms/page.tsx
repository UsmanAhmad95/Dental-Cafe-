import type { Metadata } from "next";
import { PageHero } from "@/components/ui/PageHero";
import { site } from "@/content/site";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: `Terms of use for the ${site.name} website and appointment request service.`,
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <>
      <PageHero tone="light" compact eyebrow="Legal" title="Terms & Conditions" crumbs={[{ label: "Terms & Conditions" }]} />
      <section className="bg-white">
        <div className="container-x pb-24">
          <div className="prose-cafe max-w-3xl">
            <h2>Use of this website</h2>
            <p>This website is provided by {site.name} for general information about our clinic and services. By using it you agree to these terms.</p>
            <h2>Appointment requests</h2>
            <p>
              Submitting the online form creates an appointment <strong>request</strong> only. An appointment is confirmed only when a member of our team contacts you. Please contact the clinic directly if you have not heard from us.
            </p>
            <h2>Medical information</h2>
            <p>Content on this site is general and educational. It is not a substitute for a clinical examination or personalised advice from a qualified dental professional.</p>
            <h2>Intellectual property</h2>
            <p>All logos, photographs, text and design elements are the property of {site.name} or their respective owners and may not be reproduced without permission.</p>
            <h2>External links</h2>
            <p>Links to third-party sites (including Google Maps, WhatsApp, Instagram and Facebook) are provided for convenience. We are not responsible for their content.</p>
            <h2>Contact</h2>
            <p>{site.name}, {site.location.full} · {site.contact.phone}</p>
          </div>
        </div>
      </section>
    </>
  );
}
