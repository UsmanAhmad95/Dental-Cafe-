import Link from "next/link";
import { site } from "@/content/site";
import { whatsappLink } from "@/lib/links";

export default function NotFound() {
  return (
    <section className="bg-ink text-white">
      <div className="container-x flex min-h-[70svh] flex-col items-center justify-center py-24 text-center">
        <p className="eyebrow eyebrow-plain">404</p>
        <h1 className="mt-5 display-lg">This page could not be found</h1>
        <p className="mt-6 max-w-md text-white/70">
          The page you are looking for may have moved. Let us help you find your way back to {site.name}.
        </p>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <Link href="/" className="btn btn-gold">Back to Home</Link>
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light">Chat on WhatsApp</a>
        </div>
      </div>
    </section>
  );
}
