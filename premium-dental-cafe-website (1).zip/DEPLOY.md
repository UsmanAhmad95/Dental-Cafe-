# Dental Cafe — Production Deployment Guide

> **Why you need this:** the preview link produced inside the build sandbox is a temporary
> session URL (its hostname changes on every restart and it stops when the sandbox stops).
> A permanent public URL requires the code to run on a hosting account you own.
> This project is fully prepared for that — deployment is ~10–15 minutes.

## What the app needs

| Requirement | Why |
| --- | --- |
| Node.js host that runs Next.js 16 (Vercel, Railway, Render, Fly.io, DigitalOcean, any VPS with Docker) | Booking API, `/admin` and image optimisation are server-side |
| A PostgreSQL database (Neon, Supabase, Railway, Render, RDS…) | Stores appointment requests |
| Three environment variables (below) | Configuration only — no secrets are in the code |

### Environment variables

| Key | Example | Notes |
| --- | --- | --- |
| `DATABASE_URL` | `postgresql://user:pass@host/db?sslmode=require` | From your Postgres provider |
| `ADMIN_PASSWORD` | a long random string | Protects `/admin` |
| `NEXT_PUBLIC_SITE_URL` | `https://www.dentalcafe.pk` | Your public domain (auto-detected on Vercel if omitted) |

---

## Option A — Vercel + Neon (recommended, fastest)

1. **Put the code in a Git repository** (GitHub/GitLab/Bitbucket). From the project folder:
   ```bash
   git init && git add -A && git commit -m "Dental Cafe website"
   git remote add origin https://github.com/<you>/dental-cafe.git && git push -u origin main
   ```
2. **Create the database** at [neon.tech](https://neon.tech) → New project → copy the *pooled* connection string.
3. **Create the tables** (run once, from the project folder):
   ```bash
   DATABASE_URL="postgresql://...?sslmode=require" npx drizzle-kit push --config drizzle.config.prod.ts
   ```
   *(No terminal? Paste the contents of `drizzle/0000_init.sql` into Neon's SQL Editor and run it.)*
4. **Deploy** at [vercel.com/new](https://vercel.com/new) → Import the repository → Framework: Next.js (auto) →
   add the three environment variables → **Deploy**. You get `https://<project>.vercel.app` immediately.
5. **Custom domain**: Vercel → Project → Settings → Domains → add `dentalcafe.pk` (or your domain) and set
   the DNS records Vercel shows. Then set `NEXT_PUBLIC_SITE_URL` to that domain and redeploy.

> Vercel's free Hobby plan is for non-commercial use; a clinic website should be on Vercel **Pro**
> (or use Option B). Neon's free tier is fine to start.

**CLI alternative** (instead of step 4): `npx vercel login` then `npx vercel --prod`.

---

## Option B — Docker on Railway / Render / Fly.io / VPS

The included `Dockerfile` builds a self-contained production server.

**Railway** (simple, includes Postgres): New Project → *Deploy from GitHub repo* → Railway detects the
Dockerfile → click **+ New → Database → PostgreSQL** → in the web service add variables
`DATABASE_URL = ${{Postgres.DATABASE_URL}}`, `ADMIN_PASSWORD`, `NEXT_PUBLIC_SITE_URL` → Settings → *Generate Domain*.
Then run the table creation command from Option A step 3 (or `railway run npx drizzle-kit push --config drizzle.config.prod.ts`).

**Any VPS / Docker host:**
```bash
docker build --build-arg NEXT_PUBLIC_SITE_URL=https://www.dentalcafe.pk -t dental-cafe .
docker run -d --restart=always -p 3000:3000 \
  -e DATABASE_URL="postgresql://...?sslmode=require" \
  -e ADMIN_PASSWORD="long-random-string" \
  -e NEXT_PUBLIC_SITE_URL="https://www.dentalcafe.pk" \
  dental-cafe
```
Put Nginx/Caddy in front for HTTPS, or use the host's built-in TLS.

---

## Post-deployment checklist (5 minutes)

- [ ] `https://<your-domain>/api/health` returns `{"ok":true}` (database connected)
- [ ] Submit a test booking at `/book` → "APPOINTMENT REQUEST RECEIVED" with a `DC-…` reference
- [ ] Sign in at `/admin` with `ADMIN_PASSWORD` → the test request is listed → set it to *closed*
- [ ] Drop the official logo into `public/assets/brand/logo.png` and doctor photos into
      `public/assets/doctors/` → flip `status: "real"` in `src/content/assets.ts` (see `CONTENT-GUIDE.md`)
- [ ] Choose the homepage design (Option 1 = `/`, Option 2 = `/option-2`) and remove
      `<OptionSwitcher />` from `src/app/page.tsx`
- [ ] Add the domain to Google Business Profile, Instagram and Facebook bios

### Resilience built in
- The database client connects lazily, so builds never need a live DB.
- If the database is ever unreachable, the booking form offers a one-tap
  **"Send this request on WhatsApp instead"** fallback with the details pre-filled.
- All pages except `/admin` and the API are statically pre-rendered → fast and cheap to host.

### Updating content later
Edit files in `src/content/` and `public/assets/` → commit → push. Vercel/Railway redeploy automatically.
